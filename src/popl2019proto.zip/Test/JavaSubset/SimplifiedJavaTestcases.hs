import BX
import BXDef
import Data.Dynamic
import Text.Show.Pretty

-- public class Vehicle {
--   /** fuelling
--   */
--   public void fuel (int vol) {
--     for (int oil : arr ){
--       oil = oil + vol;
--     }
--   }
-- }

-- public class Car extends Vehicle {

-- }

-- public class Bus extends Vehicle {

-- }

-- public class Bicycle extends Vehicle {

-- }


cst :: CompilationUnit
cst = CompilationUnit $
  Cons vehicle (Cons car (Cons bus (Cons bicycle Nil)))

vehicle = FromClassDeclaration (NormalClassDeclaration3 "VehicleClass" "public" "class" "Vehicle" vehicleBody)

vehicleBody :: ClassBody
vehicleBody = ClassBody1 "{" (Cons (FromClassMemberDeclaration memberDec) Nil) "}"

memberDec :: ClassMemberDeclaration
memberDec = MethodDeclaration1 "fuelling it!" "public"
  (MethodHeader (LLeft UInteger) (MethodDeclarator1 "fuel" "(" methArg ")")) methBody

methArg :: Prod UType String
methArg = Prod UInteger "vol"

methBody :: MethodBody
methBody = MethodBody0 (Cons (FromStatement forEachLoop) Nil)

forEachLoop :: Statement
forEachLoop = EnhancedFor "for" "(" UInteger "oil" ":" arrExpr ")" (FromBlockStatement forStmtBlock)

arrExpr = AssignExp (FromRelExp (FromAdditiveExp (FromPostfixExp (ExpN "arr"))))

forStmtBlock = Cons (FromStatement (ExpressionStatement (AssignExp assign) ";")) Nil

assign = Assignment "oil" "=" addExp

addExp = AssignExp (FromRelExp (FromAdditiveExp (AdditiveExp0 (FromPostfixExp (ExpN "oil")) "+" (ExpN "vol"))))


-- empty classes car, bus, and bicycle
car = FromClassDeclaration (NormalClassDeclaration1 "CarClass" "public" "class" "Car" "extends" "Vehicle" nilBody)

bus = FromClassDeclaration (NormalClassDeclaration1 "BusClass" "public" "class" "Bus" "extends" "Vehicle" nilBody)

bicycle = FromClassDeclaration (NormalClassDeclaration1 "BicycleClass" "public" "class" "Bicycle" "extends" "Vehicle" nilBody)

nilBody :: ClassBody
nilBody = ClassBody0 "{" "}"


getcst = topGetCompilationUnitJCCompilationUnit cst
putSrcIdLinks = fromDyn (topPut CompilationUnitTag CompilationUnitTag JCCompilationUnitTag
  (toDyn cst) (toDyn $ fst v) (snd v)) CompilationUnitNull
  where v = topGetCompilationUnitJCCompilationUnit cst
testPutSrcIdLinks = putSrcIdLinks == cst

putSrcIdNoLink = fromDyn (topPut CompilationUnitTag CompilationUnitTag JCCompilationUnitTag
  (toDyn cst) (toDyn $ fst v) []) CompilationUnitNull
  where v = topGetCompilationUnitJCCompilationUnit cst
testPutSrcIdNoLink = fst getcst == fst (topGetCompilationUnitJCCompilationUnit (putSrcIdNoLink))


ast = fst $ getcst
consisLinks = snd $ getcst
consisRegionLinks = eraseSecondOrderProp consisLinks

-- ast' is created by pushing the fuel method declaration into Car and Bus but not Bicycle
ast' = JCCompilationUnit
  (Cons (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust "public") "Vehicle" NNothing Nil)))
  (Cons (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust "public") "Car" (JJust (JCIdent "Vehicle")) (Cons (FromJCMethodDecl (JCMethodDecl (JJust "public") "fuel" (JCPrimitiveTypeTree UInteger) (JJust (JCVariableDecl NNothing "vol" (JCPrimitiveTypeTree UInteger) NNothing)) (Cons (JCForLoop (Cons (FromJCVariableDecl (JCVariableDecl NNothing "i" (JCPrimitiveTypeTree UInteger) (JJust (FromJCLiteral (UIntegerLit 0))))) Nil) (JCBinary LESSTHAN (JCIdent "i") (JCFieldAccess (JCIdent "arr") "length") "<") (Cons (JCUnary POSTINC (JCIdent "i") "++") Nil) (FromJCBlock (Cons (FromJCVariableDecl (JCVariableDecl NNothing "oil" (JCPrimitiveTypeTree UInteger) (JJust (JCArrayAccess (JCIdent "arr") (JCIdent "i"))))) (Cons (FromJCExpressionStatement (JCAssign (JCIdent "oil") (JCBinary PLUS (JCIdent "oil") (JCIdent "vol") "+"))) Nil)))) Nil))) Nil))))
  (Cons (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust "public") "Bus" (JJust (JCIdent "Vehicle")) (Cons (FromJCMethodDecl (JCMethodDecl (JJust "public") "fuel" (JCPrimitiveTypeTree UInteger) (JJust (JCVariableDecl NNothing "vol" (JCPrimitiveTypeTree UInteger) NNothing)) (Cons (JCForLoop (Cons (FromJCVariableDecl (JCVariableDecl NNothing "i" (JCPrimitiveTypeTree UInteger) (JJust (FromJCLiteral (UIntegerLit 0))))) Nil) (JCBinary LESSTHAN (JCIdent "i") (JCFieldAccess (JCIdent "arr") "length") "<") (Cons (JCUnary POSTINC (JCIdent "i") "++") Nil) (FromJCBlock (Cons (FromJCVariableDecl (JCVariableDecl NNothing "oil" (JCPrimitiveTypeTree UInteger) (JJust (JCArrayAccess (JCIdent "arr") (JCIdent "i"))))) (Cons (FromJCExpressionStatement (JCAssign (JCIdent "oil") (JCBinary PLUS (JCIdent "oil") (JCIdent "vol") "+"))) Nil)))) Nil))) Nil))))
  (Cons (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust "public") "Bicycle" (JJust (JCIdent "Vehicle")) Nil))) Nil))))

-- now we create the diagonal links by hand:
-- we link the fuel method in the Car class so that the EnhancedFor is preserved
-- as comparison, we do not link the fuel method in the Bus class so that a default BasicFor will be created
diagonalRegionLinks = shiftPaths (deleteBusLinks (deleteCarLinks consisRegionLinks))

-- we delete the links connected to the body of the Vehicle class, since the method disappear
deleteCarLinks = filter (\((sr,sp),(vr,vp)) -> length vp <= 3 || take 3 vp /= [0,1,0])


-- the fuel method is Pushed Down into the Car class, so that the method should have links to the old source cst
-- we can view this modification as "shift" the fuel method from Vehicle class to the Car class
-- so that the new links can be obtained by shift the prefix of the old links
-- before that, we delete the links of the bus class
deleteBusLinks = filter (\((sr,sp),(vr,vp)) -> length vp <= 4 || take 4 vp /= [0,1,1,0])

shiftPaths = map shiftPath
-- shift the path [0,0,0,0...] in view-region to [0,1,0,0,0...]
-- create diagonal links. Region = (RegPat, Path)
shiftPath :: (Region, Region) -> (Region,Region)
shiftPath ((sr,sp),(vr, 0:0:0:0:3:vp)) = ((sr,sp),(vr, 0:1:0:0:0:3:vp))
shiftPath a = a


-- now we cant test put cst ast' with diagonal links
-- the result will show:
-- (1) a Vehicle class with empty body
-- (2) a Car class with annotations and Enhanced for loop preserved (search for MethodDeclaration1 "fuelling it!" and EnhancedFor)
-- (3) a Bus class without annotations and a Basic for loop is created (search for MethodDeclaration1 "DEF_VAL" and BasicFor)
-- (4) a Bicycle class with empty body
putSrcMASTDiagLink' = putStrLn . ppShow $ putSrcMASTDiagLink

putSrcMASTDiagLink = fromDyn (topPut CompilationUnitTag CompilationUnitTag JCCompilationUnitTag
  (toDyn cst) (toDyn $ ast') (toHLink diagonalRegionLinks)) CompilationUnitNull

-- True
testputSrcMASTDiagLink = fst (topGetCompilationUnitJCCompilationUnit putSrcMASTDiagLink) == ast'

-- False, of course
testputSrcMASTDiagLink2 = topGetCompilationUnitJCCompilationUnit putSrcMASTDiagLink == getcst



--------------------------
-- after code refactoring


-- public class Vehicle {

-- }

-- public class Car extends Vehicle {
--   /** fuelling
--   */
--   public void fuel (int vol) {
--     for (int oil : arr ){
--       oil = oil + vol;
--     }
--   }
-- }

-- public class Bus extends Vehicle {
--   /** fuelling
--   */
--   public void fuel (int vol) {
--     for (int oil : arr ){
--       oil = oil + vol;
--     }
--   }
-- }


-- public class Bicycle extends Vehicle {

-- }
