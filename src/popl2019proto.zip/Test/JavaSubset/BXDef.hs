{-# LANGUAGE DeriveDataTypeable, TypeSynonymInstances, FlexibleInstances, MultiParamTypeClasses, ViewPatterns #-}

module BXDef where

import Prelude hiding (putChar)
import Data.Data
import Data.Generics hiding (GT)
import Data.Dynamic
import Data.List (partition, sortBy)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Maybe (catMaybes, isJust, fromJust)

type Region = (RegPat, Path)
type RLink = (Region, Region)

type NamedPat = (RegPat, Int)
type NamedRegion = (NamedPat, Path)
type NamedRLink = (NamedRegion, NamedRegion)

data SProp = Top NamedPat
           | Child NamedPat NamedPat Integer
  deriving (Show, Eq, Ord)

type SPropLink = (SProp, SProp)
data HLink = FirstOrderLink  NamedRLink
           | SecondOrderLink SPropLink
  deriving (Show, Eq, Ord)

type SSLink = (Path,RegPat,Path)
type VVLink = (Path,Region,Path)

type OSDyn = Dynamic
type SDyn  = Dynamic
type VDyn  = Dynamic

type OSTyTag = TyTag
type STyTag  = TyTag
type VTyTag  = TyTag
type SupTyTag = TyTag
type SubTyTag = TyTag

type Path = [Integer]
type Env = [HLink]
type HLinks = [HLink]
type SSLinks = [SSLink]
type VVLinks = [VVLink]

-- functions handling paths and steps.
-- compose a SSLink and a RLink
compSSSV :: SSLink -> RLink -> Maybe RLink
compSSSV (sPathU,sReg1,sPathB) ((sReg2,sPathL),(vReg,vPathR))
  | sPathB == sPathL && sReg1 == sReg2 = Just ((sReg2,sPathU),(vReg,vPathR))
compSSSV _ _ = Nothing

-- compose SSLinks and [RLink]
compSSSVs :: SSLinks -> [RLink] -> [RLink]
compSSSVs ss sv = catMaybes [compSSSV s v | s <- ss, v <- sv]

filterEnv :: Path -> [RLink] -> [RLink]
filterEnv s = filter (\ (_ , (_,p)) -> isPrefix s p)

isPrefix :: Path -> Path -> Bool
isPrefix [] _ = True
isPrefix (s1:ss1) (s2:ss2) | s1 /= s2 = False
isPrefix (s1:ss1) (s2:ss2) | s1 == s2 = isPrefix ss1 ss2
isPrefix _ _ = False

-- delete the given prefix path from all links
delPathH :: (Path,Path) -> RLink -> RLink
delPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) =
  ((sReg,delPrefix sPre sp) , (vReg,delPrefix vPre vp))

delPrefix :: Path -> Path -> Path
delPrefix [] p = p
delPrefix s1 s2 = if isPrefix s1 s2 then drop (length s1) s2
  else error $ "the first input path is not a prefix of the second \n" ++
               "input path1: " ++ show s1 ++ "\n" ++ "input path2: " ++ show s2

addPathSS :: (Path,Path) -> SSLink -> SSLink
addPathSS (sPre1,sPre2) (sp1,sPat,sp2) = (sPre1 ++ sp1,sPat,sPre2 ++ sp2)

addPathH :: (Path,Path) -> RLink -> RLink
addPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) = ((sReg,sPre ++ sp) , (vReg,vPre ++ vp))

hasTopLink :: [RLink] -> Bool
hasTopLink = ([] `elem`) . map (snd . snd)

-- get links with empty view paths (link at the top)
-- return a Maybe real-link, a list of imaginary links (may be empty list), and remainings
-- to do so, we first sort the HLinks in the following order:
-- (3) : the links whose view-paths are empty come first
-- (2) : among (3), whose view-patterns is Void come first.
-- (1) : among (2), whose source-paths are smaller come first.
getTopLinks :: [RLink] -> (Maybe RLink, [RLink], [RLink])
getTopLinks hls =
  let (candidates3,rem3) = partition (\ (_,(_,vpath)) -> null vpath) hls
      -- rem2 should be either empty or singleton
      (candidates2,rem2) = partition (\ (_,(vRegion,_)) -> vRegion == Void) candidates3 
      candidates1 = sortBy cmpSPathRL candidates2
  in  case rem2 of
        []  -> (Nothing, candidates1, rem3)
        [r] -> (Just r, candidates1, rem3)

cmpSPathRL :: RLink -> RLink -> Ordering
cmpSPathRL ((_,sp1),_) ((_,sp2),_) = if sp1 < sp2 then LT
  else if sp1 == sp2 then EQ else GT


toHLink :: [RLink] -> [HLink]
toHLink rls =
  let nrls = nameRLink rls
  in  map FirstOrderLink nrls ++ [topProp nrls] ++ relativePos nrls

nameRLink :: [RLink] -> [NamedRLink]
nameRLink rls =
  let rls' = sortBy cmpSPathRL rls
  in  zipWith (\((sPat,sPath), (vPat,vPath)) i ->
                  (((sPat,i),sPath) , ((vPat,i),vPath))) rls' [0..]

-- assume input lists are sorted
topProp :: [NamedRLink] -> HLink
topProp nrls =
  case filter (\ (((sPat,si),sPath) , ((vPat,vi),vPath)) -> null sPath && null vPath) nrls of
    [((nspat,[]) , (nvPat,[]))] -> SecondOrderLink (Top nspat , Top nvPat)

-- assume input lists are sorted
relativePos :: [NamedRLink] -> [HLink]
relativePos [] = []
relativePos (nrl@((_,sPath0), _):nrls) =
  let (children, others) = span (\ ((_,sPath1), _)  -> 1 + length sPath0 == length sPath1) nrls
  in  establishPosLink nrl children ++ relativePos nrls

establishPosLink :: NamedRLink -> [NamedRLink] -> [HLink]
establishPosLink _ [] = []
establishPosLink father@((fnsPat,fsPath),(fnvPat,fvPath)) (((cnsPat,csPath),(cnvPat,cvPath)) : cs) =
  let sPos = if null (drop (length fsPath) csPath)
              then error "impossible. in generating second-order links (relative positions)"
              else head $ drop (length fsPath) csPath
      vPos = if null (drop (length fvPath) cvPath)
              then -1
              else head $ drop (length fvPath) cvPath
  in  SecondOrderLink ((Child fnsPat cnsPat sPos) , (Child cnvPat cnvPat vPos)) :
      establishPosLink father cs


eraseSecondOrderProp :: [HLink] -> [RLink]
eraseSecondOrderProp [] = []
eraseSecondOrderProp (FirstOrderLink nrLink : l) = eraseName nrLink : eraseSecondOrderProp l
eraseSecondOrderProp (SecondOrderLink _ : l) = eraseSecondOrderProp l

eraseName :: NamedRLink -> RLink
eraseName (((regPatS,_), pathS), ((regPatV,_), pathV)) = ((regPatS, pathS) , (regPatV, pathV))

apFst f (x,y) = (f x , y)



data Prod a b =
    Prod a b
  | ProdNull
  deriving (Show, Read, Eq, Data, Typeable)

data List a =
    Nil
  | Cons a (List a)
  | ListNull
  deriving (Show, Read, Eq, Data, Typeable)

data MMaybe a =
    NNothing
  | JJust a
  | MMaybeNull
  deriving (Show, Read, Eq, Data, Typeable)

data EEither a b =
    LLeft a
  | RRight b
  | EEitherNull
  deriving (Show, Read, Eq, Data, Typeable)

data UType =
    UInteger
  | UString
  | UBool
  | UVoid
  | UTypeNull
  deriving (Show, Read, Eq, Data, Typeable)

data ULit =
    UIntegerLit Integer
  | UStringLit String
  | UBoolLit Bool
  | ULitNull
  deriving (Show, Read, Eq, Data, Typeable)

data CompilationUnit =
    CompilationUnit (List TypeDeclaration)
  | CompilationUnitNull
  deriving (Show, Read, Eq, Data, Typeable)

data TypeDeclaration =
    FromClassDeclaration ClassDeclaration
  | TypeDeclarationSkip String
  | TypeDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassDeclaration =
    NormalClassDeclaration0 String String String String String ClassBody
  | NormalClassDeclaration1 String String String String String String ClassBody
  | NormalClassDeclaration2 String String String ClassBody
  | NormalClassDeclaration3 String String String String ClassBody
  | ClassDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassBody =
    ClassBody0 String String
  | ClassBody1 String (List ClassBodyDeclaration) String
  | ClassBodyNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassBodyDeclaration =
    FromClassMemberDeclaration ClassMemberDeclaration
  | FromInstanceInitializer (List BlockStatement)
  | ClassBodyDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassMemberDeclaration =
    FieldDeclaration0 String UType VariableDeclarator String
  | FieldDeclaration1 String String UType VariableDeclarator String
  | MethodDeclaration0 String MethodHeader MethodBody
  | MethodDeclaration1 String String MethodHeader MethodBody
  | MemberFromClassDeclaration ClassDeclaration
  | ClassMemberDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data MethodHeader =
    MethodHeader (EEither UType String) MethodDeclarator
  | MethodHeaderNull
  deriving (Show, Read, Eq, Data, Typeable)

data MethodBody =
    MethodBody0 (List BlockStatement)
  | MethodBody1 String
  | MethodBodyNull
  deriving (Show, Read, Eq, Data, Typeable)

data MethodDeclarator =
    MethodDeclarator0 String String String
  | MethodDeclarator1 String String (Prod UType String) String
  | MethodDeclaratorNull
  deriving (Show, Read, Eq, Data, Typeable)

data BlockStatement =
    LocalVariableDeclaration UType VariableDeclarator
  | BlockFromClassDeclaration ClassDeclaration
  | FromStatement Statement
  | BlockStatementNull
  deriving (Show, Read, Eq, Data, Typeable)

data Statement =
    IfThenElse String String Expression String Statement String Statement
  | ExpressionStatement Expression String
  | While String String Expression String Statement
  | BasicFor String String (List BlockStatement) String Expression String (List Expression) String Statement
  | EnhancedFor String String UType String String Expression String Statement
  | FromBlockStatement (List BlockStatement)
  | StatementNull
  deriving (Show, Read, Eq, Data, Typeable)

data Expression =
    AssignExp Assignment
  | MethodInvocation0 String String String
  | MethodInvocation1 String String Expression String
  | ExpressionNull
  deriving (Show, Read, Eq, Data, Typeable)

data Assignment =
    Assignment String String Expression
  | FromRelExp RelExp
  | AssignmentNull
  deriving (Show, Read, Eq, Data, Typeable)

data VariableDeclarator =
    VariableDeclarator0 String
  | VariableDeclarator1 String VariableInitializer
  | VariableDeclaratorNull
  deriving (Show, Read, Eq, Data, Typeable)

data VariableInitializer =
    VariableInitializer String Expression
  | VariableInitializerNull
  deriving (Show, Read, Eq, Data, Typeable)

data RelExp =
    RelExp0 RelExp String PostfixExp
  | FromAdditiveExp AdditiveExp
  | RelExpNull
  deriving (Show, Read, Eq, Data, Typeable)

data AdditiveExp =
    AdditiveExp0 AdditiveExp String PostfixExp
  | FromPostfixExp PostfixExp
  | AdditiveExpNull
  deriving (Show, Read, Eq, Data, Typeable)

data PostfixExp =
    PostIncExp PostfixExp String
  | FromPrimary Primary
  | ExpN String
  | PostfixExpNull
  deriving (Show, Read, Eq, Data, Typeable)

data Primary =
    PrimaryLit ULit
  | Paren String Expression String
  | FieldAccess PostfixExp String String
  | ArrayAccess String String Expression String
  | PrimaryNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCCompilationUnit =
    JCCompilationUnit (List JCTree)
  | JCCompilationUnitNull
  deriving (Show, Re