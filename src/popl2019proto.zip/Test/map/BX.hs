{-# LANGUAGE ViewPatterns #-}
module BX where

import BXDef
import Prelude hiding (putChar)
import Data.Maybe (isJust, isNothing, fromJust)
import Data.List (partition, sortBy, sort)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Dynamic
import Text.Show.Pretty (pPrint, ppShow)

topGetBinTNatBinTBoool :: BinT Nat -> (BinT Boool, [HLink])

topGetBinTNatBinTBoool s = let (view,
                                rlinks) = getBinTNatBinTBoool s
                            in (view, toHLink rlinks)

topGetNatBoool :: Nat -> (Boool, [HLink])

topGetNatBoool s = let (view, rlinks) = getNatBoool s
                    in (view, toHLink rlinks)

getBinTNatBinTBoool :: BinT Nat -> (BinT Boool, [RLink])

getBinTNatBinTBoool (Tip) = (Tip, l0 : ls')
                        where l0 = ((BinTNatBinTBooolS0, []), (BinTNatBinTBooolV0, []))
                              ls' = concat []
getBinTNatBinTBoool (Node xl0 lsl1 rsl2) = (Node xr0 lsr1 rsr2,
                                            l0 : ls')
                        where (xr0, xr0ls) = getNatBoool xl0
                              preS_xr0 = [0]
                              preV_xr0 = [0]
                              xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                              (lsr1, lsr1ls) = getBinTNatBinTBoool lsl1
                              preS_lsr1 = [1]
                              preV_lsr1 = [1]
                              lsr1ls' = map (addPathH (preS_lsr1, preV_lsr1)) lsr1ls
                              (rsr2, rsr2ls) = getBinTNatBinTBoool rsl2
                              preS_rsr2 = [2]
                              preV_rsr2 = [2]
                              rsr2ls' = map (addPathH (preS_rsr2, preV_rsr2)) rsr2ls
                              l0 = ((BinTNatBinTBooolS1, []), (BinTNatBinTBooolV1, []))
                              ls' = concat [xr0ls', lsr1ls', rsr2ls']

getNatBoool :: Nat -> (Boool, [RLink])

getNatBoool (Succ _) = (TTrue, l0 : ls')
                where l0 = ((NatBooolS0, []), (NatBooolV0, []))
                      ls' = concat []
getNatBoool (Zero) = (FFalse, l0 : ls')
                where l0 = ((NatBooolS1, []), (NatBooolV1, []))
                      ls' = concat []

getIntegerInteger s = (s, [((IntegerR, []), (IntegerR, []))])

getStringString s = (s, [((StringR, []), (StringR, []))])

getCharChar s = (s, [((CharR, []), (CharR, []))])

getBoolBool s = (s, [((BoolR, []), (BoolR, []))])

put :: OSTyTag ->
       STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

put osTy sTy vTy osDyn vDyn env | not (hasTopLink env) = putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env

put osTy sTy vTy osDyn vDyn env | hasTopLink env = putWithLinks osTy sTy vTy osDyn vDyn env

putNoLink :: OSTyTag ->
             STyTag -> VTyTag -> RegPat -> OSDyn -> VDyn -> [RLink] -> SDyn

putNoLink _ (IntegerTag) (IntegerTag) _ _ dynV _ = dynV

putNoLink _ (StringTag) (StringTag) _ _ dynV _ = dynV

putNoLink _ (CharTag) (CharTag) _ _ dynV _ = dynV

putNoLink _ (BoolTag) (BoolTag) _ _ dynV _ = dynV

putNoLink osTy (BinTNatTag) (BinTBooolTag) BinTNatBinTBooolS0 osDyn ((fromDynamic :: Dynamic -> Maybe (BinT Boool)) -> Just (Tip)) env = toDyn ((Tip) :: ( BinT Nat ))
putNoLink osTy (BinTNatTag) (BinTBooolTag) BinTNatBinTBooolS1 osDyn ((fromDynamic :: Dynamic -> Maybe (BinT Boool)) -> Just (Node xr0
                                                                                                                                  lsr1
                                                                                                                                  rsr2)) env = toDyn ((Node res_xr0 res_lsr1 res_rsr2) :: ( BinT Nat ))
              where preS_xr0 = [0]
                    preV_xr0 = [0]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( Nat )
                    res_xr0 = fromJust (fromDynamic (put osTy NatTag BooolTag osDyn (toDyn xr0) env_xr0))
                    preS_lsr1 = [1]
                    preV_lsr1 = [1]
                    env_lsr1 = map (delPathH ([], preV_lsr1)) (filterEnv preV_lsr1 env)
                    res_lsr1 :: ( BinT Nat )
                    res_lsr1 = fromJust (fromDynamic (put osTy BinTNatTag BinTBooolTag osDyn (toDyn lsr1) env_lsr1))
                    preS_rsr2 = [2]
                    preV_rsr2 = [2]
                    env_rsr2 = map (delPathH ([], preV_rsr2)) (filterEnv preV_rsr2 env)
                    res_rsr2 :: ( BinT Nat )
                    res_rsr2 = fromJust (fromDynamic (put osTy BinTNatTag BinTBooolTag osDyn (toDyn rsr2) env_rsr2))

putNoLink osTy (NatTag) (BooolTag) NatBooolS0 osDyn ((fromDynamic :: Dynamic -> Maybe (Boool)) -> Just (TTrue)) env = toDyn ((Succ NatNull) :: Nat)
putNoLink osTy (NatTag) (BooolTag) NatBooolS1 osDyn ((fromDynamic :: Dynamic -> Maybe (Boool)) -> Just (FFalse)) env = toDyn ((Zero) :: Nat)

putWithLinks :: OSTyTag ->
                STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

putWithLinks osTy sTy vTy osDyn vDyn env = s4
                 where (maybeL, imags, env') = getTopLinks env
                       s2 = case maybeL of
                                Just l -> let {((sReg, sPath), (_, [])) = l;
                                               s0 = fetch' osTy osDyn l;
                                               s1 = putNoLink osTy (askDynTyTag s0) vTy sReg osDyn vDyn env'}
                                           in (repSubtree sReg s0 s1)
                                Nothing -> putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env'
                       s3 = foldr (splice osDyn) s2 imags
                       s4 = mkInj (askDynTyTag s3) sTy s3

topPut :: OSTyTag -> STyTag -> VTyTag -> OSDyn -> VDyn -> [HLink] -> SDyn

topPut osTy sTy vTy osDyn vDyn hls = put osTy sTy vTy osDyn vDyn (eraseSecondOrderProp hls)

