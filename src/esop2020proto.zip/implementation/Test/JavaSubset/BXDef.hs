{-# LANGUAGE DeriveDataTypeable, TypeSynonymInstances, FlexibleInstances, MultiParamTypeClasses, ViewPatterns #-}

module BXDef where

import Prelude hiding (putChar)
import Data.Data
import Data.Generics hiding (GT)
import Data.Dynamic
import Data.List (partition, sortBy, nub)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Maybe (catMaybes, isJust, fromJust)

type Region = (RegPat, Path)
type RLink = (Region, Region)
type HLink = RLink

type VLink = (Path,RegPat,Path)
type VCorr = VLink

type OSDyn = Dynamic
type SDyn  = Dynamic
type VDyn  = Dynamic

type OSTyTag = TyTag
type STyTag  = TyTag
type VTyTag  = TyTag
type SupTyTag = TyTag
type SubTyTag = TyTag

type Path = [Integer]
type Env = [RLink]
type RLinks = [RLink]

-- functions handling paths and steps.

-- compose a HLink and a VLink
compHV :: RLink -> VCorr -> Maybe RLink
compHV ((hRegL,hPathL),(hRegR,hPathR)) (vPathU,vReg,vPathB)
  | hPathR == vPathU && hRegR == vReg = Just ((hRegL,hPathL),(hRegR,vPathB))
compHV _ _ = Nothing

-- compose [VCorr] and [RLink]
compHVs :: [RLink] -> [VCorr] -> [RLink]
compHVs hls vls = nub $ catMaybes [hl `compHV` vl | hl <- hls, vl <- vls]

filterEnv :: Path -> [RLink] -> [RLink]
filterEnv s = filter (\ (_ , (_,p)) -> isPrefix s p)

filterVLinkS :: Path -> [VCorr] -> [VCorr]
filterVLinkS p0 = filter (\ (p, _, _) -> isPrefix p0 p)

filterVLinkE :: Path -> [VCorr] -> [VCorr]
filterVLinkE p0 = filter (\ (_, _, p) -> isPrefix p0 p)

isPrefix :: Path -> Path -> Bool
isPrefix [] _ = True
isPrefix (s1:ss1) (s2:ss2) | s1 /= s2 = False
isPrefix (s1:ss1) (s2:ss2) | s1 == s2 = isPrefix ss1 ss2
isPrefix _ _ = False

-- delete the given prefix path from all links
delPathH :: (Path,Path) -> RLink -> RLink
delPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) =
  ((sReg,delPrefix sPre sp) , (vReg,delPrefix vPre vp))

delPrefix :: Path -> Path -> Path
delPrefix [] p = p
delPrefix s1 s2 = if isPrefix s1 s2 then drop (length s1) s2
  else error $ "the first input path is not a prefix of the second \n" ++
               "input path1: " ++ show s1 ++ "\n" ++ "input path2: " ++ show s2

addPathV :: (Path,Path) -> VLink -> VLink
addPathV (sPre1,sPre2) (sp1,sPat,sp2) = (sPre1 ++ sp1,sPat,sPre2 ++ sp2)

addPathH :: (Path,Path) -> RLink -> RLink
addPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) = ((sReg,sPre ++ sp) , (vReg,vPre ++ vp))

hasTopLink :: [RLink] -> Bool
hasTopLink = ([] `elem`) . map (snd . snd)

-- get links with empty view paths (link at the top)
-- return a Maybe real-link, a list of imaginary links (may be empty list), and remainings
-- to do so, we first sort the HLinks in the following order:
-- (3) : the links whose view-paths are empty come first
-- (2) : among (3), whose view-patterns is Void come first.
-- (1) : among (2), whose source-paths are smaller come first.
getTopLinks :: [RLink] -> (Maybe RLink, [RLink], [RLink])
getTopLinks hls =
  let (candidates3,rem3) = partition (\ (_,(_,vpath)) -> null vpath) hls
      -- rem2 should be either empty or singleton
      (candidates2,rem2) = partition (\ (_,(vRegion,_)) -> vRegion == Void) candidates3 
      candidates1 = sortBy cmpSPathRL candidates2
  in  case rem2 of
        []  -> (Nothing, candidates1, rem3)
        [r] -> (Just r, candidates1, rem3)

cmpSPathRL :: RLink -> RLink -> Ordering
cmpSPathRL ((_,sp1),_) ((_,sp2),_) = if sp1 < sp2 then LT
  else if sp1 == sp2 then EQ else GT

-- build vertical correspondence between an AST and itself, according to the given consitency links
-- do not use nub. nub will remove usefull links having the void region.
buildIdVCorr :: [RLink] -> [VCorr]
buildIdVCorr consisHLS = [(path2,pat2,path2) | ((pat1,path1) , (pat2,path2)) <- consisHLS]

apFst f (x,y) = (f x , y)


data Prod a b =
    Prod a b
  | ProdNull
  deriving (Show, Read, Eq, Data, Typeable)

data List a =
    Nil
  | Cons a (List a)
  | ListNull
  deriving (Show, Read, Eq, Data, Typeable)

data MMaybe a =
    NNothing
  | JJust a
  | MMaybeNull
  deriving (Show, Read, Eq, Data, Typeable)

data EEither a b =
    LLeft a
  | RRight b
  | EEitherNull
  deriving (Show, Read, Eq, Data, Typeable)

data UType =
    UInteger
  | UString
  | UBool
  | UVoid
  | UTypeNull
  deriving (Show, Read, Eq, Data, Typeable)

data ULit =
    UIntegerLit Integer
  | UStringLit String
  | UBoolLit Bool
  | ULitNull
  deriving (Show, Read, Eq, Data, Typeable)

data CompilationUnit =
    CompilationUnit (List TypeDeclaration)
  | CompilationUnitNull
  deriving (Show, Read, Eq, Data, Typeable)

data TypeDeclaration =
    FromClassDeclaration ClassDeclaration
  | TypeDeclarationSkip String
  | TypeDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassDeclaration =
    NormalClassDeclaration0 String String String String String ClassBody
  | NormalClassDeclaration1 String String String String String String ClassBody
  | NormalClassDeclaration2 String String String ClassBody
  | NormalClassDeclaration3 String String String String ClassBody
  | ClassDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassBody =
    ClassBody0 String String
  | ClassBody1 String (List ClassBodyDeclaration) String
  | ClassBodyNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassBodyDeclaration =
    FromClassMemberDeclaration ClassMemberDeclaration
  | FromInstanceInitializer (List BlockStatement)
  | ClassBodyDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data ClassMemberDeclaration =
    FieldDeclaration0 String UType VariableDeclarator String
  | FieldDeclaration1 String String UType VariableDeclarator String
  | MethodDeclaration0 String MethodHeader MethodBody
  | MethodDeclaration1 String String MethodHeader MethodBody
  | MemberFromClassDeclaration ClassDeclaration
  | ClassMemberDeclarationNull
  deriving (Show, Read, Eq, Data, Typeable)

data MethodHeader =
    MethodHeader (EEither UType String) MethodDeclarator
  | MethodHeaderNull
  deriving (Show, Read, Eq, Data, Typeable)

data MethodBody =
    MethodBody0 (List BlockStatement)
  | MethodBody1 String
  | MethodBodyNull
  deriving (Show, Read, Eq, Data, Typeable)

data MethodDeclarator =
    MethodDeclarator0 String String String
  | MethodDeclarator1 String String (Prod UType String) String
  | MethodDeclaratorNull
  deriving (Show, Read, Eq, Data, Typeable)

data BlockStatement =
    LocalVariableDeclaration UType VariableDeclarator
  | BlockFromClassDeclaration ClassDeclaration
  | FromStatement Statement
  | BlockStatementNull
  deriving (Show, Read, Eq, Data, Typeable)

data Statement =
    IfThenElse String String Expression String Statement String Statement
  | ExpressionStatement Expression String
  | While String String Expression String Statement
  | BasicFor String String (List BlockStatement) String Expression String (List Expression) String Statement
  | EnhancedFor String String UType String String Expression String Statement
  | FromBlockStatement (List BlockStatement)
  | StatementNull
  deriving (Show, Read, Eq, Data, Typeable)

data Expression =
    AssignExp Assignment
  | MethodInvocation0 String String String
  | MethodInvocation1 String String Expression String
  | ExpressionNull
  deriving (Show, Read, Eq, Data, Typeable)

data Assignment =
    Assignment String String Expression
  | FromRelExp RelExp
  | AssignmentNull
  deriving (Show, Read, Eq, Data, Typeable)

data VariableDeclarator =
    VariableDeclarator0 String
  | VariableDeclarator1 String VariableInitializer
  | VariableDeclaratorNull
  deriving (Show, Read, Eq, Data, Typeable)

data VariableInitializer =
    VariableInitializer String Expression
  | VariableInitializerNull
  deriving (Show, Read, Eq, Data, Typeable)

data RelExp =
    RelExp0 RelExp String PostfixExp
  | FromAdditiveExp AdditiveExp
  | RelExpNull
  deriving (Show, Read, Eq, Data, Typeable)

data AdditiveExp =
    AdditiveExp0 AdditiveExp String PostfixExp
  | AdditiveExp1 AdditiveExp String PostfixExp
  | FromPostfixExp PostfixExp
  | AdditiveExpNull
  deriving (Show, Read, Eq, Data, Typeable)

data PostfixExp =
    PostIncExp PostfixExp String
  | FromPrimary Primary
  | ExpN String
  | PostfixExpNull
  deriving (Show, Read, Eq, Data, Typeable)

data Primary =
    PrimaryLit ULit
  | Paren String Expression String
  | FieldAccess PostfixExp String String
  | ArrayAccess String String Expression String
  | PrimaryNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCCompilationUnit =
    JCCompilationUnit (List JCTree)
  | JCCompilationUnitNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCTree =
    FromJCExpression JCExpression
  | FromJCStatement JCStatement
  | FromJCModifier String
  | FromJCMethodDecl JCMethodDecl
  | JCTreeNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCExpression =
    FromJCPolyExpression JCPolyExpression
  | JCAssign JCExpression JCExpression
  | JCUnary Tag JCExpression String
  | JCBinary Tag JCExpression JCExpression String
  | JCArrayAccess JCExpression JCExpression
  | JCFieldAccess JCExpression String
  | JCIdent String
  | JCPrimitiveTypeTree UType
  | FromJCLiteral ULit
  | JCExpressionNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCPolyExpression =
    JCMethodInvocation (List JCExpression) JCExpression (MMaybe JCExpression)
  | JCPolyExpressionNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCStatement =
    FromJCClassDecl JCClassDecl
  | FromJCBlock (List JCStatement)
  | FromJCExpressionStatement JCExpression
  | FromJCVariableDecl JCVariableDecl
  | JCForLoop (List JCStatement) JCExpression (List JCExpression) JCStatement
  | JCIf JCExpression JCStatement JCStatement
  | JCSkip
  | JCStatementNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCClassDecl =
    JCClassDecl (MMaybe String) String (MMaybe JCExpression) (List JCTree)
  | JCClassDeclNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCVariableDecl =
    JCVariableDecl (MMaybe String) String JCExpression (MMaybe JCExpression)
  | JCVariableDeclNull
  deriving (Show, Read, Eq, Data, Typeable)

data JCMethodDecl =
    JCMethodDecl (MMaybe String) String JCExpression (MMaybe JCVariableDecl) (List JCStatement)
  | JCMethodDeclNull
  deriving (Show, Read, Eq, Data, Typeable)

data Tag =
    OR
  | LESSTHAN
  | POSTINC
  | PLUS
  | MINUS
  | TagNull
  deriving (Show, Read, Eq, Data, Typeable)

data TyTag
    = EEitherUTypeStringTag
    | ListAssignmentTag
    | ListBlockStatementTag
    | ListClassBodyDeclarationTag
    | ListExpressionTag
    | ListJCExpressionTag
    | ListJCStatementTag
    | ListJCTreeTag
    | ListTypeDeclarationTag
    | MMaybeJCExpressionTag
    | MMaybeJCVariableDeclTag
    | MMaybeStringTag
    | ProdUTypeStringTag
    | UTypeTag
    | ULitTag
    | CompilationUnitTag
    | TypeDeclarationTag
    | ClassDeclarationTag
    | ClassBodyTag
    | ClassBodyDeclarationTag
    | ClassMemberDeclarationTag
    | MethodHeaderTag
    | MethodBodyTag
    | MethodDeclaratorTag
    | BlockStatementTag
    | StatementTag
    | ExpressionTag
    | AssignmentTag
    | VariableDeclaratorTag
    | VariableInitializerTag
    | RelExpTag
    | AdditiveExpTag
    | PostfixExpTag
    | PrimaryTag
    | JCCompilationUnitTag
    | JCTreeTag
    | JCExpressionTag
    | JCPolyExpressionTag
    | JCStatementTag
    | JCClassDeclTag
    | JCVariableDeclTag
    | JCMethodDeclTag
    | TagTag
    | IntegerTag
    | StringTag
    | CharTag
    | BoolTag
    deriving (Eq, Show)

class TypeTag a
    where tyTag :: a -> TyTag

instance TypeTag Integer
    where tyTag _ = IntegerTag
instance TypeTag String
    where tyTag _ = StringTag
instance TypeTag Char
    where tyTag _ = CharTag
instance TypeTag Bool
    where tyTag _ = BoolTag
instance TypeTag ( EEither UType String )
    where tyTag EEitherNull = EEitherUTypeStringTag
          tyTag (LLeft _) = EEitherUTypeStringTag
          tyTag (RRight _) = EEitherUTypeStringTag
instance TypeTag ( List Assignment )
    where tyTag ListNull = ListAssignmentTag
          tyTag (Nil) = ListAssignmentTag
          tyTag (Cons _ _) = ListAssignmentTag
instance TypeTag ( List BlockStatement )
    where tyTag ListNull = ListBlockStatementTag
          tyTag (Nil) = ListBlockStatementTag
          tyTag (Cons _ _) = ListBlockStatementTag
instance TypeTag ( List ClassBodyDeclaration )
    where tyTag ListNull = ListClassBodyDeclarationTag
          tyTag (Nil) = ListClassBodyDeclarationTag
          tyTag (Cons _ _) = ListClassBodyDeclarationTag
instance TypeTag ( List Expression )
    where tyTag ListNull = ListExpressionTag
          tyTag (Nil) = ListExpressionTag
          tyTag (Cons _ _) = ListExpressionTag
instance TypeTag ( List JCExpression )
    where tyTag ListNull = ListJCExpressionTag
          tyTag (Nil) = ListJCExpressionTag
          tyTag (Cons _ _) = ListJCExpressionTag
instance TypeTag ( List JCStatement )
    where tyTag ListNull = ListJCStatementTag
          tyTag (Nil) = ListJCStatementTag
          tyTag (Cons _ _) = ListJCStatementTag
instance TypeTag ( List JCTree )
    where tyTag ListNull = ListJCTreeTag
          tyTag (Nil) = ListJCTreeTag
          tyTag (Cons _ _) = ListJCTreeTag
instance TypeTag ( List TypeDeclaration )
    where tyTag ListNull = ListTypeDeclarationTag
          tyTag (Nil) = ListTypeDeclarationTag
          tyTag (Cons _ _) = ListTypeDeclarationTag
instance TypeTag ( MMaybe JCExpression )
    where tyTag MMaybeNull = MMaybeJCExpressionTag
          tyTag (NNothing) = MMaybeJCExpressionTag
          tyTag (JJust _) = MMaybeJCExpressionTag
instance TypeTag ( MMaybe JCVariableDecl )
    where tyTag MMaybeNull = MMaybeJCVariableDeclTag
          tyTag (NNothing) = MMaybeJCVariableDeclTag
          tyTag (JJust _) = MMaybeJCVariableDeclTag
instance TypeTag ( MMaybe String )
    where tyTag MMaybeNull = MMaybeStringTag
          tyTag (NNothing) = MMaybeStringTag
          tyTag (JJust _) = MMaybeStringTag
instance TypeTag ( Prod UType String )
    where tyTag ProdNull = ProdUTypeStringTag
          tyTag (Prod _ _) = ProdUTypeStringTag
instance TypeTag UType
    where tyTag UTypeNull = UTypeTag
          tyTag (UInteger) = UTypeTag
          tyTag (UString) = UTypeTag
          tyTag (UBool) = UTypeTag
          tyTag (UVoid) = UTypeTag
instance TypeTag ULit
    where tyTag ULitNull = ULitTag
          tyTag (UIntegerLit _) = ULitTag
          tyTag (UStringLit _) = ULitTag
          tyTag (UBoolLit _) = ULitTag
instance TypeTag CompilationUnit
    where tyTag CompilationUnitNull = CompilationUnitTag
          tyTag (CompilationUnit _) = CompilationUnitTag
instance TypeTag TypeDeclaration
    where tyTag TypeDeclarationNull = TypeDeclarationTag
          tyTag (FromClassDeclaration _) = TypeDeclarationTag
          tyTag (TypeDeclarationSkip _) = TypeDeclarationTag
instance TypeTag ClassDeclaration
    where tyTag ClassDeclarationNull = ClassDeclarationTag
          tyTag (NormalClassDeclaration0 _ _ _ _ _ _) = ClassDeclarationTag
          tyTag (NormalClassDeclaration1 _ _ _ _ _ _ _) = ClassDeclarationTag
          tyTag (NormalClassDeclaration2 _ _ _ _) = ClassDeclarationTag
          tyTag (NormalClassDeclaration3 _ _ _ _ _) = ClassDeclarationTag
instance TypeTag ClassBody
    where tyTag ClassBodyNull = ClassBodyTag
          tyTag (ClassBody0 _ _) = ClassBodyTag
          tyTag (ClassBody1 _ _ _) = ClassBodyTag
instance TypeTag ClassBodyDeclaration
    where tyTag ClassBodyDeclarationNull = ClassBodyDeclarationTag
          tyTag (FromClassMemberDeclaration _) = ClassBodyDeclarationTag
          tyTag (FromInstanceInitializer _) = ClassBodyDeclarationTag
instance TypeTag ClassMemberDeclaration
    where tyTag ClassMemberDeclarationNull = ClassMemberDeclarationTag
          tyTag (FieldDeclaration0 _ _ _ _) = ClassMemberDeclarationTag
          tyTag (FieldDeclaration1 _ _ _ _ _) = ClassMemberDeclarationTag
          tyTag (MethodDeclaration0 _ _ _) = ClassMemberDeclarationTag
          tyTag (MethodDeclaration1 _ _ _ _) = ClassMemberDeclarationTag
          tyTag (MemberFromClassDeclaration _) = ClassMemberDeclarationTag
instance TypeTag MethodHeader
    where tyTag MethodHeaderNull = MethodHeaderTag
          tyTag (MethodHeader _ _) = MethodHeaderTag
instance TypeTag MethodBody
    where tyTag MethodBodyNull = MethodBodyTag
          tyTag (MethodBody0 _) = MethodBodyTag
          tyTag (MethodBody1 _) = MethodBodyTag
instance TypeTag MethodDeclarator
    where tyTag MethodDeclaratorNull = MethodDeclaratorTag
          tyTag (MethodDeclarator0 _ _ _) = MethodDeclaratorTag
          tyTag (MethodDeclarator1 _ _ _ _) = MethodDeclaratorTag
instance TypeTag BlockStatement
    where tyTag BlockStatementNull = BlockStatementTag
          tyTag (LocalVariableDeclaration _ _) = BlockStatementTag
          tyTag (BlockFromClassDeclaration _) = BlockStatementTag
          tyTag (FromStatement _) = BlockStatementTag
instance TypeTag Statement
    where tyTag StatementNull = StatementTag
          tyTag (IfThenElse _ _ _ _ _ _ _) = StatementTag
          tyTag (ExpressionStatement _ _) = StatementTag
          tyTag (While _ _ _ _ _) = StatementTag
          tyTag (BasicFor _ _ _ _ _ _ _ _ _) = StatementTag
          tyTag (EnhancedFor _ _ _ _ _ _ _ _) = StatementTag
          tyTag (FromBlockStatement _) = StatementTag
instance TypeTag Expression
    where tyTag ExpressionNull = ExpressionTag
          tyTag (AssignExp _) = ExpressionTag
          tyTag (MethodInvocation0 _ _ _) = ExpressionTag
          tyTag (MethodInvocation1 _ _ _ _) = ExpressionTag
instance TypeTag Assignment
    where tyTag AssignmentNull = AssignmentTag
          tyTag (Assignment _ _ _) = AssignmentTag
          tyTag (FromRelExp _) = AssignmentTag
instance TypeTag VariableDeclarator
    where tyTag VariableDeclaratorNull = VariableDeclaratorTag
          tyTag (VariableDeclarator0 _) = VariableDeclaratorTag
          tyTag (VariableDeclarator1 _ _) = VariableDeclaratorTag
instance TypeTag VariableInitializer
    where tyTag VariableInitializerNull = VariableInitializerTag
          tyTag (VariableInitializer _ _) = VariableInitializerTag
instance TypeTag RelExp
    where tyTag RelExpNull = RelExpTag
          tyTag (RelExp0 _ _ _) = RelExpTag
          tyTag (FromAdditiveExp _) = RelExpTag
instance TypeTag AdditiveExp
    where tyTag AdditiveExpNull = AdditiveExpTag
          tyTag (AdditiveExp0 _ _ _) = AdditiveExpTag
          tyTag (AdditiveExp1 _ _ _) = AdditiveExpTag
          tyTag (FromPostfixExp _) = AdditiveExpTag
instance TypeTag PostfixExp
    where tyTag PostfixExpNull = PostfixExpTag
          tyTag (PostIncExp _ _) = PostfixExpTag
          tyTag (FromPrimary _) = PostfixExpTag
          tyTag (ExpN _) = PostfixExpTag
instance TypeTag Primary
    where tyTag PrimaryNull = PrimaryTag
          tyTag (PrimaryLit _) = PrimaryTag
          tyTag (Paren _ _ _) = PrimaryTag
          tyTag (FieldAccess _ _ _) = PrimaryTag
          tyTag (ArrayAccess _ _ _ _) = PrimaryTag
instance TypeTag JCCompilationUnit
    where tyTag JCCompilationUnitNull = JCCompilationUnitTag
          tyTag (JCCompilationUnit _) = JCCompilationUnitTag
instance TypeTag JCTree
    where tyTag JCTreeNull = JCTreeTag
          tyTag (FromJCExpression _) = JCTreeTag
          tyTag (FromJCStatement _) = JCTreeTag
          tyTag (FromJCModifier _) = JCTreeTag
          tyTag (FromJCMethodDecl _) = JCTreeTag
instance TypeTag JCExpression
    where tyTag JCExpressionNull = JCExpressionTag
          tyTag (FromJCPolyExpression _) = JCExpressionTag
          tyTag (JCAssign _ _) = JCExpressionTag
          tyTag (JCUnary _ _ _) = JCExpressionTag
          tyTag (JCBinary _ _ _ _) = JCExpressionTag
          tyTag (JCArrayAccess _ _) = JCExpressionTag
          tyTag (JCFieldAccess _ _) = JCExpressionTag
          tyTag (JCIdent _) = JCExpressionTag
          tyTag (JCPrimitiveTypeTree _) = JCExpressionTag
          tyTag (FromJCLiteral _) = JCExpressionTag
instance TypeTag JCPolyExpression
    where tyTag JCPolyExpressionNull = JCPolyExpressionTag
          tyTag (JCMethodInvocation _ _ _) = JCPolyExpressionTag
instance TypeTag JCStatement
    where tyTag JCStatementNull = JCStatementTag
          tyTag (FromJCClassDecl _) = JCStatementTag
          tyTag (FromJCBlock _) = JCStatementTag
          tyTag (FromJCExpressionStatement _) = JCStatementTag
          tyTag (FromJCVariableDecl _) = JCStatementTag
          tyTag (JCForLoop _ _ _ _) = JCStatementTag
          tyTag (JCIf _ _ _) = JCStatementTag
          tyTag (JCSkip) = JCStatementTag
instance TypeTag JCClassDecl
    where tyTag JCClassDeclNull = JCClassDeclTag
          tyTag (JCClassDecl _ _ _ _) = JCClassDeclTag
instance TypeTag JCVariableDecl
    where tyTag JCVariableDeclNull = JCVariableDeclTag
          tyTag (JCVariableDecl _ _ _ _) = JCVariableDeclTag
instance TypeTag JCMethodDecl
    where tyTag JCMethodDeclNull = JCMethodDeclTag
          tyTag (JCMethodDecl _ _ _ _ _) = JCMethodDeclTag
instance TypeTag Tag
    where tyTag TagNull = TagTag
          tyTag (OR) = TagTag
          tyTag (LESSTHAN) = TagTag
          tyTag (POSTINC) = TagTag
          tyTag (PLUS) = TagTag
          tyTag (MINUS) = TagTag

class Fetchable a
    where fetch :: Path -> a -> Dynamic

instance Fetchable Integer
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Integer"
instance Fetchable String
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a String"
instance Fetchable Char
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Char"
instance Fetchable Bool
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Bool"
instance ( Fetchable a , Typeable a , Fetchable b , Typeable b ) => Fetchable ( Prod a b )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Prod t0 _ , (0)) -> fetch ps t0
                                   (Prod _ t1 , (1)) -> fetch ps t1
instance ( Fetchable a , Typeable a ) => Fetchable ( List a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Cons t0 _ , (0)) -> fetch ps t0
                                   (Cons _ t1 , (1)) -> fetch ps t1
instance ( Fetchable a , Typeable a ) => Fetchable ( MMaybe a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (JJust t0 , (0)) -> fetch ps t0
instance ( Fetchable a , Typeable a , Fetchable b , Typeable b ) => Fetchable ( EEither a b )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (LLeft t0 , (0)) -> fetch ps t0
                                   (RRight t0 , (0)) -> fetch ps t0
instance Fetchable UType
    where fetch [] src = toDyn src
          fetch (p : ps) src = (error $ "path too long.")
instance Fetchable ULit
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (UIntegerLit t0 , (0)) -> fetch ps t0
                                   (UStringLit t0 , (0)) -> fetch ps t0
                                   (UBoolLit t0 , (0)) -> fetch ps t0
instance Fetchable CompilationUnit
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (CompilationUnit t0 , (0)) -> fetch ps t0
instance Fetchable TypeDeclaration
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (FromClassDeclaration t0 , (0)) -> fetch ps t0
                                   (TypeDeclarationSkip t0 , (0)) -> fetch ps t0
instance Fetchable ClassDeclaration
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (NormalClassDeclaration0 t0 _ _ _ _ _ , (0)) -> fetch ps t0
                                   (NormalClassDeclaration0 _ t1 _ _ _ _ , (1)) -> fetch ps t1
                                   (NormalClassDeclaration0 _ _ t2 _ _ _ , (2)) -> fetch ps t2
                                   (NormalClassDeclaration0 _ _ _ t3 _ _ , (3)) -> fetch ps t3
                                   (NormalClassDeclaration0 _ _ _ _ t4 _ , (4)) -> fetch ps t4
                                   (NormalClassDeclaration0 _ _ _ _ _ t5 , (5)) -> fetch ps t5
                                   (NormalClassDeclaration1 t0 _ _ _ _ _ _ , (0)) -> fetch ps t0
                                   (NormalClassDeclaration1 _ t1 _ _ _ _ _ , (1)) -> fetch ps t1
                                   (NormalClassDeclaration1 _ _ t2 _ _ _ _ , (2)) -> fetch ps t2
                                   (NormalClassDeclaration1 _ _ _ t3 _ _ _ , (3)) -> fetch ps t3
                                   (NormalClassDeclaration1 _ _ _ _ t4 _ _ , (4)) -> fetch ps t4
                                   (NormalClassDeclaration1 _ _ _ _ _ t5 _ , (5)) -> fetch ps t5
                                   (NormalClassDeclaration1 _ _ _ _ _ _ t6 , (6)) -> fetch ps t6
                                   (NormalClassDeclaration2 t0 _ _ _ , (0)) -> fetch ps t0
                                   (NormalClassDeclaration2 _ t1 _ _ , (1)) -> fetch ps t1
                                   (NormalClassDeclaration2 _ _ t2 _ , (2)) -> fetch ps t2
                                   (NormalClassDeclaration2 _ _ _ t3 , (3)) -> fetch ps t3
                                   (NormalClassDeclaration3 t0 _ _ _ _ , (0)) -> fetch ps t0
                                   (NormalClassDeclaration3 _ t1 _ _ _ , (1)) -> fetch ps t1
                                   (NormalClassDeclaration3 _ _ t2 _ _ , (2)) -> fetch ps t2
                                   (NormalClassDeclaration3 _ _ _ t3 _ , (3)) -> fetch ps t3
                                   (NormalClassDeclaration3 _ _ _ _ t4 , (4)) -> fetch ps t4
instance Fetchable ClassBody
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (ClassBody0 t0 _ , (0)) -> fetch ps t0
                                   (ClassBody0 _ t1 , (1)) -> fetch ps t1
                                   (ClassBody1 t0 _ _ , (0)) -> fetch ps t0
                                   (ClassBody1 _ t1 _ , (1)) -> fetch ps t1
                                   (ClassBody1 _ _ t2 , (2)) -> fetch ps t2
instance Fetchable ClassBodyDeclaration
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (FromClassMemberDeclaration t0 , (0)) -> fetch ps t0
                                   (FromInstanceInitializer t0 , (0)) -> fetch ps t0
instance Fetchable ClassMemberDeclaration
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (FieldDeclaration0 t0 _ _ _ , (0)) -> fetch ps t0
                                   (FieldDeclaration0 _ t1 _ _ , (1)) -> fetch ps t1
                                   (FieldDeclaration0 _ _ t2 _ , (2)) -> fetch ps t2
                                   (FieldDeclaration0 _ _ _ t3 , (3)) -> fetch ps t3
                                   (FieldDeclaration1 t0 _ _ _ _ , (0)) -> fetch ps t0
                                   (FieldDeclaration1 _ t1 _ _ _ , (1)) -> fetch ps t1
                                   (FieldDeclaration1 _ _ t2 _ _ , (2)) -> fetch ps t2
                                   (FieldDeclaration1 _ _ _ t3 _ , (3)) -> fetch ps t3
                                   (FieldDeclaration1 _ _ _ _ t4 , (4)) -> fetch ps t4
                                   (MethodDeclaration0 t0 _ _ , (0)) -> fetch ps t0
                                   (MethodDeclaration0 _ t1 _ , (1)) -> fetch ps t1
                                   (MethodDeclaration0 _ _ t2 , (2)) -> fetch ps t2
                                   (MethodDeclaration1 t0 _ _ _ , (0)) -> fetch ps t0
                                   (MethodDeclaration1 _ t1 _ _ , (1)) -> fetch ps t1
                                   (MethodDeclaration1 _ _ t2 _ , (2)) -> fetch ps t2
                                   (MethodDeclaration1 _ _ _ t3 , (3)) -> fetch ps t3
                                   (MemberFromClassDeclaration t0 , (0)) -> fetch ps t0
instance Fetchable MethodHeader
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (MethodHeader t0 _ , (0)) -> fetch ps t0
                                   (MethodHeader _ t1 , (1)) -> fetch ps t1
instance Fetchable MethodBody
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (MethodBody0 t0 , (0)) -> fetch ps t0
                                   (MethodBody1 t0 , (0)) -> fetch ps t0
instance Fetchable MethodDeclarator
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (MethodDeclarator0 t0 _ _ , (0)) -> fetch ps t0
                                   (MethodDeclarator0 _ t1 _ , (1)) -> fetch ps t1
                                   (MethodDeclarator0 _ _ t2 , (2)) -> fetch ps t2
                                   (MethodDeclarator1 t0 _ _ _ , (0)) -> fetch ps t0
                                   (MethodDeclarator1 _ t1 _ _ , (1)) -> fetch ps t1
                                   (MethodDeclarator1 _ _ t2 _ , (2)) -> fetch ps t2
                                   (MethodDeclarator1 _ _ _ t3 , (3)) -> fetch ps t3
instance Fetchable BlockStatement
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (LocalVariableDeclaration t0 _ , (0)) -> fetch ps t0
                                   (LocalVariableDeclaration _ t1 , (1)) -> fetch ps t1
                                   (BlockFromClassDeclaration t0 , (0)) -> fetch ps t0
                                   (FromStatement t0 , (0)) -> fetch ps t0
instance Fetchable Statement
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (IfThenElse t0 _ _ _ _ _ _ , (0)) -> fetch ps t0
                                   (IfThenElse _ t1 _ _ _ _ _ , (1)) -> fetch ps t1
                                   (IfThenElse _ _ t2 _ _ _ _ , (2)) -> fetch ps t2
                                   (IfThenElse _ _ _ t3 _ _ _ , (3)) -> fetch ps t3
                                   (IfThenElse _ _ _ _ t4 _ _ , (4)) -> fetch ps t4
                                   (IfThenElse _ _ _ _ _ t5 _ , (5)) -> fetch ps t5
                                   (IfThenElse _ _ _ _ _ _ t6 , (6)) -> fetch ps t6
                                   (ExpressionStatement t0 _ , (0)) -> fetch ps t0
                                   (ExpressionStatement _ t1 , (1)) -> fetch ps t1
                                   (While t0 _ _ _ _ , (0)) -> fetch ps t0
                                   (While _ t1 _ _ _ , (1)) -> fetch ps t1
                                   (While _ _ t2 _ _ , (2)) -> fetch ps t2
                                   (While _ _ _ t3 _ , (3)) -> fetch ps t3
                                   (While _ _ _ _ t4 , (4)) -> fetch ps t4
                                   (BasicFor t0 _ _ _ _ _ _ _ _ , (0)) -> fetch ps t0
                                   (BasicFor _ t1 _ _ _ _ _ _ _ , (1)) -> fetch ps t1
                                   (BasicFor _ _ t2 _ _ _ _ _ _ , (2)) -> fetch ps t2
                                   (BasicFor _ _ _ t3 _ _ _ _ _ , (3)) -> fetch ps t3
                                   (BasicFor _ _ _ _ t4 _ _ _ _ , (4)) -> fetch ps t4
                                   (BasicFor _ _ _ _ _ t5 _ _ _ , (5)) -> fetch ps t5
                                   (BasicFor _ _ _ _ _ _ t6 _ _ , (6)) -> fetch ps t6
                                   (BasicFor _ _ _ _ _ _ _ t7 _ , (7)) -> fetch ps t7
                                   (BasicFor _ _ _ _ _ _ _ _ t8 , (8)) -> fetch ps t8
                                   (EnhancedFor t0 _ _ _ _ _ _ _ , (0)) -> fetch ps t0
                                   (EnhancedFor _ t1 _ _ _ _ _ _ , (1)) -> fetch ps t1
                                   (EnhancedFor _ _ t2 _ _ _ _ _ , (2)) -> fetch ps t2
                                   (EnhancedFor _ _ _ t3 _ _ _ _ , (3)) -> fetch ps t3
                                   (EnhancedFor _ _ _ _ t4 _ _ _ , (4)) -> fetch ps t4
                                   (EnhancedFor _ _ _ _ _ t5 _ _ , (5)) -> fetch ps t5
                                   (EnhancedFor _ _ _ _ _ _ t6 _ , (6)) -> fetch ps t6
                                   (EnhancedFor _ _ _ _ _ _ _ t7 , (7)) -> fetch ps t7
                                   (FromBlockStatement t0 , (0)) -> fetch ps t0
instance Fetchable Expression
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (AssignExp t0 , (0)) -> fetch ps t0
                                   (MethodInvocation0 t0 _ _ , (0)) -> fetch ps t0
                                   (MethodInvocation0 _ t1 _ , (1)) -> fetch ps t1
                                   (MethodInvocation0 _ _ t2 , (2)) -> fetch ps t2
                                   (MethodInvocation1 t0 _ _ _ , (0)) -> fetch ps t0
                                   (MethodInvocation1 _ t1 _ _ , (1)) -> fetch ps t1
                                   (MethodInvocation1 _ _ t2 _ , (2)) -> fetch ps t2
                                   (MethodInvocation1 _ _ _ t3 , (3)) -> fetch ps t3
instance Fetchable Assignment
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Assignment t0 _ _ , (0)) -> fetch ps t0
                                   (Assignment _ t1 _ , (1)) -> fetch ps t1
                                   (Assignment _ _ t2 , (2)) -> fetch ps t2
                                   (FromRelExp t0 , (0)) -> fetch ps t0
instance Fetchable VariableDeclarator
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (VariableDeclarator0 t0 , (0)) -> fetch ps t0
                                   (VariableDeclarator1 t0 _ , (0)) -> fetch ps t0
                                   (VariableDeclarator1 _ t1 , (1)) -> fetch ps t1
instance Fetchable VariableInitializer
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (VariableInitializer t0 _ , (0)) -> fetch ps t0
                                   (VariableInitializer _ t1 , (1)) -> fetch ps t1
instance Fetchable RelExp
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (RelExp0 t0 _ _ , (0)) -> fetch ps t0
                                   (RelExp0 _ t1 _ , (1)) -> fetch ps t1
                                   (RelExp0 _ _ t2 , (2)) -> fetch ps t2
                                   (FromAdditiveExp t0 , (0)) -> fetch ps t0
instance Fetchable AdditiveExp
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (AdditiveExp0 t0 _ _ , (0)) -> fetch ps t0
                                   (AdditiveExp0 _ t1 _ , (1)) -> fetch ps t1
                                   (AdditiveExp0 _ _ t2 , (2)) -> fetch ps t2
                                   (AdditiveExp1 t0 _ _ , (0)) -> fetch ps t0
                                   (AdditiveExp1 _ t1 _ , (1)) -> fetch ps t1
                                   (AdditiveExp1 _ _ t2 , (2)) -> fetch ps t2
                                   (FromPostfixExp t0 , (0)) -> fetch ps t0
instance Fetchable PostfixExp
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (PostIncExp t0 _ , (0)) -> fetch ps t0
                                   (PostIncExp _ t1 , (1)) -> fetch ps t1
                                   (FromPrimary t0 , (0)) -> fetch ps t0
                                   (ExpN t0 , (0)) -> fetch ps t0
instance Fetchable Primary
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (PrimaryLit t0 , (0)) -> fetch ps t0
                                   (Paren t0 _ _ , (0)) -> fetch ps t0
                                   (Paren _ t1 _ , (1)) -> fetch ps t1
                                   (Paren _ _ t2 , (2)) -> fetch ps t2
                                   (FieldAccess t0 _ _ , (0)) -> fetch ps t0
                                   (FieldAccess _ t1 _ , (1)) -> fetch ps t1
                                   (FieldAccess _ _ t2 , (2)) -> fetch ps t2
                                   (ArrayAccess t0 _ _ _ , (0)) -> fetch ps t0
                                   (ArrayAccess _ t1 _ _ , (1)) -> fetch ps t1
                                   (ArrayAccess _ _ t2 _ , (2)) -> fetch ps t2
                                   (ArrayAccess _ _ _ t3 , (3)) -> fetch ps t3
instance Fetchable JCCompilationUnit
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (JCCompilationUnit t0 , (0)) -> fetch ps t0
instance Fetchable JCTree
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (FromJCExpression t0 , (0)) -> fetch ps t0
                                   (FromJCStatement t0 , (0)) -> fetch ps t0
                                   (FromJCModifier t0 , (0)) -> fetch ps t0
                                   (FromJCMethodDecl t0 , (0)) -> fetch ps t0
instance Fetchable JCExpression
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (FromJCPolyExpression t0 , (0)) -> fetch ps t0
                                   (JCAssign t0 _ , (0)) -> fetch ps t0
                                   (JCAssign _ t1 , (1)) -> fetch ps t1
                                   (JCUnary t0 _ _ , (0)) -> fetch ps t0
                                   (JCUnary _ t1 _ , (1)) -> fetch ps t1
                                   (JCUnary _ _ t2 , (2)) -> fetch ps t2
                                   (JCBinary t0 _ _ _ , (0)) -> fetch ps t0
                                   (JCBinary _ t1 _ _ , (1)) -> fetch ps t1
                                   (JCBinary _ _ t2 _ , (2)) -> fetch ps t2
                                   (JCBinary _ _ _ t3 , (3)) -> fetch ps t3
                                   (JCArrayAccess t0 _ , (0)) -> fetch ps t0
                                   (JCArrayAccess _ t1 , (1)) -> fetch ps t1
                                   (JCFieldAccess t0 _ , (0)) -> fetch ps t0
                                   (JCFieldAccess _ t1 , (1)) -> fetch ps t1
                                   (JCIdent t0 , (0)) -> fetch ps t0
                                   (JCPrimitiveTypeTree t0 , (0)) -> fetch ps t0
                                   (FromJCLiteral t0 , (0)) -> fetch ps t0
instance Fetchable JCPolyExpression
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (JCMethodInvocation t0 _ _ , (0)) -> fetch ps t0
                                   (JCMethodInvocation _ t1 _ , (1)) -> fetch ps t1
                                   (JCMethodInvocation _ _ t2 , (2)) -> fetch ps t2
instance Fetchable JCStatement
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (FromJCClassDecl t0 , (0)) -> fetch ps t0
                                   (FromJCBlock t0 , (0)) -> fetch ps t0
                                   (FromJCExpressionStatement t0 , (0)) -> fetch ps t0
                                   (FromJCVariableDecl t0 , (0)) -> fetch ps t0
                                   (JCForLoop t0 _ _ _ , (0)) -> fetch ps t0
                                   (JCForLoop _ t1 _ _ , (1)) -> fetch ps t1
                                   (JCForLoop _ _ t2 _ , (2)) -> fetch ps t2
                                   (JCForLoop _ _ _ t3 , (3)) -> fetch ps t3
                                   (JCIf t0 _ _ , (0)) -> fetch ps t0
                                   (JCIf _ t1 _ , (1)) -> fetch ps t1
                                   (JCIf _ _ t2 , (2)) -> fetch ps t2
instance Fetchable JCClassDecl
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (JCClassDecl t0 _ _ _ , (0)) -> fetch ps t0
                                   (JCClassDecl _ t1 _ _ , (1)) -> fetch ps t1
                                   (JCClassDecl _ _ t2 _ , (2)) -> fetch ps t2
                                   (JCClassDecl _ _ _ t3 , (3)) -> fetch ps t3
instance Fetchable JCVariableDecl
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (JCVariableDecl t0 _ _ _ , (0)) -> fetch ps t0
                                   (JCVariableDecl _ t1 _ _ , (1)) -> fetch ps t1
                                   (JCVariableDecl _ _ t2 _ , (2)) -> fetch ps t2
                                   (JCVariableDecl _ _ _ t3 , (3)) -> fetch ps t3
instance Fetchable JCMethodDecl
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (JCMethodDecl t0 _ _ _ _ , (0)) -> fetch ps t0
                                   (JCMethodDecl _ t1 _ _ _ , (1)) -> fetch ps t1
                                   (JCMethodDecl _ _ t2 _ _ , (2)) -> fetch ps t2
                                   (JCMethodDecl _ _ _ t3 _ , (3)) -> fetch ps t3
                                   (JCMethodDecl _ _ _ _ t4 , (4)) -> fetch ps t4
instance Fetchable Tag
    where fetch [] src = toDyn src
          fetch (p : ps) src = (error $ "path too long.")

fetch' :: OSTyTag -> OSDyn -> RLink -> SDyn
fetch' CompilationUnitTag ((fromDynamic :: Dynamic ->
                                           Maybe CompilationUnit) -> Just os) l = let ((sReg,
                                                                                        sPath),
                                                                                       (_, [])) = l
                                                                                   in fetch sPath os
fetch' JCCompilationUnitTag ((fromDynamic :: Dynamic ->
                                             Maybe JCCompilationUnit) -> Just os) l = let ((sReg,
                                                                                            sPath),
                                                                                           (_,
                                                                                            [])) = l
                                                                                       in fetch sPath os
fetch' TypeDeclarationTag ((fromDynamic :: Dynamic ->
                                           Maybe TypeDeclaration) -> Just os) l = let ((sReg,
                                                                                        sPath),
                                                                                       (_, [])) = l
                                                                                   in fetch sPath os
fetch' JCTreeTag ((fromDynamic :: Dynamic ->
                                  Maybe JCTree) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' ClassDeclarationTag ((fromDynamic :: Dynamic ->
                                            Maybe ClassDeclaration) -> Just os) l = let ((sReg,
                                                                                          sPath),
                                                                                         (_,
                                                                                          [])) = l
                                                                                     in fetch sPath os
fetch' ClassBodyTag ((fromDynamic :: Dynamic ->
                                     Maybe ClassBody) -> Just os) l = let ((sReg, sPath),
                                                                           (_, [])) = l
                                                                       in fetch sPath os
fetch' ListJCTreeTag ((fromDynamic :: Dynamic ->
                                      Maybe ( List JCTree )) -> Just os) l = let ((sReg, sPath),
                                                                                  (_, [])) = l
                                                                              in fetch sPath os
fetch' ClassBodyDeclarationTag ((fromDynamic :: Dynamic ->
                                                Maybe ClassBodyDeclaration) -> Just os) l = let ((sReg,
                                                                                                  sPath),
                                                                                                 (_,
                                                                                                  [])) = l
                                                                                             in fetch sPath os
fetch' ClassMemberDeclarationTag ((fromDynamic :: Dynamic ->
                                                  Maybe ClassMemberDeclaration) -> Just os) l = let ((sReg,
                                                                                                      sPath),
                                                                                                     (_,
                                                                                                      [])) = l
                                                                                                 in fetch sPath os
fetch' EEitherUTypeStringTag ((fromDynamic :: Dynamic ->
                                              Maybe ( EEither UType String )) -> Just os) l = let ((sReg,
                                                                                                    sPath),
                                                                                                   (_,
                                                                                                    [])) = l
                                                                                               in fetch sPath os
fetch' JCExpressionTag ((fromDynamic :: Dynamic ->
                                        Maybe JCExpression) -> Just os) l = let ((sReg, sPath),
                                                                                 (_, [])) = l
                                                                             in fetch sPath os
fetch' ProdUTypeStringTag ((fromDynamic :: Dynamic ->
                                           Maybe ( Prod UType String )) -> Just os) l = let ((sReg,
                                                                                              sPath),
                                                                                             (_,
                                                                                              [])) = l
                                                                                         in fetch sPath os
fetch' JCVariableDeclTag ((fromDynamic :: Dynamic ->
                                          Maybe JCVariableDecl) -> Just os) l = let ((sReg, sPath),
                                                                                     (_, [])) = l
                                                                                 in fetch sPath os
fetch' MethodBodyTag ((fromDynamic :: Dynamic ->
                                      Maybe MethodBody) -> Just os) l = let ((sReg, sPath),
                                                                             (_, [])) = l
                                                                         in fetch sPath os
fetch' ListJCStatementTag ((fromDynamic :: Dynamic ->
                                           Maybe ( List JCStatement )) -> Just os) l = let ((sReg,
                                                                                             sPath),
                                                                                            (_,
                                                                                             [])) = l
                                                                                        in fetch sPath os
fetch' BlockStatementTag ((fromDynamic :: Dynamic ->
                                          Maybe BlockStatement) -> Just os) l = let ((sReg, sPath),
                                                                                     (_, [])) = l
                                                                                 in fetch sPath os
fetch' JCStatementTag ((fromDynamic :: Dynamic ->
                                       Maybe JCStatement) -> Just os) l = let ((sReg, sPath),
                                                                               (_, [])) = l
                                                                           in fetch sPath os
fetch' JCClassDeclTag ((fromDynamic :: Dynamic ->
                                       Maybe JCClassDecl) -> Just os) l = let ((sReg, sPath),
                                                                               (_, [])) = l
                                                                           in fetch sPath os
fetch' ExpressionTag ((fromDynamic :: Dynamic ->
                                      Maybe Expression) -> Just os) l = let ((sReg, sPath),
                                                                             (_, [])) = l
                                                                         in fetch sPath os
fetch' StatementTag ((fromDynamic :: Dynamic ->
                                     Maybe Statement) -> Just os) l = let ((sReg, sPath),
                                                                           (_, [])) = l
                                                                       in fetch sPath os
fetch' AssignmentTag ((fromDynamic :: Dynamic ->
                                      Maybe Assignment) -> Just os) l = let ((sReg, sPath),
                                                                             (_, [])) = l
                                                                         in fetch sPath os
fetch' RelExpTag ((fromDynamic :: Dynamic ->
                                  Maybe RelExp) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' AdditiveExpTag ((fromDynamic :: Dynamic ->
                                       Maybe AdditiveExp) -> Just os) l = let ((sReg, sPath),
                                                                               (_, [])) = l
                                                                           in fetch sPath os
fetch' PostfixExpTag ((fromDynamic :: Dynamic ->
                                      Maybe PostfixExp) -> Just os) l = let ((sReg, sPath),
                                                                             (_, [])) = l
                                                                         in fetch sPath os
fetch' ListTypeDeclarationTag ((fromDynamic :: Dynamic ->
                                               Maybe ( List TypeDeclaration )) -> Just os) l = let ((sReg,
                                                                                                     sPath),
                                                                                                    (_,
                                                                                                     [])) = l
                                                                                                in fetch sPath os
fetch' ListClassBodyDeclarationTag ((fromDynamic :: Dynamic ->
                                                    Maybe ( List ClassBodyDeclaration )) -> Just os) l = let ((sReg,
                                                                                                               sPath),
                                                                                                              (_,
                                                                                                               [])) = l
                                                                                                          in fetch sPath os
fetch' ListBlockStatementTag ((fromDynamic :: Dynamic ->
                                              Maybe ( List BlockStatement )) -> Just os) l = let ((sReg,
                                                                                                   sPath),
                                                                                                  (_,
                                                                                                   [])) = l
                                                                                              in fetch sPath os
fetch' ListExpressionTag ((fromDynamic :: Dynamic ->
                                          Maybe ( List Expression )) -> Just os) l = let ((sReg,
                                                                                           sPath),
                                                                                          (_,
                                                                                           [])) = l
                                                                                      in fetch sPath os
fetch' ListJCExpressionTag ((fromDynamic :: Dynamic ->
                                            Maybe ( List JCExpression )) -> Just os) l = let ((sReg,
                                                                                               sPath),
                                                                                              (_,
                                                                                               [])) = l
                                                                                          in fetch sPath os
fetch' ListAssignmentTag ((fromDynamic :: Dynamic ->
                                          Maybe ( List Assignment )) -> Just os) l = let ((sReg,
                                                                                           sPath),
                                                                                          (_,
                                                                                           [])) = l
                                                                                      in fetch sPath os
fetch' UTypeTag ((fromDynamic :: Dynamic ->
                                 Maybe UType) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                               in fetch sPath os
fetch' ULitTag ((fromDynamic :: Dynamic ->
                                Maybe ULit) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' IntegerTag ((fromDynamic :: Dynamic ->
                                   Maybe Integer) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                   in fetch sPath os
fetch' StringTag ((fromDynamic :: Dynamic ->
                                  Maybe String) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' CharTag ((fromDynamic :: Dynamic ->
                                Maybe Char) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' BoolTag ((fromDynamic :: Dynamic ->
                                Maybe Bool) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os

class Insertable a
    where ins :: (a, Path) -> (TyTag, Dynamic) -> a

instance Insertable Integer
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable String
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Char
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Bool
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable ( EEither UType String )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (LLeft theHole ,
                                               (0)) -> LLeft ( fromDyn subT theHole ) 
                                              (RRight theHole ,
                                               (0)) -> RRight ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (LLeft theHole ,
                                                (0)) -> LLeft ( ins (theHole,ps) (tySubT,subT) ) 
                                               (RRight theHole ,
                                                (0)) -> RRight ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List Assignment )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List BlockStatement )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List ClassBodyDeclaration )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List Expression )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List JCExpression )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List JCStatement )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List JCTree )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List TypeDeclaration )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( MMaybe JCExpression )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JJust theHole ,
                                               (0)) -> JJust ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JJust theHole ,
                                                (0)) -> JJust ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( MMaybe JCVariableDecl )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JJust theHole ,
                                               (0)) -> JJust ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JJust theHole ,
                                                (0)) -> JJust ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( MMaybe String )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JJust theHole ,
                                               (0)) -> JJust ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JJust theHole ,
                                                (0)) -> JJust ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( Prod UType String )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Prod theHole t1 ,
                                               (0)) -> Prod ( fromDyn subT theHole ) t1 
                                              (Prod t0 theHole ,
                                               (1)) -> Prod t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Prod theHole t1 ,
                                                (0)) -> Prod ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Prod t0 theHole ,
                                                (1)) -> Prod t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable UType
    where ins (src, [p]) (tySubT, subT) = (error $ "path too long.")
          ins (src, p:ps) (tySubT, subT) = (error $ "path too long.")
instance Insertable ULit
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (UIntegerLit theHole ,
                                               (0)) -> UIntegerLit ( fromDyn subT theHole ) 
                                              (UStringLit theHole ,
                                               (0)) -> UStringLit ( fromDyn subT theHole ) 
                                              (UBoolLit theHole ,
                                               (0)) -> UBoolLit ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (UIntegerLit theHole ,
                                                (0)) -> UIntegerLit ( ins (theHole,ps) (tySubT,subT) ) 
                                               (UStringLit theHole ,
                                                (0)) -> UStringLit ( ins (theHole,ps) (tySubT,subT) ) 
                                               (UBoolLit theHole ,
                                                (0)) -> UBoolLit ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable CompilationUnit
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (CompilationUnit theHole ,
                                               (0)) -> CompilationUnit ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (CompilationUnit theHole ,
                                                (0)) -> CompilationUnit ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable TypeDeclaration
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (FromClassDeclaration theHole ,
                                               (0)) -> FromClassDeclaration ( fromDyn subT theHole ) 
                                              (TypeDeclarationSkip theHole ,
                                               (0)) -> TypeDeclarationSkip ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (FromClassDeclaration theHole ,
                                                (0)) -> FromClassDeclaration ( ins (theHole,ps) (tySubT,subT) ) 
                                               (TypeDeclarationSkip theHole ,
                                                (0)) -> TypeDeclarationSkip ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ClassDeclaration
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (NormalClassDeclaration0 theHole t1 t2 t3 t4 t5 ,
                                               (0)) -> NormalClassDeclaration0 ( fromDyn subT theHole ) t1 t2 t3 t4 t5 
                                              (NormalClassDeclaration0 t0 theHole t2 t3 t4 t5 ,
                                               (1)) -> NormalClassDeclaration0 t0 ( fromDyn subT theHole ) t2 t3 t4 t5 
                                              (NormalClassDeclaration0 t0 t1 theHole t3 t4 t5 ,
                                               (2)) -> NormalClassDeclaration0 t0 t1 ( fromDyn subT theHole ) t3 t4 t5 
                                              (NormalClassDeclaration0 t0 t1 t2 theHole t4 t5 ,
                                               (3)) -> NormalClassDeclaration0 t0 t1 t2 ( fromDyn subT theHole ) t4 t5 
                                              (NormalClassDeclaration0 t0 t1 t2 t3 theHole t5 ,
                                               (4)) -> NormalClassDeclaration0 t0 t1 t2 t3 ( fromDyn subT theHole ) t5 
                                              (NormalClassDeclaration0 t0 t1 t2 t3 t4 theHole ,
                                               (5)) -> NormalClassDeclaration0 t0 t1 t2 t3 t4 ( fromDyn subT theHole ) 
                                              (NormalClassDeclaration1 theHole t1 t2 t3 t4 t5 t6 ,
                                               (0)) -> NormalClassDeclaration1 ( fromDyn subT theHole ) t1 t2 t3 t4 t5 t6 
                                              (NormalClassDeclaration1 t0 theHole t2 t3 t4 t5 t6 ,
                                               (1)) -> NormalClassDeclaration1 t0 ( fromDyn subT theHole ) t2 t3 t4 t5 t6 
                                              (NormalClassDeclaration1 t0 t1 theHole t3 t4 t5 t6 ,
                                               (2)) -> NormalClassDeclaration1 t0 t1 ( fromDyn subT theHole ) t3 t4 t5 t6 
                                              (NormalClassDeclaration1 t0 t1 t2 theHole t4 t5 t6 ,
                                               (3)) -> NormalClassDeclaration1 t0 t1 t2 ( fromDyn subT theHole ) t4 t5 t6 
                                              (NormalClassDeclaration1 t0 t1 t2 t3 theHole t5 t6 ,
                                               (4)) -> NormalClassDeclaration1 t0 t1 t2 t3 ( fromDyn subT theHole ) t5 t6 
                                              (NormalClassDeclaration1 t0 t1 t2 t3 t4 theHole t6 ,
                                               (5)) -> NormalClassDeclaration1 t0 t1 t2 t3 t4 ( fromDyn subT theHole ) t6 
                                              (NormalClassDeclaration1 t0 t1 t2 t3 t4 t5 theHole ,
                                               (6)) -> NormalClassDeclaration1 t0 t1 t2 t3 t4 t5 ( fromDyn subT theHole ) 
                                              (NormalClassDeclaration2 theHole t1 t2 t3 ,
                                               (0)) -> NormalClassDeclaration2 ( fromDyn subT theHole ) t1 t2 t3 
                                              (NormalClassDeclaration2 t0 theHole t2 t3 ,
                                               (1)) -> NormalClassDeclaration2 t0 ( fromDyn subT theHole ) t2 t3 
                                              (NormalClassDeclaration2 t0 t1 theHole t3 ,
                                               (2)) -> NormalClassDeclaration2 t0 t1 ( fromDyn subT theHole ) t3 
                                              (NormalClassDeclaration2 t0 t1 t2 theHole ,
                                               (3)) -> NormalClassDeclaration2 t0 t1 t2 ( fromDyn subT theHole ) 
                                              (NormalClassDeclaration3 theHole t1 t2 t3 t4 ,
                                               (0)) -> NormalClassDeclaration3 ( fromDyn subT theHole ) t1 t2 t3 t4 
                                              (NormalClassDeclaration3 t0 theHole t2 t3 t4 ,
                                               (1)) -> NormalClassDeclaration3 t0 ( fromDyn subT theHole ) t2 t3 t4 
                                              (NormalClassDeclaration3 t0 t1 theHole t3 t4 ,
                                               (2)) -> NormalClassDeclaration3 t0 t1 ( fromDyn subT theHole ) t3 t4 
                                              (NormalClassDeclaration3 t0 t1 t2 theHole t4 ,
                                               (3)) -> NormalClassDeclaration3 t0 t1 t2 ( fromDyn subT theHole ) t4 
                                              (NormalClassDeclaration3 t0 t1 t2 t3 theHole ,
                                               (4)) -> NormalClassDeclaration3 t0 t1 t2 t3 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (NormalClassDeclaration0 theHole t1 t2 t3 t4 t5 ,
                                                (0)) -> NormalClassDeclaration0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 t5 
                                               (NormalClassDeclaration0 t0 theHole t2 t3 t4 t5 ,
                                                (1)) -> NormalClassDeclaration0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 t5 
                                               (NormalClassDeclaration0 t0 t1 theHole t3 t4 t5 ,
                                                (2)) -> NormalClassDeclaration0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 t5 
                                               (NormalClassDeclaration0 t0 t1 t2 theHole t4 t5 ,
                                                (3)) -> NormalClassDeclaration0 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 t5 
                                               (NormalClassDeclaration0 t0 t1 t2 t3 theHole t5 ,
                                                (4)) -> NormalClassDeclaration0 t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) t5 
                                               (NormalClassDeclaration0 t0 t1 t2 t3 t4 theHole ,
                                                (5)) -> NormalClassDeclaration0 t0 t1 t2 t3 t4 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (NormalClassDeclaration1 theHole t1 t2 t3 t4 t5 t6 ,
                                                (0)) -> NormalClassDeclaration1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 t5 t6 
                                               (NormalClassDeclaration1 t0 theHole t2 t3 t4 t5 t6 ,
                                                (1)) -> NormalClassDeclaration1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 t5 t6 
                                               (NormalClassDeclaration1 t0 t1 theHole t3 t4 t5 t6 ,
                                                (2)) -> NormalClassDeclaration1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 t5 t6 
                                               (NormalClassDeclaration1 t0 t1 t2 theHole t4 t5 t6 ,
                                                (3)) -> NormalClassDeclaration1 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 t5 t6 
                                               (NormalClassDeclaration1 t0 t1 t2 t3 theHole t5 t6 ,
                                                (4)) -> NormalClassDeclaration1 t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) t5 t6 
                                               (NormalClassDeclaration1 t0 t1 t2 t3 t4 theHole t6 ,
                                                (5)) -> NormalClassDeclaration1 t0 t1 t2 t3 t4 ( ins (theHole,ps) (tySubT,subT) ) t6 
                                               (NormalClassDeclaration1 t0 t1 t2 t3 t4 t5 theHole ,
                                                (6)) -> NormalClassDeclaration1 t0 t1 t2 t3 t4 t5 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (NormalClassDeclaration2 theHole t1 t2 t3 ,
                                                (0)) -> NormalClassDeclaration2 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (NormalClassDeclaration2 t0 theHole t2 t3 ,
                                                (1)) -> NormalClassDeclaration2 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (NormalClassDeclaration2 t0 t1 theHole t3 ,
                                                (2)) -> NormalClassDeclaration2 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (NormalClassDeclaration2 t0 t1 t2 theHole ,
                                                (3)) -> NormalClassDeclaration2 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (NormalClassDeclaration3 theHole t1 t2 t3 t4 ,
                                                (0)) -> NormalClassDeclaration3 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 
                                               (NormalClassDeclaration3 t0 theHole t2 t3 t4 ,
                                                (1)) -> NormalClassDeclaration3 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 
                                               (NormalClassDeclaration3 t0 t1 theHole t3 t4 ,
                                                (2)) -> NormalClassDeclaration3 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 
                                               (NormalClassDeclaration3 t0 t1 t2 theHole t4 ,
                                                (3)) -> NormalClassDeclaration3 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 
                                               (NormalClassDeclaration3 t0 t1 t2 t3 theHole ,
                                                (4)) -> NormalClassDeclaration3 t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ClassBody
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (ClassBody0 theHole t1 ,
                                               (0)) -> ClassBody0 ( fromDyn subT theHole ) t1 
                                              (ClassBody0 t0 theHole ,
                                               (1)) -> ClassBody0 t0 ( fromDyn subT theHole ) 
                                              (ClassBody1 theHole t1 t2 ,
                                               (0)) -> ClassBody1 ( fromDyn subT theHole ) t1 t2 
                                              (ClassBody1 t0 theHole t2 ,
                                               (1)) -> ClassBody1 t0 ( fromDyn subT theHole ) t2 
                                              (ClassBody1 t0 t1 theHole ,
                                               (2)) -> ClassBody1 t0 t1 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (ClassBody0 theHole t1 ,
                                                (0)) -> ClassBody0 ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (ClassBody0 t0 theHole ,
                                                (1)) -> ClassBody0 t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (ClassBody1 theHole t1 t2 ,
                                                (0)) -> ClassBody1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (ClassBody1 t0 theHole t2 ,
                                                (1)) -> ClassBody1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (ClassBody1 t0 t1 theHole ,
                                                (2)) -> ClassBody1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ClassBodyDeclaration
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (FromClassMemberDeclaration theHole ,
                                               (0)) -> FromClassMemberDeclaration ( fromDyn subT theHole ) 
                                              (FromInstanceInitializer theHole ,
                                               (0)) -> FromInstanceInitializer ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (FromClassMemberDeclaration theHole ,
                                                (0)) -> FromClassMemberDeclaration ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromInstanceInitializer theHole ,
                                                (0)) -> FromInstanceInitializer ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ClassMemberDeclaration
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (FieldDeclaration0 theHole t1 t2 t3 ,
                                               (0)) -> FieldDeclaration0 ( fromDyn subT theHole ) t1 t2 t3 
                                              (FieldDeclaration0 t0 theHole t2 t3 ,
                                               (1)) -> FieldDeclaration0 t0 ( fromDyn subT theHole ) t2 t3 
                                              (FieldDeclaration0 t0 t1 theHole t3 ,
                                               (2)) -> FieldDeclaration0 t0 t1 ( fromDyn subT theHole ) t3 
                                              (FieldDeclaration0 t0 t1 t2 theHole ,
                                               (3)) -> FieldDeclaration0 t0 t1 t2 ( fromDyn subT theHole ) 
                                              (FieldDeclaration1 theHole t1 t2 t3 t4 ,
                                               (0)) -> FieldDeclaration1 ( fromDyn subT theHole ) t1 t2 t3 t4 
                                              (FieldDeclaration1 t0 theHole t2 t3 t4 ,
                                               (1)) -> FieldDeclaration1 t0 ( fromDyn subT theHole ) t2 t3 t4 
                                              (FieldDeclaration1 t0 t1 theHole t3 t4 ,
                                               (2)) -> FieldDeclaration1 t0 t1 ( fromDyn subT theHole ) t3 t4 
                                              (FieldDeclaration1 t0 t1 t2 theHole t4 ,
                                               (3)) -> FieldDeclaration1 t0 t1 t2 ( fromDyn subT theHole ) t4 
                                              (FieldDeclaration1 t0 t1 t2 t3 theHole ,
                                               (4)) -> FieldDeclaration1 t0 t1 t2 t3 ( fromDyn subT theHole ) 
                                              (MethodDeclaration0 theHole t1 t2 ,
                                               (0)) -> MethodDeclaration0 ( fromDyn subT theHole ) t1 t2 
                                              (MethodDeclaration0 t0 theHole t2 ,
                                               (1)) -> MethodDeclaration0 t0 ( fromDyn subT theHole ) t2 
                                              (MethodDeclaration0 t0 t1 theHole ,
                                               (2)) -> MethodDeclaration0 t0 t1 ( fromDyn subT theHole ) 
                                              (MethodDeclaration1 theHole t1 t2 t3 ,
                                               (0)) -> MethodDeclaration1 ( fromDyn subT theHole ) t1 t2 t3 
                                              (MethodDeclaration1 t0 theHole t2 t3 ,
                                               (1)) -> MethodDeclaration1 t0 ( fromDyn subT theHole ) t2 t3 
                                              (MethodDeclaration1 t0 t1 theHole t3 ,
                                               (2)) -> MethodDeclaration1 t0 t1 ( fromDyn subT theHole ) t3 
                                              (MethodDeclaration1 t0 t1 t2 theHole ,
                                               (3)) -> MethodDeclaration1 t0 t1 t2 ( fromDyn subT theHole ) 
                                              (MemberFromClassDeclaration theHole ,
                                               (0)) -> MemberFromClassDeclaration ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (FieldDeclaration0 theHole t1 t2 t3 ,
                                                (0)) -> FieldDeclaration0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (FieldDeclaration0 t0 theHole t2 t3 ,
                                                (1)) -> FieldDeclaration0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (FieldDeclaration0 t0 t1 theHole t3 ,
                                                (2)) -> FieldDeclaration0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (FieldDeclaration0 t0 t1 t2 theHole ,
                                                (3)) -> FieldDeclaration0 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FieldDeclaration1 theHole t1 t2 t3 t4 ,
                                                (0)) -> FieldDeclaration1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 
                                               (FieldDeclaration1 t0 theHole t2 t3 t4 ,
                                                (1)) -> FieldDeclaration1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 
                                               (FieldDeclaration1 t0 t1 theHole t3 t4 ,
                                                (2)) -> FieldDeclaration1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 
                                               (FieldDeclaration1 t0 t1 t2 theHole t4 ,
                                                (3)) -> FieldDeclaration1 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 
                                               (FieldDeclaration1 t0 t1 t2 t3 theHole ,
                                                (4)) -> FieldDeclaration1 t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MethodDeclaration0 theHole t1 t2 ,
                                                (0)) -> MethodDeclaration0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (MethodDeclaration0 t0 theHole t2 ,
                                                (1)) -> MethodDeclaration0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (MethodDeclaration0 t0 t1 theHole ,
                                                (2)) -> MethodDeclaration0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MethodDeclaration1 theHole t1 t2 t3 ,
                                                (0)) -> MethodDeclaration1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (MethodDeclaration1 t0 theHole t2 t3 ,
                                                (1)) -> MethodDeclaration1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (MethodDeclaration1 t0 t1 theHole t3 ,
                                                (2)) -> MethodDeclaration1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (MethodDeclaration1 t0 t1 t2 theHole ,
                                                (3)) -> MethodDeclaration1 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MemberFromClassDeclaration theHole ,
                                                (0)) -> MemberFromClassDeclaration ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable MethodHeader
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (MethodHeader theHole t1 ,
                                               (0)) -> MethodHeader ( fromDyn subT theHole ) t1 
                                              (MethodHeader t0 theHole ,
                                               (1)) -> MethodHeader t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (MethodHeader theHole t1 ,
                                                (0)) -> MethodHeader ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (MethodHeader t0 theHole ,
                                                (1)) -> MethodHeader t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable MethodBody
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (MethodBody0 theHole ,
                                               (0)) -> MethodBody0 ( fromDyn subT theHole ) 
                                              (MethodBody1 theHole ,
                                               (0)) -> MethodBody1 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (MethodBody0 theHole ,
                                                (0)) -> MethodBody0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MethodBody1 theHole ,
                                                (0)) -> MethodBody1 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable MethodDeclarator
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (MethodDeclarator0 theHole t1 t2 ,
                                               (0)) -> MethodDeclarator0 ( fromDyn subT theHole ) t1 t2 
                                              (MethodDeclarator0 t0 theHole t2 ,
                                               (1)) -> MethodDeclarator0 t0 ( fromDyn subT theHole ) t2 
                                              (MethodDeclarator0 t0 t1 theHole ,
                                               (2)) -> MethodDeclarator0 t0 t1 ( fromDyn subT theHole ) 
                                              (MethodDeclarator1 theHole t1 t2 t3 ,
                                               (0)) -> MethodDeclarator1 ( fromDyn subT theHole ) t1 t2 t3 
                                              (MethodDeclarator1 t0 theHole t2 t3 ,
                                               (1)) -> MethodDeclarator1 t0 ( fromDyn subT theHole ) t2 t3 
                                              (MethodDeclarator1 t0 t1 theHole t3 ,
                                               (2)) -> MethodDeclarator1 t0 t1 ( fromDyn subT theHole ) t3 
                                              (MethodDeclarator1 t0 t1 t2 theHole ,
                                               (3)) -> MethodDeclarator1 t0 t1 t2 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (MethodDeclarator0 theHole t1 t2 ,
                                                (0)) -> MethodDeclarator0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (MethodDeclarator0 t0 theHole t2 ,
                                                (1)) -> MethodDeclarator0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (MethodDeclarator0 t0 t1 theHole ,
                                                (2)) -> MethodDeclarator0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MethodDeclarator1 theHole t1 t2 t3 ,
                                                (0)) -> MethodDeclarator1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (MethodDeclarator1 t0 theHole t2 t3 ,
                                                (1)) -> MethodDeclarator1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (MethodDeclarator1 t0 t1 theHole t3 ,
                                                (2)) -> MethodDeclarator1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (MethodDeclarator1 t0 t1 t2 theHole ,
                                                (3)) -> MethodDeclarator1 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable BlockStatement
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (LocalVariableDeclaration theHole t1 ,
                                               (0)) -> LocalVariableDeclaration ( fromDyn subT theHole ) t1 
                                              (LocalVariableDeclaration t0 theHole ,
                                               (1)) -> LocalVariableDeclaration t0 ( fromDyn subT theHole ) 
                                              (BlockFromClassDeclaration theHole ,
                                               (0)) -> BlockFromClassDeclaration ( fromDyn subT theHole ) 
                                              (FromStatement theHole ,
                                               (0)) -> FromStatement ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (LocalVariableDeclaration theHole t1 ,
                                                (0)) -> LocalVariableDeclaration ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (LocalVariableDeclaration t0 theHole ,
                                                (1)) -> LocalVariableDeclaration t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (BlockFromClassDeclaration theHole ,
                                                (0)) -> BlockFromClassDeclaration ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromStatement theHole ,
                                                (0)) -> FromStatement ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Statement
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (IfThenElse theHole t1 t2 t3 t4 t5 t6 ,
                                               (0)) -> IfThenElse ( fromDyn subT theHole ) t1 t2 t3 t4 t5 t6 
                                              (IfThenElse t0 theHole t2 t3 t4 t5 t6 ,
                                               (1)) -> IfThenElse t0 ( fromDyn subT theHole ) t2 t3 t4 t5 t6 
                                              (IfThenElse t0 t1 theHole t3 t4 t5 t6 ,
                                               (2)) -> IfThenElse t0 t1 ( fromDyn subT theHole ) t3 t4 t5 t6 
                                              (IfThenElse t0 t1 t2 theHole t4 t5 t6 ,
                                               (3)) -> IfThenElse t0 t1 t2 ( fromDyn subT theHole ) t4 t5 t6 
                                              (IfThenElse t0 t1 t2 t3 theHole t5 t6 ,
                                               (4)) -> IfThenElse t0 t1 t2 t3 ( fromDyn subT theHole ) t5 t6 
                                              (IfThenElse t0 t1 t2 t3 t4 theHole t6 ,
                                               (5)) -> IfThenElse t0 t1 t2 t3 t4 ( fromDyn subT theHole ) t6 
                                              (IfThenElse t0 t1 t2 t3 t4 t5 theHole ,
                                               (6)) -> IfThenElse t0 t1 t2 t3 t4 t5 ( fromDyn subT theHole ) 
                                              (ExpressionStatement theHole t1 ,
                                               (0)) -> ExpressionStatement ( fromDyn subT theHole ) t1 
                                              (ExpressionStatement t0 theHole ,
                                               (1)) -> ExpressionStatement t0 ( fromDyn subT theHole ) 
                                              (While theHole t1 t2 t3 t4 ,
                                               (0)) -> While ( fromDyn subT theHole ) t1 t2 t3 t4 
                                              (While t0 theHole t2 t3 t4 ,
                                               (1)) -> While t0 ( fromDyn subT theHole ) t2 t3 t4 
                                              (While t0 t1 theHole t3 t4 ,
                                               (2)) -> While t0 t1 ( fromDyn subT theHole ) t3 t4 
                                              (While t0 t1 t2 theHole t4 ,
                                               (3)) -> While t0 t1 t2 ( fromDyn subT theHole ) t4 
                                              (While t0 t1 t2 t3 theHole ,
                                               (4)) -> While t0 t1 t2 t3 ( fromDyn subT theHole ) 
                                              (BasicFor theHole t1 t2 t3 t4 t5 t6 t7 t8 ,
                                               (0)) -> BasicFor ( fromDyn subT theHole ) t1 t2 t3 t4 t5 t6 t7 t8 
                                              (BasicFor t0 theHole t2 t3 t4 t5 t6 t7 t8 ,
                                               (1)) -> BasicFor t0 ( fromDyn subT theHole ) t2 t3 t4 t5 t6 t7 t8 
                                              (BasicFor t0 t1 theHole t3 t4 t5 t6 t7 t8 ,
                                               (2)) -> BasicFor t0 t1 ( fromDyn subT theHole ) t3 t4 t5 t6 t7 t8 
                                              (BasicFor t0 t1 t2 theHole t4 t5 t6 t7 t8 ,
                                               (3)) -> BasicFor t0 t1 t2 ( fromDyn subT theHole ) t4 t5 t6 t7 t8 
                                              (BasicFor t0 t1 t2 t3 theHole t5 t6 t7 t8 ,
                                               (4)) -> BasicFor t0 t1 t2 t3 ( fromDyn subT theHole ) t5 t6 t7 t8 
                                              (BasicFor t0 t1 t2 t3 t4 theHole t6 t7 t8 ,
                                               (5)) -> BasicFor t0 t1 t2 t3 t4 ( fromDyn subT theHole ) t6 t7 t8 
                                              (BasicFor t0 t1 t2 t3 t4 t5 theHole t7 t8 ,
                                               (6)) -> BasicFor t0 t1 t2 t3 t4 t5 ( fromDyn subT theHole ) t7 t8 
                                              (BasicFor t0 t1 t2 t3 t4 t5 t6 theHole t8 ,
                                               (7)) -> BasicFor t0 t1 t2 t3 t4 t5 t6 ( fromDyn subT theHole ) t8 
                                              (BasicFor t0 t1 t2 t3 t4 t5 t6 t7 theHole ,
                                               (8)) -> BasicFor t0 t1 t2 t3 t4 t5 t6 t7 ( fromDyn subT theHole ) 
                                              (EnhancedFor theHole t1 t2 t3 t4 t5 t6 t7 ,
                                               (0)) -> EnhancedFor ( fromDyn subT theHole ) t1 t2 t3 t4 t5 t6 t7 
                                              (EnhancedFor t0 theHole t2 t3 t4 t5 t6 t7 ,
                                               (1)) -> EnhancedFor t0 ( fromDyn subT theHole ) t2 t3 t4 t5 t6 t7 
                                              (EnhancedFor t0 t1 theHole t3 t4 t5 t6 t7 ,
                                               (2)) -> EnhancedFor t0 t1 ( fromDyn subT theHole ) t3 t4 t5 t6 t7 
                                              (EnhancedFor t0 t1 t2 theHole t4 t5 t6 t7 ,
                                               (3)) -> EnhancedFor t0 t1 t2 ( fromDyn subT theHole ) t4 t5 t6 t7 
                                              (EnhancedFor t0 t1 t2 t3 theHole t5 t6 t7 ,
                                               (4)) -> EnhancedFor t0 t1 t2 t3 ( fromDyn subT theHole ) t5 t6 t7 
                                              (EnhancedFor t0 t1 t2 t3 t4 theHole t6 t7 ,
                                               (5)) -> EnhancedFor t0 t1 t2 t3 t4 ( fromDyn subT theHole ) t6 t7 
                                              (EnhancedFor t0 t1 t2 t3 t4 t5 theHole t7 ,
                                               (6)) -> EnhancedFor t0 t1 t2 t3 t4 t5 ( fromDyn subT theHole ) t7 
                                              (EnhancedFor t0 t1 t2 t3 t4 t5 t6 theHole ,
                                               (7)) -> EnhancedFor t0 t1 t2 t3 t4 t5 t6 ( fromDyn subT theHole ) 
                                              (FromBlockStatement theHole ,
                                               (0)) -> FromBlockStatement ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (IfThenElse theHole t1 t2 t3 t4 t5 t6 ,
                                                (0)) -> IfThenElse ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 t5 t6 
                                               (IfThenElse t0 theHole t2 t3 t4 t5 t6 ,
                                                (1)) -> IfThenElse t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 t5 t6 
                                               (IfThenElse t0 t1 theHole t3 t4 t5 t6 ,
                                                (2)) -> IfThenElse t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 t5 t6 
                                               (IfThenElse t0 t1 t2 theHole t4 t5 t6 ,
                                                (3)) -> IfThenElse t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 t5 t6 
                                               (IfThenElse t0 t1 t2 t3 theHole t5 t6 ,
                                                (4)) -> IfThenElse t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) t5 t6 
                                               (IfThenElse t0 t1 t2 t3 t4 theHole t6 ,
                                                (5)) -> IfThenElse t0 t1 t2 t3 t4 ( ins (theHole,ps) (tySubT,subT) ) t6 
                                               (IfThenElse t0 t1 t2 t3 t4 t5 theHole ,
                                                (6)) -> IfThenElse t0 t1 t2 t3 t4 t5 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (ExpressionStatement theHole t1 ,
                                                (0)) -> ExpressionStatement ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (ExpressionStatement t0 theHole ,
                                                (1)) -> ExpressionStatement t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (While theHole t1 t2 t3 t4 ,
                                                (0)) -> While ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 
                                               (While t0 theHole t2 t3 t4 ,
                                                (1)) -> While t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 
                                               (While t0 t1 theHole t3 t4 ,
                                                (2)) -> While t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 
                                               (While t0 t1 t2 theHole t4 ,
                                                (3)) -> While t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 
                                               (While t0 t1 t2 t3 theHole ,
                                                (4)) -> While t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (BasicFor theHole t1 t2 t3 t4 t5 t6 t7 t8 ,
                                                (0)) -> BasicFor ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 t5 t6 t7 t8 
                                               (BasicFor t0 theHole t2 t3 t4 t5 t6 t7 t8 ,
                                                (1)) -> BasicFor t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 t5 t6 t7 t8 
                                               (BasicFor t0 t1 theHole t3 t4 t5 t6 t7 t8 ,
                                                (2)) -> BasicFor t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 t5 t6 t7 t8 
                                               (BasicFor t0 t1 t2 theHole t4 t5 t6 t7 t8 ,
                                                (3)) -> BasicFor t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 t5 t6 t7 t8 
                                               (BasicFor t0 t1 t2 t3 theHole t5 t6 t7 t8 ,
                                                (4)) -> BasicFor t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) t5 t6 t7 t8 
                                               (BasicFor t0 t1 t2 t3 t4 theHole t6 t7 t8 ,
                                                (5)) -> BasicFor t0 t1 t2 t3 t4 ( ins (theHole,ps) (tySubT,subT) ) t6 t7 t8 
                                               (BasicFor t0 t1 t2 t3 t4 t5 theHole t7 t8 ,
                                                (6)) -> BasicFor t0 t1 t2 t3 t4 t5 ( ins (theHole,ps) (tySubT,subT) ) t7 t8 
                                               (BasicFor t0 t1 t2 t3 t4 t5 t6 theHole t8 ,
                                                (7)) -> BasicFor t0 t1 t2 t3 t4 t5 t6 ( ins (theHole,ps) (tySubT,subT) ) t8 
                                               (BasicFor t0 t1 t2 t3 t4 t5 t6 t7 theHole ,
                                                (8)) -> BasicFor t0 t1 t2 t3 t4 t5 t6 t7 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (EnhancedFor theHole t1 t2 t3 t4 t5 t6 t7 ,
                                                (0)) -> EnhancedFor ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 t5 t6 t7 
                                               (EnhancedFor t0 theHole t2 t3 t4 t5 t6 t7 ,
                                                (1)) -> EnhancedFor t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 t5 t6 t7 
                                               (EnhancedFor t0 t1 theHole t3 t4 t5 t6 t7 ,
                                                (2)) -> EnhancedFor t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 t5 t6 t7 
                                               (EnhancedFor t0 t1 t2 theHole t4 t5 t6 t7 ,
                                                (3)) -> EnhancedFor t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 t5 t6 t7 
                                               (EnhancedFor t0 t1 t2 t3 theHole t5 t6 t7 ,
                                                (4)) -> EnhancedFor t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) t5 t6 t7 
                                               (EnhancedFor t0 t1 t2 t3 t4 theHole t6 t7 ,
                                                (5)) -> EnhancedFor t0 t1 t2 t3 t4 ( ins (theHole,ps) (tySubT,subT) ) t6 t7 
                                               (EnhancedFor t0 t1 t2 t3 t4 t5 theHole t7 ,
                                                (6)) -> EnhancedFor t0 t1 t2 t3 t4 t5 ( ins (theHole,ps) (tySubT,subT) ) t7 
                                               (EnhancedFor t0 t1 t2 t3 t4 t5 t6 theHole ,
                                                (7)) -> EnhancedFor t0 t1 t2 t3 t4 t5 t6 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromBlockStatement theHole ,
                                                (0)) -> FromBlockStatement ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Expression
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (AssignExp theHole ,
                                               (0)) -> AssignExp ( fromDyn subT theHole ) 
                                              (MethodInvocation0 theHole t1 t2 ,
                                               (0)) -> MethodInvocation0 ( fromDyn subT theHole ) t1 t2 
                                              (MethodInvocation0 t0 theHole t2 ,
                                               (1)) -> MethodInvocation0 t0 ( fromDyn subT theHole ) t2 
                                              (MethodInvocation0 t0 t1 theHole ,
                                               (2)) -> MethodInvocation0 t0 t1 ( fromDyn subT theHole ) 
                                              (MethodInvocation1 theHole t1 t2 t3 ,
                                               (0)) -> MethodInvocation1 ( fromDyn subT theHole ) t1 t2 t3 
                                              (MethodInvocation1 t0 theHole t2 t3 ,
                                               (1)) -> MethodInvocation1 t0 ( fromDyn subT theHole ) t2 t3 
                                              (MethodInvocation1 t0 t1 theHole t3 ,
                                               (2)) -> MethodInvocation1 t0 t1 ( fromDyn subT theHole ) t3 
                                              (MethodInvocation1 t0 t1 t2 theHole ,
                                               (3)) -> MethodInvocation1 t0 t1 t2 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (AssignExp theHole ,
                                                (0)) -> AssignExp ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MethodInvocation0 theHole t1 t2 ,
                                                (0)) -> MethodInvocation0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (MethodInvocation0 t0 theHole t2 ,
                                                (1)) -> MethodInvocation0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (MethodInvocation0 t0 t1 theHole ,
                                                (2)) -> MethodInvocation0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (MethodInvocation1 theHole t1 t2 t3 ,
                                                (0)) -> MethodInvocation1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (MethodInvocation1 t0 theHole t2 t3 ,
                                                (1)) -> MethodInvocation1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (MethodInvocation1 t0 t1 theHole t3 ,
                                                (2)) -> MethodInvocation1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (MethodInvocation1 t0 t1 t2 theHole ,
                                                (3)) -> MethodInvocation1 t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Assignment
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Assignment theHole t1 t2 ,
                                               (0)) -> Assignment ( fromDyn subT theHole ) t1 t2 
                                              (Assignment t0 theHole t2 ,
                                               (1)) -> Assignment t0 ( fromDyn subT theHole ) t2 
                                              (Assignment t0 t1 theHole ,
                                               (2)) -> Assignment t0 t1 ( fromDyn subT theHole ) 
                                              (FromRelExp theHole ,
                                               (0)) -> FromRelExp ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Assignment theHole t1 t2 ,
                                                (0)) -> Assignment ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Assignment t0 theHole t2 ,
                                                (1)) -> Assignment t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Assignment t0 t1 theHole ,
                                                (2)) -> Assignment t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromRelExp theHole ,
                                                (0)) -> FromRelExp ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable VariableDeclarator
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (VariableDeclarator0 theHole ,
                                               (0)) -> VariableDeclarator0 ( fromDyn subT theHole ) 
                                              (VariableDeclarator1 theHole t1 ,
                                               (0)) -> VariableDeclarator1 ( fromDyn subT theHole ) t1 
                                              (VariableDeclarator1 t0 theHole ,
                                               (1)) -> VariableDeclarator1 t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (VariableDeclarator0 theHole ,
                                                (0)) -> VariableDeclarator0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (VariableDeclarator1 theHole t1 ,
                                                (0)) -> VariableDeclarator1 ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (VariableDeclarator1 t0 theHole ,
                                                (1)) -> VariableDeclarator1 t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable VariableInitializer
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (VariableInitializer theHole t1 ,
                                               (0)) -> VariableInitializer ( fromDyn subT theHole ) t1 
                                              (VariableInitializer t0 theHole ,
                                               (1)) -> VariableInitializer t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (VariableInitializer theHole t1 ,
                                                (0)) -> VariableInitializer ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (VariableInitializer t0 theHole ,
                                                (1)) -> VariableInitializer t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable RelExp
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (RelExp0 theHole t1 t2 ,
                                               (0)) -> RelExp0 ( fromDyn subT theHole ) t1 t2 
                                              (RelExp0 t0 theHole t2 ,
                                               (1)) -> RelExp0 t0 ( fromDyn subT theHole ) t2 
                                              (RelExp0 t0 t1 theHole ,
                                               (2)) -> RelExp0 t0 t1 ( fromDyn subT theHole ) 
                                              (FromAdditiveExp theHole ,
                                               (0)) -> FromAdditiveExp ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (RelExp0 theHole t1 t2 ,
                                                (0)) -> RelExp0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (RelExp0 t0 theHole t2 ,
                                                (1)) -> RelExp0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (RelExp0 t0 t1 theHole ,
                                                (2)) -> RelExp0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromAdditiveExp theHole ,
                                                (0)) -> FromAdditiveExp ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable AdditiveExp
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (AdditiveExp0 theHole t1 t2 ,
                                               (0)) -> AdditiveExp0 ( fromDyn subT theHole ) t1 t2 
                                              (AdditiveExp0 t0 theHole t2 ,
                                               (1)) -> AdditiveExp0 t0 ( fromDyn subT theHole ) t2 
                                              (AdditiveExp0 t0 t1 theHole ,
                                               (2)) -> AdditiveExp0 t0 t1 ( fromDyn subT theHole ) 
                                              (AdditiveExp1 theHole t1 t2 ,
                                               (0)) -> AdditiveExp1 ( fromDyn subT theHole ) t1 t2 
                                              (AdditiveExp1 t0 theHole t2 ,
                                               (1)) -> AdditiveExp1 t0 ( fromDyn subT theHole ) t2 
                                              (AdditiveExp1 t0 t1 theHole ,
                                               (2)) -> AdditiveExp1 t0 t1 ( fromDyn subT theHole ) 
                                              (FromPostfixExp theHole ,
                                               (0)) -> FromPostfixExp ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (AdditiveExp0 theHole t1 t2 ,
                                                (0)) -> AdditiveExp0 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (AdditiveExp0 t0 theHole t2 ,
                                                (1)) -> AdditiveExp0 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (AdditiveExp0 t0 t1 theHole ,
                                                (2)) -> AdditiveExp0 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (AdditiveExp1 theHole t1 t2 ,
                                                (0)) -> AdditiveExp1 ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (AdditiveExp1 t0 theHole t2 ,
                                                (1)) -> AdditiveExp1 t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (AdditiveExp1 t0 t1 theHole ,
                                                (2)) -> AdditiveExp1 t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromPostfixExp theHole ,
                                                (0)) -> FromPostfixExp ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable PostfixExp
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (PostIncExp theHole t1 ,
                                               (0)) -> PostIncExp ( fromDyn subT theHole ) t1 
                                              (PostIncExp t0 theHole ,
                                               (1)) -> PostIncExp t0 ( fromDyn subT theHole ) 
                                              (FromPrimary theHole ,
                                               (0)) -> FromPrimary ( fromDyn subT theHole ) 
                                              (ExpN theHole , (0)) -> ExpN ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (PostIncExp theHole t1 ,
                                                (0)) -> PostIncExp ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (PostIncExp t0 theHole ,
                                                (1)) -> PostIncExp t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromPrimary theHole ,
                                                (0)) -> FromPrimary ( ins (theHole,ps) (tySubT,subT) ) 
                                               (ExpN theHole ,
                                                (0)) -> ExpN ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Primary
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (PrimaryLit theHole ,
                                               (0)) -> PrimaryLit ( fromDyn subT theHole ) 
                                              (Paren theHole t1 t2 ,
                                               (0)) -> Paren ( fromDyn subT theHole ) t1 t2 
                                              (Paren t0 theHole t2 ,
                                               (1)) -> Paren t0 ( fromDyn subT theHole ) t2 
                                              (Paren t0 t1 theHole ,
                                               (2)) -> Paren t0 t1 ( fromDyn subT theHole ) 
                                              (FieldAccess theHole t1 t2 ,
                                               (0)) -> FieldAccess ( fromDyn subT theHole ) t1 t2 
                                              (FieldAccess t0 theHole t2 ,
                                               (1)) -> FieldAccess t0 ( fromDyn subT theHole ) t2 
                                              (FieldAccess t0 t1 theHole ,
                                               (2)) -> FieldAccess t0 t1 ( fromDyn subT theHole ) 
                                              (ArrayAccess theHole t1 t2 t3 ,
                                               (0)) -> ArrayAccess ( fromDyn subT theHole ) t1 t2 t3 
                                              (ArrayAccess t0 theHole t2 t3 ,
                                               (1)) -> ArrayAccess t0 ( fromDyn subT theHole ) t2 t3 
                                              (ArrayAccess t0 t1 theHole t3 ,
                                               (2)) -> ArrayAccess t0 t1 ( fromDyn subT theHole ) t3 
                                              (ArrayAccess t0 t1 t2 theHole ,
                                               (3)) -> ArrayAccess t0 t1 t2 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (PrimaryLit theHole ,
                                                (0)) -> PrimaryLit ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Paren theHole t1 t2 ,
                                                (0)) -> Paren ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Paren t0 theHole t2 ,
                                                (1)) -> Paren t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Paren t0 t1 theHole ,
                                                (2)) -> Paren t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FieldAccess theHole t1 t2 ,
                                                (0)) -> FieldAccess ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (FieldAccess t0 theHole t2 ,
                                                (1)) -> FieldAccess t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (FieldAccess t0 t1 theHole ,
                                                (2)) -> FieldAccess t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (ArrayAccess theHole t1 t2 t3 ,
                                                (0)) -> ArrayAccess ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (ArrayAccess t0 theHole t2 t3 ,
                                                (1)) -> ArrayAccess t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (ArrayAccess t0 t1 theHole t3 ,
                                                (2)) -> ArrayAccess t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (ArrayAccess t0 t1 t2 theHole ,
                                                (3)) -> ArrayAccess t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCCompilationUnit
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JCCompilationUnit theHole ,
                                               (0)) -> JCCompilationUnit ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JCCompilationUnit theHole ,
                                                (0)) -> JCCompilationUnit ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCTree
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (FromJCExpression theHole ,
                                               (0)) -> FromJCExpression ( fromDyn subT theHole ) 
                                              (FromJCStatement theHole ,
                                               (0)) -> FromJCStatement ( fromDyn subT theHole ) 
                                              (FromJCModifier theHole ,
                                               (0)) -> FromJCModifier ( fromDyn subT theHole ) 
                                              (FromJCMethodDecl theHole ,
                                               (0)) -> FromJCMethodDecl ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (FromJCExpression theHole ,
                                                (0)) -> FromJCExpression ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCStatement theHole ,
                                                (0)) -> FromJCStatement ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCModifier theHole ,
                                                (0)) -> FromJCModifier ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCMethodDecl theHole ,
                                                (0)) -> FromJCMethodDecl ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCExpression
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (FromJCPolyExpression theHole ,
                                               (0)) -> FromJCPolyExpression ( fromDyn subT theHole ) 
                                              (JCAssign theHole t1 ,
                                               (0)) -> JCAssign ( fromDyn subT theHole ) t1 
                                              (JCAssign t0 theHole ,
                                               (1)) -> JCAssign t0 ( fromDyn subT theHole ) 
                                              (JCUnary theHole t1 t2 ,
                                               (0)) -> JCUnary ( fromDyn subT theHole ) t1 t2 
                                              (JCUnary t0 theHole t2 ,
                                               (1)) -> JCUnary t0 ( fromDyn subT theHole ) t2 
                                              (JCUnary t0 t1 theHole ,
                                               (2)) -> JCUnary t0 t1 ( fromDyn subT theHole ) 
                                              (JCBinary theHole t1 t2 t3 ,
                                               (0)) -> JCBinary ( fromDyn subT theHole ) t1 t2 t3 
                                              (JCBinary t0 theHole t2 t3 ,
                                               (1)) -> JCBinary t0 ( fromDyn subT theHole ) t2 t3 
                                              (JCBinary t0 t1 theHole t3 ,
                                               (2)) -> JCBinary t0 t1 ( fromDyn subT theHole ) t3 
                                              (JCBinary t0 t1 t2 theHole ,
                                               (3)) -> JCBinary t0 t1 t2 ( fromDyn subT theHole ) 
                                              (JCArrayAccess theHole t1 ,
                                               (0)) -> JCArrayAccess ( fromDyn subT theHole ) t1 
                                              (JCArrayAccess t0 theHole ,
                                               (1)) -> JCArrayAccess t0 ( fromDyn subT theHole ) 
                                              (JCFieldAccess theHole t1 ,
                                               (0)) -> JCFieldAccess ( fromDyn subT theHole ) t1 
                                              (JCFieldAccess t0 theHole ,
                                               (1)) -> JCFieldAccess t0 ( fromDyn subT theHole ) 
                                              (JCIdent theHole ,
                                               (0)) -> JCIdent ( fromDyn subT theHole ) 
                                              (JCPrimitiveTypeTree theHole ,
                                               (0)) -> JCPrimitiveTypeTree ( fromDyn subT theHole ) 
                                              (FromJCLiteral theHole ,
                                               (0)) -> FromJCLiteral ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (FromJCPolyExpression theHole ,
                                                (0)) -> FromJCPolyExpression ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCAssign theHole t1 ,
                                                (0)) -> JCAssign ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (JCAssign t0 theHole ,
                                                (1)) -> JCAssign t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCUnary theHole t1 t2 ,
                                                (0)) -> JCUnary ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (JCUnary t0 theHole t2 ,
                                                (1)) -> JCUnary t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (JCUnary t0 t1 theHole ,
                                                (2)) -> JCUnary t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCBinary theHole t1 t2 t3 ,
                                                (0)) -> JCBinary ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (JCBinary t0 theHole t2 t3 ,
                                                (1)) -> JCBinary t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (JCBinary t0 t1 theHole t3 ,
                                                (2)) -> JCBinary t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (JCBinary t0 t1 t2 theHole ,
                                                (3)) -> JCBinary t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCArrayAccess theHole t1 ,
                                                (0)) -> JCArrayAccess ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (JCArrayAccess t0 theHole ,
                                                (1)) -> JCArrayAccess t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCFieldAccess theHole t1 ,
                                                (0)) -> JCFieldAccess ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (JCFieldAccess t0 theHole ,
                                                (1)) -> JCFieldAccess t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCIdent theHole ,
                                                (0)) -> JCIdent ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCPrimitiveTypeTree theHole ,
                                                (0)) -> JCPrimitiveTypeTree ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCLiteral theHole ,
                                                (0)) -> FromJCLiteral ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCPolyExpression
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JCMethodInvocation theHole t1 t2 ,
                                               (0)) -> JCMethodInvocation ( fromDyn subT theHole ) t1 t2 
                                              (JCMethodInvocation t0 theHole t2 ,
                                               (1)) -> JCMethodInvocation t0 ( fromDyn subT theHole ) t2 
                                              (JCMethodInvocation t0 t1 theHole ,
                                               (2)) -> JCMethodInvocation t0 t1 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JCMethodInvocation theHole t1 t2 ,
                                                (0)) -> JCMethodInvocation ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (JCMethodInvocation t0 theHole t2 ,
                                                (1)) -> JCMethodInvocation t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (JCMethodInvocation t0 t1 theHole ,
                                                (2)) -> JCMethodInvocation t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCStatement
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (FromJCClassDecl theHole ,
                                               (0)) -> FromJCClassDecl ( fromDyn subT theHole ) 
                                              (FromJCBlock theHole ,
                                               (0)) -> FromJCBlock ( fromDyn subT theHole ) 
                                              (FromJCExpressionStatement theHole ,
                                               (0)) -> FromJCExpressionStatement ( fromDyn subT theHole ) 
                                              (FromJCVariableDecl theHole ,
                                               (0)) -> FromJCVariableDecl ( fromDyn subT theHole ) 
                                              (JCForLoop theHole t1 t2 t3 ,
                                               (0)) -> JCForLoop ( fromDyn subT theHole ) t1 t2 t3 
                                              (JCForLoop t0 theHole t2 t3 ,
                                               (1)) -> JCForLoop t0 ( fromDyn subT theHole ) t2 t3 
                                              (JCForLoop t0 t1 theHole t3 ,
                                               (2)) -> JCForLoop t0 t1 ( fromDyn subT theHole ) t3 
                                              (JCForLoop t0 t1 t2 theHole ,
                                               (3)) -> JCForLoop t0 t1 t2 ( fromDyn subT theHole ) 
                                              (JCIf theHole t1 t2 ,
                                               (0)) -> JCIf ( fromDyn subT theHole ) t1 t2 
                                              (JCIf t0 theHole t2 ,
                                               (1)) -> JCIf t0 ( fromDyn subT theHole ) t2 
                                              (JCIf t0 t1 theHole ,
                                               (2)) -> JCIf t0 t1 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (FromJCClassDecl theHole ,
                                                (0)) -> FromJCClassDecl ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCBlock theHole ,
                                                (0)) -> FromJCBlock ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCExpressionStatement theHole ,
                                                (0)) -> FromJCExpressionStatement ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromJCVariableDecl theHole ,
                                                (0)) -> FromJCVariableDecl ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCForLoop theHole t1 t2 t3 ,
                                                (0)) -> JCForLoop ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (JCForLoop t0 theHole t2 t3 ,
                                                (1)) -> JCForLoop t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (JCForLoop t0 t1 theHole t3 ,
                                                (2)) -> JCForLoop t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (JCForLoop t0 t1 t2 theHole ,
                                                (3)) -> JCForLoop t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (JCIf theHole t1 t2 ,
                                                (0)) -> JCIf ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (JCIf t0 theHole t2 ,
                                                (1)) -> JCIf t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (JCIf t0 t1 theHole ,
                                                (2)) -> JCIf t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCClassDecl
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JCClassDecl theHole t1 t2 t3 ,
                                               (0)) -> JCClassDecl ( fromDyn subT theHole ) t1 t2 t3 
                                              (JCClassDecl t0 theHole t2 t3 ,
                                               (1)) -> JCClassDecl t0 ( fromDyn subT theHole ) t2 t3 
                                              (JCClassDecl t0 t1 theHole t3 ,
                                               (2)) -> JCClassDecl t0 t1 ( fromDyn subT theHole ) t3 
                                              (JCClassDecl t0 t1 t2 theHole ,
                                               (3)) -> JCClassDecl t0 t1 t2 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JCClassDecl theHole t1 t2 t3 ,
                                                (0)) -> JCClassDecl ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (JCClassDecl t0 theHole t2 t3 ,
                                                (1)) -> JCClassDecl t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (JCClassDecl t0 t1 theHole t3 ,
                                                (2)) -> JCClassDecl t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (JCClassDecl t0 t1 t2 theHole ,
                                                (3)) -> JCClassDecl t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCVariableDecl
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JCVariableDecl theHole t1 t2 t3 ,
                                               (0)) -> JCVariableDecl ( fromDyn subT theHole ) t1 t2 t3 
                                              (JCVariableDecl t0 theHole t2 t3 ,
                                               (1)) -> JCVariableDecl t0 ( fromDyn subT theHole ) t2 t3 
                                              (JCVariableDecl t0 t1 theHole t3 ,
                                               (2)) -> JCVariableDecl t0 t1 ( fromDyn subT theHole ) t3 
                                              (JCVariableDecl t0 t1 t2 theHole ,
                                               (3)) -> JCVariableDecl t0 t1 t2 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JCVariableDecl theHole t1 t2 t3 ,
                                                (0)) -> JCVariableDecl ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 
                                               (JCVariableDecl t0 theHole t2 t3 ,
                                                (1)) -> JCVariableDecl t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 
                                               (JCVariableDecl t0 t1 theHole t3 ,
                                                (2)) -> JCVariableDecl t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 
                                               (JCVariableDecl t0 t1 t2 theHole ,
                                                (3)) -> JCVariableDecl t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable JCMethodDecl
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (JCMethodDecl theHole t1 t2 t3 t4 ,
                                               (0)) -> JCMethodDecl ( fromDyn subT theHole ) t1 t2 t3 t4 
                                              (JCMethodDecl t0 theHole t2 t3 t4 ,
                                               (1)) -> JCMethodDecl t0 ( fromDyn subT theHole ) t2 t3 t4 
                                              (JCMethodDecl t0 t1 theHole t3 t4 ,
                                               (2)) -> JCMethodDecl t0 t1 ( fromDyn subT theHole ) t3 t4 
                                              (JCMethodDecl t0 t1 t2 theHole t4 ,
                                               (3)) -> JCMethodDecl t0 t1 t2 ( fromDyn subT theHole ) t4 
                                              (JCMethodDecl t0 t1 t2 t3 theHole ,
                                               (4)) -> JCMethodDecl t0 t1 t2 t3 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (JCMethodDecl theHole t1 t2 t3 t4 ,
                                                (0)) -> JCMethodDecl ( ins (theHole,ps) (tySubT,subT) ) t1 t2 t3 t4 
                                               (JCMethodDecl t0 theHole t2 t3 t4 ,
                                                (1)) -> JCMethodDecl t0 ( ins (theHole,ps) (tySubT,subT) ) t2 t3 t4 
                                               (JCMethodDecl t0 t1 theHole t3 t4 ,
                                                (2)) -> JCMethodDecl t0 t1 ( ins (theHole,ps) (tySubT,subT) ) t3 t4 
                                               (JCMethodDecl t0 t1 t2 theHole t4 ,
                                                (3)) -> JCMethodDecl t0 t1 t2 ( ins (theHole,ps) (tySubT,subT) ) t4 
                                               (JCMethodDecl t0 t1 t2 t3 theHole ,
                                                (4)) -> JCMethodDecl t0 t1 t2 t3 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Tag
    where ins (src, [p]) (tySubT, subT) = (error $ "path too long.")
          ins (src, p:ps) (tySubT, subT) = (error $ "path too long.")

class HasDefVal a
    where defVal :: TyTag -> a

instance HasDefVal ( EEither UType String )
    where defVal EEitherUTypeStringTag = EEitherNull
instance HasDefVal ( List Assignment )
    where defVal ListAssignmentTag = ListNull
instance HasDefVal ( List BlockStatement )
    where defVal ListBlockStatementTag = ListNull
instance HasDefVal ( List ClassBodyDeclaration )
    where defVal ListClassBodyDeclarationTag = ListNull
instance HasDefVal ( List Expression )
    where defVal ListExpressionTag = ListNull
instance HasDefVal ( List JCExpression )
    where defVal ListJCExpressionTag = ListNull
instance HasDefVal ( List JCStatement )
    where defVal ListJCStatementTag = ListNull
instance HasDefVal ( List JCTree )
    where defVal ListJCTreeTag = ListNull
instance HasDefVal ( List TypeDeclaration )
    where defVal ListTypeDeclarationTag = ListNull
instance HasDefVal ( MMaybe JCExpression )
    where defVal MMaybeJCExpressionTag = MMaybeNull
instance HasDefVal ( MMaybe JCVariableDecl )
    where defVal MMaybeJCVariableDeclTag = MMaybeNull
instance HasDefVal ( MMaybe String )
    where defVal MMaybeStringTag = MMaybeNull
instance HasDefVal ( Prod UType String )
    where defVal ProdUTypeStringTag = ProdNull
instance HasDefVal UType
    where defVal UTypeTag = UTypeNull
instance HasDefVal ULit
    where defVal ULitTag = ULitNull
instance HasDefVal CompilationUnit
    where defVal CompilationUnitTag = CompilationUnitNull
instance HasDefVal TypeDeclaration
    where defVal TypeDeclarationTag = TypeDeclarationNull
instance HasDefVal ClassDeclaration
    where defVal ClassDeclarationTag = ClassDeclarationNull
instance HasDefVal ClassBody
    where defVal ClassBodyTag = ClassBodyNull
instance HasDefVal ClassBodyDeclaration
    where defVal ClassBodyDeclarationTag = ClassBodyDeclarationNull
instance HasDefVal ClassMemberDeclaration
    where defVal ClassMemberDeclarationTag = ClassMemberDeclarationNull
instance HasDefVal MethodHeader
    where defVal MethodHeaderTag = MethodHeaderNull
instance HasDefVal MethodBody
    where defVal MethodBodyTag = MethodBodyNull
instance HasDefVal MethodDeclarator
    where defVal MethodDeclaratorTag = MethodDeclaratorNull
instance HasDefVal BlockStatement
    where defVal BlockStatementTag = BlockStatementNull
instance HasDefVal Statement
    where defVal StatementTag = StatementNull
instance HasDefVal Expression
    where defVal ExpressionTag = ExpressionNull
instance HasDefVal Assignment
    where defVal AssignmentTag = AssignmentNull
instance HasDefVal VariableDeclarator
    where defVal VariableDeclaratorTag = VariableDeclaratorNull
instance HasDefVal VariableInitializer
    where defVal VariableInitializerTag = VariableInitializerNull
instance HasDefVal RelExp
    where defVal RelExpTag = RelExpNull
instance HasDefVal AdditiveExp
    where defVal AdditiveExpTag = AdditiveExpNull
instance HasDefVal PostfixExp
    where defVal PostfixExpTag = PostfixExpNull
instance HasDefVal Primary
    where defVal PrimaryTag = PrimaryNull
instance HasDefVal JCCompilationUnit
    where defVal JCCompilationUnitTag = JCCompilationUnitNull
instance HasDefVal JCTree
    where defVal JCTreeTag = JCTreeNull
instance HasDefVal JCExpression
    where defVal JCExpressionTag = JCExpressionNull
instance HasDefVal JCPolyExpression
    where defVal JCPolyExpressionTag = JCPolyExpressionNull
instance HasDefVal JCStatement
    where defVal JCStatementTag = JCStatementNull
instance HasDefVal JCClassDecl
    where defVal JCClassDeclTag = JCClassDeclNull
instance HasDefVal JCVariableDecl
    where defVal JCVariableDeclTag = JCVariableDeclNull
instance HasDefVal JCMethodDecl
    where defVal JCMethodDeclTag = JCMethodDeclNull
instance HasDefVal Tag
    where defVal TagTag = TagNull
instance HasDefVal Integer
    where defVal IntegerTag = 0
instance HasDefVal String
    where defVal StringTag = "DEF_VAL"
instance HasDefVal Char
    where defVal CharTag = 'X'
instance HasDefVal Bool
    where defVal BoolTag = False

class NodeAndPath a
    where nodeAndPath :: a -> [(Dynamic, Path)]

instance NodeAndPath Integer
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath String
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Char
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Bool
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath ( EEither UType String )
    where nodeAndPath (t@(LLeft t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(RRight t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath ( List Assignment )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List BlockStatement )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List ClassBodyDeclaration )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List Expression )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List JCExpression )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List JCStatement )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List JCTree )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List TypeDeclaration )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( MMaybe JCExpression )
    where nodeAndPath (t@(NNothing)) = [(toDyn t, [])]
          nodeAndPath (t@(JJust t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath ( MMaybe JCVariableDecl )
    where nodeAndPath (t@(NNothing)) = [(toDyn t, [])]
          nodeAndPath (t@(JJust t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath ( MMaybe String )
    where nodeAndPath (t@(NNothing)) = [(toDyn t, [])]
          nodeAndPath (t@(JJust t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath ( Prod UType String )
    where nodeAndPath (t@(Prod t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath UType
    where nodeAndPath (t@(UInteger)) = [(toDyn t, [])]
          nodeAndPath (t@(UString)) = [(toDyn t, [])]
          nodeAndPath (t@(UBool)) = [(toDyn t, [])]
          nodeAndPath (t@(UVoid)) = [(toDyn t, [])]
instance NodeAndPath ULit
    where nodeAndPath (t@(UIntegerLit t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(UStringLit t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(UBoolLit t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath CompilationUnit
    where nodeAndPath (t@(CompilationUnit t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath TypeDeclaration
    where nodeAndPath (t@(FromClassDeclaration t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(TypeDeclarationSkip t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath ClassDeclaration
    where nodeAndPath (t@(NormalClassDeclaration0 t0
                                                  t1
                                                  t2
                                                  t3
                                                  t4
                                                  t5)) = ((((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)) ++ map (\(n,p) -> (n,5:p)) (nodeAndPath t5)
          nodeAndPath (t@(NormalClassDeclaration1 t0
                                                  t1
                                                  t2
                                                  t3
                                                  t4
                                                  t5
                                                  t6)) = (((((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)) ++ map (\(n,p) -> (n,5:p)) (nodeAndPath t5)) ++ map (\(n,p) -> (n,6:p)) (nodeAndPath t6)
          nodeAndPath (t@(NormalClassDeclaration2 t0
                                                  t1
                                                  t2
                                                  t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
          nodeAndPath (t@(NormalClassDeclaration3 t0
                                                  t1
                                                  t2
                                                  t3
                                                  t4)) = (((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)
instance NodeAndPath ClassBody
    where nodeAndPath (t@(ClassBody0 t0
                                     t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(ClassBody1 t0
                                     t1
                                     t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
instance NodeAndPath ClassBodyDeclaration
    where nodeAndPath (t@(FromClassMemberDeclaration t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromInstanceInitializer t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath ClassMemberDeclaration
    where nodeAndPath (t@(FieldDeclaration0 t0
                                            t1
                                            t2
                                            t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
          nodeAndPath (t@(FieldDeclaration1 t0
                                            t1
                                            t2
                                            t3
                                            t4)) = (((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)
          nodeAndPath (t@(MethodDeclaration0 t0
                                             t1
                                             t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(MethodDeclaration1 t0
                                             t1
                                             t2
                                             t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
          nodeAndPath (t@(MemberFromClassDeclaration t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath MethodHeader
    where nodeAndPath (t@(MethodHeader t0
                                       t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath MethodBody
    where nodeAndPath (t@(MethodBody0 t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(MethodBody1 t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath MethodDeclarator
    where nodeAndPath (t@(MethodDeclarator0 t0
                                            t1
                                            t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(MethodDeclarator1 t0
                                            t1
                                            t2
                                            t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
instance NodeAndPath BlockStatement
    where nodeAndPath (t@(LocalVariableDeclaration t0
                                                   t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(BlockFromClassDeclaration t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromStatement t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath Statement
    where nodeAndPath (t@(IfThenElse t0
                                     t1
                                     t2
                                     t3
                                     t4
                                     t5
                                     t6)) = (((((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)) ++ map (\(n,p) -> (n,5:p)) (nodeAndPath t5)) ++ map (\(n,p) -> (n,6:p)) (nodeAndPath t6)
          nodeAndPath (t@(ExpressionStatement t0
                                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(While t0
                                t1
                                t2
                                t3
                                t4)) = (((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)
          nodeAndPath (t@(BasicFor t0
                                   t1
                                   t2
                                   t3
                                   t4
                                   t5
                                   t6
                                   t7
                                   t8)) = (((((((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)) ++ map (\(n,p) -> (n,5:p)) (nodeAndPath t5)) ++ map (\(n,p) -> (n,6:p)) (nodeAndPath t6)) ++ map (\(n,p) -> (n,7:p)) (nodeAndPath t7)) ++ map (\(n,p) -> (n,8:p)) (nodeAndPath t8)
          nodeAndPath (t@(EnhancedFor t0
                                      t1
                                      t2
                                      t3
                                      t4
                                      t5
                                      t6
                                      t7)) = ((((((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)) ++ map (\(n,p) -> (n,5:p)) (nodeAndPath t5)) ++ map (\(n,p) -> (n,6:p)) (nodeAndPath t6)) ++ map (\(n,p) -> (n,7:p)) (nodeAndPath t7)
          nodeAndPath (t@(FromBlockStatement t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath Expression
    where nodeAndPath (t@(AssignExp t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(MethodInvocation0 t0
                                            t1
                                            t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(MethodInvocation1 t0
                                            t1
                                            t2
                                            t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
instance NodeAndPath Assignment
    where nodeAndPath (t@(Assignment t0
                                     t1
                                     t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(FromRelExp t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath VariableDeclarator
    where nodeAndPath (t@(VariableDeclarator0 t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(VariableDeclarator1 t0
                                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath VariableInitializer
    where nodeAndPath (t@(VariableInitializer t0
                                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath RelExp
    where nodeAndPath (t@(RelExp0 t0
                                  t1
                                  t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(FromAdditiveExp t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath AdditiveExp
    where nodeAndPath (t@(AdditiveExp0 t0
                                       t1
                                       t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(AdditiveExp1 t0
                                       t1
                                       t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(FromPostfixExp t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath PostfixExp
    where nodeAndPath (t@(PostIncExp t0
                                     t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(FromPrimary t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(ExpN t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath Primary
    where nodeAndPath (t@(PrimaryLit t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(Paren t0
                                t1
                                t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(FieldAccess t0
                                      t1
                                      t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(ArrayAccess t0
                                      t1
                                      t2
                                      t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
instance NodeAndPath JCCompilationUnit
    where nodeAndPath (t@(JCCompilationUnit t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath JCTree
    where nodeAndPath (t@(FromJCExpression t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCStatement t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCModifier t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCMethodDecl t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath JCExpression
    where nodeAndPath (t@(FromJCPolyExpression t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(JCAssign t0
                                   t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(JCUnary t0
                                  t1
                                  t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(JCBinary t0
                                   t1
                                   t2
                                   t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
          nodeAndPath (t@(JCArrayAccess t0
                                        t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(JCFieldAccess t0
                                        t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(JCIdent t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(JCPrimitiveTypeTree t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCLiteral t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath JCPolyExpression
    where nodeAndPath (t@(JCMethodInvocation t0
                                             t1
                                             t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
instance NodeAndPath JCStatement
    where nodeAndPath (t@(FromJCClassDecl t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCBlock t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCExpressionStatement t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(FromJCVariableDecl t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
          nodeAndPath (t@(JCForLoop t0
                                    t1
                                    t2
                                    t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
          nodeAndPath (t@(JCIf t0
                               t1
                               t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(JCSkip)) = [(toDyn t, [])]
instance NodeAndPath JCClassDecl
    where nodeAndPath (t@(JCClassDecl t0
                                      t1
                                      t2
                                      t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
instance NodeAndPath JCVariableDecl
    where nodeAndPath (t@(JCVariableDecl t0
                                         t1
                                         t2
                                         t3)) = ((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)
instance NodeAndPath JCMethodDecl
    where nodeAndPath (t@(JCMethodDecl t0
                                       t1
                                       t2
                                       t3
                                       t4)) = (((([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)) ++ map (\(n,p) -> (n,3:p)) (nodeAndPath t3)) ++ map (\(n,p) -> (n,4:p)) (nodeAndPath t4)
instance NodeAndPath Tag
    where nodeAndPath (t@(OR)) = [(toDyn t, [])]
          nodeAndPath (t@(LESSTHAN)) = [(toDyn t, [])]
          nodeAndPath (t@(POSTINC)) = [(toDyn t, [])]
          nodeAndPath (t@(PLUS)) = [(toDyn t, [])]
          nodeAndPath (t@(MINUS)) = [(toDyn t, [])]

class IntConv sub sup
    where inj :: sub -> sup
instance IntConv ClassMemberDeclaration ClassBodyDeclaration
    where inj decl = FromClassMemberDeclaration decl
instance IntConv Assignment Expression
    where inj expl = AssignExp expl
instance IntConv Expression Assignment
    where inj expl = FromRelExp (FromAdditiveExp (FromPostfixExp (FromPrimary (Paren "(" expl ")"))))
instance IntConv RelExp Expression
    where inj relExpl = AssignExp (FromRelExp relExpl)
instance IntConv Expression RelExp
    where inj expl = FromAdditiveExp (FromPostfixExp (FromPrimary (Paren "(" expl ")")))
instance IntConv AdditiveExp Expression
    where inj addExpl = AssignExp (FromRelExp (FromAdditiveExp addExpl))
instance IntConv Expression AdditiveExp
    where inj expl = FromPostfixExp (FromPrimary (Paren "(" expl ")"))
instance IntConv PostfixExp Expression
    where inj postExpl = AssignExp (FromRelExp (FromAdditiveExp (FromPostfixExp postExpl)))
instance IntConv Expression PostfixExp
    where inj expl = FromPrimary (Paren "(" expl ")")
instance IntConv RelExp Assignment
    where inj relExpl = FromRelExp relExpl
instance IntConv Assignment RelExp
    where inj expl = FromAdditiveExp (FromPostfixExp (FromPrimary (Paren "(" (AssignExp expl) ")")))
instance IntConv AdditiveExp Assignment
    where inj addExpl = FromRelExp (FromAdditiveExp addExpl)
instance IntConv Assignment AdditiveExp
    where inj expl = FromPostfixExp (FromPrimary (Paren "(" (AssignExp expl) ")"))
instance IntConv PostfixExp Assignment
    where inj postExpl = FromRelExp (FromAdditiveExp (FromPostfixExp postExpl))
instance IntConv Assignment PostfixExp
    where inj expl = FromPrimary (Paren "(" (AssignExp expl) ")")
instance IntConv AdditiveExp RelExp
    where inj addExpl = FromAdditiveExp addExpl
instance IntConv RelExp AdditiveExp
    where inj relExpl = FromPostfixExp (FromPrimary (Paren "(" (AssignExp (FromRelExp relExpl)) ")"))
instance IntConv PostfixExp RelExp
    where inj postExpl = FromAdditiveExp (FromPostfixExp postExpl)
instance IntConv RelExp PostfixExp
    where inj relExpl = FromPrimary (Paren "(" (AssignExp (FromRelExp relExpl)) ")")
instance IntConv PostfixExp AdditiveExp
    where inj postExpl = FromPostfixExp postExpl
instance IntConv AdditiveExp PostfixExp
    where inj addExpl = FromPrimary (Paren "(" (AssignExp (FromRelExp (FromAdditiveExp addExpl))) ")")
mkInj :: SubTyTag -> SupTyTag -> Dynamic -> Dynamic
mkInj (ClassMemberDeclarationTag) (ClassBodyDeclarationTag) s0 | isJust (fromDynamic s0 :: Maybe ClassMemberDeclaration) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe ClassMemberDeclaration)) :: ClassBodyDeclaration
mkInj (AssignmentTag) (ExpressionTag) s0 | isJust (fromDynamic s0 :: Maybe Assignment) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Assignment)) :: Expression
mkInj (ExpressionTag) (AssignmentTag) s0 | isJust (fromDynamic s0 :: Maybe Expression) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Expression)) :: Assignment
mkInj (RelExpTag) (ExpressionTag) s0 | isJust (fromDynamic s0 :: Maybe RelExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe RelExp)) :: Expression
mkInj (ExpressionTag) (RelExpTag) s0 | isJust (fromDynamic s0 :: Maybe Expression) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Expression)) :: RelExp
mkInj (AdditiveExpTag) (ExpressionTag) s0 | isJust (fromDynamic s0 :: Maybe AdditiveExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe AdditiveExp)) :: Expression
mkInj (ExpressionTag) (AdditiveExpTag) s0 | isJust (fromDynamic s0 :: Maybe Expression) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Expression)) :: AdditiveExp
mkInj (PostfixExpTag) (ExpressionTag) s0 | isJust (fromDynamic s0 :: Maybe PostfixExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe PostfixExp)) :: Expression
mkInj (ExpressionTag) (PostfixExpTag) s0 | isJust (fromDynamic s0 :: Maybe Expression) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Expression)) :: PostfixExp
mkInj (RelExpTag) (AssignmentTag) s0 | isJust (fromDynamic s0 :: Maybe RelExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe RelExp)) :: Assignment
mkInj (AssignmentTag) (RelExpTag) s0 | isJust (fromDynamic s0 :: Maybe Assignment) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Assignment)) :: RelExp
mkInj (AdditiveExpTag) (AssignmentTag) s0 | isJust (fromDynamic s0 :: Maybe AdditiveExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe AdditiveExp)) :: Assignment
mkInj (AssignmentTag) (AdditiveExpTag) s0 | isJust (fromDynamic s0 :: Maybe Assignment) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Assignment)) :: AdditiveExp
mkInj (PostfixExpTag) (AssignmentTag) s0 | isJust (fromDynamic s0 :: Maybe PostfixExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe PostfixExp)) :: Assignment
mkInj (AssignmentTag) (PostfixExpTag) s0 | isJust (fromDynamic s0 :: Maybe Assignment) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Assignment)) :: PostfixExp
mkInj (AdditiveExpTag) (RelExpTag) s0 | isJust (fromDynamic s0 :: Maybe AdditiveExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe AdditiveExp)) :: RelExp
mkInj (RelExpTag) (AdditiveExpTag) s0 | isJust (fromDynamic s0 :: Maybe RelExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe RelExp)) :: AdditiveExp
mkInj (PostfixExpTag) (RelExpTag) s0 | isJust (fromDynamic s0 :: Maybe PostfixExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe PostfixExp)) :: RelExp
mkInj (RelExpTag) (PostfixExpTag) s0 | isJust (fromDynamic s0 :: Maybe RelExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe RelExp)) :: PostfixExp
mkInj (PostfixExpTag) (AdditiveExpTag) s0 | isJust (fromDynamic s0 :: Maybe PostfixExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe PostfixExp)) :: AdditiveExp
mkInj (AdditiveExpTag) (PostfixExpTag) s0 | isJust (fromDynamic s0 :: Maybe AdditiveExp) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe AdditiveExp)) :: PostfixExp
mkInj a b c | a == b = c

selSPat :: TyTag -> TyTag -> Dynamic -> RegPat
selSPat (CompilationUnitTag) (JCCompilationUnitTag) ((fromDynamic :: Dynamic -> Maybe JCCompilationUnit) -> Just (JCCompilationUnit tyDecsr0)) = CompilationUnitJCCompilationUnitS0
selSPat (TypeDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (JCSkip))) = TypeDeclarationJCTreeS0
selSPat (TypeDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just classr0) = TypeDeclarationJCTreeS1
selSPat (ClassDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (NNothing)
                                                                                                                                           nr0
                                                                                                                                           (JJust (JCIdent supr1))
                                                                                                                                           bodyr2)))) = ClassDeclarationJCTreeS0
selSPat (ClassDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust mdfr0)
                                                                                                                                           nr1
                                                                                                                                           (JJust (JCIdent supr2))
                                                                                                                                           bodyr3)))) = ClassDeclarationJCTreeS1
selSPat (ClassDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (NNothing)
                                                                                                                                           nr0
                                                                                                                                           (NNothing)
                                                                                                                                           bodyr1)))) = ClassDeclarationJCTreeS2
selSPat (ClassDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust mdfr0)
                                                                                                                                           nr1
                                                                                                                                           (NNothing)
                                                                                                                                           bodyr2)))) = ClassDeclarationJCTreeS3
selSPat (ClassBodyTag) (ListJCTreeTag) ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just (Nil)) = ClassBodyListJCTreeS0
selSPat (ClassBodyTag) (ListJCTreeTag) ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just decsr0) = ClassBodyListJCTreeS1
selSPat (ClassBodyDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just decr0) = ClassBodyDeclarationJCTreeS0
selSPat (ClassBodyDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCBlock decr0))) = ClassBodyDeclarationJCTreeS1
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                       varNamer0
                                                                                                                                                       (JCPrimitiveTypeTree tyr1)
                                                                                                                                                       (NNothing))))) = ClassMemberDeclarationJCTreeS0
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (JJust mdfr0)
                                                                                                                                                       varNamer1
                                                                                                                                                       (JCPrimitiveTypeTree tyr2)
                                                                                                                                                       (NNothing))))) = ClassMemberDeclarationJCTreeS1
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                       varNamer0
                                                                                                                                                       (JCPrimitiveTypeTree tyr1)
                                                                                                                                                       (JJust initValr2))))) = ClassMemberDeclarationJCTreeS2
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (JJust mdfr0)
                                                                                                                                                       varNamer1
                                                                                                                                                       (JCPrimitiveTypeTree tyr2)
                                                                                                                                                       (JJust initValr3))))) = ClassMemberDeclarationJCTreeS3
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCMethodDecl (JCMethodDecl (NNothing)
                                                                                                                                  methNamer0
                                                                                                                                  resTyper1
                                                                                                                                  (NNothing)
                                                                                                                                  bodyr2))) = ClassMemberDeclarationJCTreeS4
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCMethodDecl (JCMethodDecl (JJust mdfr0)
                                                                                                                                  methNamer1
                                                                                                                                  resTyper2
                                                                                                                                  (NNothing)
                                                                                                                                  bodyr3))) = ClassMemberDeclarationJCTreeS5
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCMethodDecl (JCMethodDecl (NNothing)
                                                                                                                                  methNamer0
                                                                                                                                  resTyper1
                                                                                                                                  (JJust argr2)
                                                                                                                                  bodyr3))) = ClassMemberDeclarationJCTreeS6
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just (FromJCMethodDecl (JCMethodDecl (JJust mdfr0)
                                                                                                                                  methNamer1
                                                                                                                                  resTyper2
                                                                                                                                  (JJust argr3)
                                                                                                                                  bodyr4))) = ClassMemberDeclarationJCTreeS7
selSPat (ClassMemberDeclarationTag) (JCTreeTag) ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just classDecr0) = ClassMemberDeclarationJCTreeS8
selSPat (EEitherUTypeStringTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCPrimitiveTypeTree resTyper0)) = EEitherUTypeStringJCExpressionS0
selSPat (EEitherUTypeStringTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCPrimitiveTypeTree (UVoid))) = EEitherUTypeStringJCExpressionS1
selSPat (ProdUTypeStringTag) (JCVariableDeclTag) ((fromDynamic :: Dynamic -> Maybe JCVariableDecl) -> Just (JCVariableDecl (NNothing)
                                                                                                                           namer0
                                                                                                                           (JCPrimitiveTypeTree tyr1)
                                                                                                                           (NNothing))) = ProdUTypeStringJCVariableDeclS0
selSPat (MethodBodyTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just stmtsr0) = MethodBodyListJCStatementS0
selSPat (MethodBodyTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just (Cons (JCSkip)
                                                                                                                   (Nil))) = MethodBodyListJCStatementS1
selSPat (BlockStatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                        varNamer0
                                                                                                                                        (JCPrimitiveTypeTree tyr1)
                                                                                                                                        (NNothing)))) = BlockStatementJCStatementS0
selSPat (BlockStatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                        varNamer0
                                                                                                                                        (JCPrimitiveTypeTree tyr1)
                                                                                                                                        (JJust initValr2)))) = BlockStatementJCStatementS1
selSPat (BlockStatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCClassDecl classDecr0)) = BlockStatementJCStatementS2
selSPat (BlockStatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just stmtr0) = BlockStatementJCStatementS3
selSPat (ClassDeclarationTag) (JCClassDeclTag) ((fromDynamic :: Dynamic -> Maybe JCClassDecl) -> Just (JCClassDecl (NNothing)
                                                                                                                   nr0
                                                                                                                   (JJust (JCIdent supr1))
                                                                                                                   bodyr2)) = ClassDeclarationJCClassDeclS0
selSPat (ClassDeclarationTag) (JCClassDeclTag) ((fromDynamic :: Dynamic -> Maybe JCClassDecl) -> Just (JCClassDecl (JJust mdfr0)
                                                                                                                   nr1
                                                                                                                   (JJust (JCIdent supr2))
                                                                                                                   bodyr3)) = ClassDeclarationJCClassDeclS1
selSPat (ClassDeclarationTag) (JCClassDeclTag) ((fromDynamic :: Dynamic -> Maybe JCClassDecl) -> Just (JCClassDecl (NNothing)
                                                                                                                   nr0
                                                                                                                   (NNothing)
                                                                                                                   bodyr1)) = ClassDeclarationJCClassDeclS2
selSPat (ClassDeclarationTag) (JCClassDeclTag) ((fromDynamic :: Dynamic -> Maybe JCClassDecl) -> Just (JCClassDecl (JJust mdfr0)
                                                                                                                   nr1
                                                                                                                   (NNothing)
                                                                                                                   bodyr2)) = ClassDeclarationJCClassDeclS3
selSPat (ExpressionTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just expr0) = ExpressionJCExpressionS0
selSPat (ExpressionTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (FromJCPolyExpression (JCMethodInvocation (Nil)
                                                                                                                                            (JCIdent methNamer0)
                                                                                                                                            (NNothing)))) = ExpressionJCExpressionS1
selSPat (ExpressionTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (FromJCPolyExpression (JCMethodInvocation (Nil)
                                                                                                                                            (JCIdent methNamer0)
                                                                                                                                            (JJust argr1)))) = ExpressionJCExpressionS2
selSPat (StatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCExpressionStatement exprr0)) = StatementJCStatementS0
selSPat (StatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (JCIf condr0
                                                                                                     trueStmtr1
                                                                                                     falseStmtr2)) = StatementJCStatementS1
selSPat (StatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (JCForLoop varDeclr0
                                                                                                          expr1
                                                                                                          updr2
                                                                                                          stmtr3)) = StatementJCStatementS2
selSPat (StatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (JCForLoop (Nil)
                                                                                                          expr0
                                                                                                          (Nil)
                                                                                                          stmtr1)) = StatementJCStatementS3
selSPat (StatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (JCForLoop (Cons (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                    "i"
                                                                                                                                                    (JCPrimitiveTypeTree (UInteger))
                                                                                                                                                    (JJust (FromJCLiteral (UIntegerLit 0)))))
                                                                                                                (Nil))
                                                                                                          (JCBinary (LESSTHAN)
                                                                                                                    (JCIdent "i")
                                                                                                                    (JCFieldAccess expr0
                                                                                                                                   "length")
                                                                                                                    "<")
                                                                                                          (Cons (JCUnary (POSTINC)
                                                                                                                         (JCIdent "i")
                                                                                                                         "++")
                                                                                                                (Nil))
                                                                                                          (FromJCBlock (Cons (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                 varr1
                                                                                                                                                                 (JCPrimitiveTypeTree tyr2)
                                                                                                                                                                 (JJust (JCArrayAccess expr3
                                                                                                                                                                                       (JCIdent "i")))))
                                                                                                                             stmtr4)))) = StatementJCStatementS4
selSPat (StatementTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCBlock blockr0)) = StatementJCStatementS5
selSPat (StatementTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just blockr0) = StatementListJCStatementS0
selSPat (AssignmentTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCExpressionStatement (JCAssign (JCIdent namer0)
                                                                                                                                     rhsr1))) = AssignmentJCStatementS0
selSPat (AssignmentTag) (JCStatementTag) ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just (FromJCExpressionStatement relExpr0)) = AssignmentJCStatementS1
selSPat (AssignmentTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCAssign (JCIdent namer0)
                                                                                                            rhsr1)) = AssignmentJCExpressionS0
selSPat (AssignmentTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just relExpr0) = AssignmentJCExpressionS1
selSPat (RelExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCBinary (LESSTHAN)
                                                                                                        lhsr0
                                                                                                        rhsr1
                                                                                                        "<")) = RelExpJCExpressionS0
selSPat (RelExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just addExpr0) = RelExpJCExpressionS1
selSPat (AdditiveExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCBinary (PLUS)
                                                                                                             lhsr0
                                                                                                             rhsr1
                                                                                                             "+")) = AdditiveExpJCExpressionS0
selSPat (AdditiveExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCBinary (MINUS)
                                                                                                             lhsr0
                                                                                                             rhsr1
                                                                                                             "-")) = AdditiveExpJCExpressionS1
selSPat (AdditiveExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just postExpr0) = AdditiveExpJCExpressionS2
selSPat (PostfixExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCUnary (POSTINC)
                                                                                                           pfixr0
                                                                                                           "++")) = PostfixExpJCExpressionS0
selSPat (PostfixExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCIdent idr0)) = PostfixExpJCExpressionS1
selSPat (PostfixExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (FromJCLiteral litr0)) = PostfixExpJCExpressionS2
selSPat (PostfixExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCFieldAccess (JCIdent nr0)
                                                                                                                 fnamer1)) = PostfixExpJCExpressionS3
selSPat (PostfixExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just (JCArrayAccess (JCIdent nr0)
                                                                                                                 expr1)) = PostfixExpJCExpressionS4
selSPat (PostfixExpTag) (JCExpressionTag) ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just expr0) = PostfixExpJCExpressionS5
selSPat (ListTypeDeclarationTag) (ListJCTreeTag) ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just (Cons tDecr0
                                                                                                                  tDecsr1)) = ListTypeDeclarationListJCTreeS0
selSPat (ListTypeDeclarationTag) (ListJCTreeTag) ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just (Nil)) = ListTypeDeclarationListJCTreeS1
selSPat (ListClassBodyDeclarationTag) (ListJCTreeTag) ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just (Nil)) = ListClassBodyDeclarationListJCTreeS0
selSPat (ListClassBodyDeclarationTag) (ListJCTreeTag) ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just (Cons ar0
                                                                                                                       asr1)) = ListClassBodyDeclarationListJCTreeS1
selSPat (ListBlockStatementTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just (Nil)) = ListBlockStatementListJCStatementS0
selSPat (ListBlockStatementTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just (Cons ar0
                                                                                                                           asr1)) = ListBlockStatementListJCStatementS1
selSPat (ListExpressionTag) (ListJCExpressionTag) ((fromDynamic :: Dynamic -> Maybe ( List JCExpression )) -> Just (Nil)) = ListExpressionListJCExpressionS0
selSPat (ListExpressionTag) (ListJCExpressionTag) ((fromDynamic :: Dynamic -> Maybe ( List JCExpression )) -> Just (Cons er0
                                                                                                                         esr1)) = ListExpressionListJCExpressionS1
selSPat (ListAssignmentTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just (Nil)) = ListAssignmentListJCStatementS0
selSPat (ListAssignmentTag) (ListJCStatementTag) ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just (Cons assr0
                                                                                                                       asssr1)) = ListAssignmentListJCStatementS1
selSPat (UTypeTag) (UTypeTag) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UInteger)) = UTypeUTypeS0
selSPat (UTypeTag) (UTypeTag) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UString)) = UTypeUTypeS1
selSPat (UTypeTag) (UTypeTag) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UBool)) = UTypeUTypeS2
selSPat (UTypeTag) (UTypeTag) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UVoid)) = UTypeUTypeS3
selSPat (ULitTag) (ULitTag) ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UIntegerLit ir0)) = ULitULitS0
selSPat (ULitTag) (ULitTag) ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UStringLit sr0)) = ULitULitS1
selSPat (ULitTag) (ULitTag) ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UBoolLit br0)) = ULitULitS2
selSPat (IntegerTag) (IntegerTag) ((fromDynamic :: Dynamic -> Maybe Integer) -> Just prim) = IntegerR
selSPat (StringTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just prim) = StringR
selSPat (CharTag) (CharTag) ((fromDynamic :: Dynamic -> Maybe Char) -> Just prim) = CharR
selSPat (BoolTag) (BoolTag) ((fromDynamic :: Dynamic -> Maybe Bool) -> Just prim) = BoolR
selSPat x y z = (error $ "panic. source tag: " ++ show x ++ "\nview tag " ++ show y ++ "\nnot found!\n" ++ show z)

askDynTyTag :: Dynamic -> TyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( EEither UType String )) -> Just _) = EEitherUTypeStringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List Assignment )) -> Just _) = ListAssignmentTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List BlockStatement )) -> Just _) = ListBlockStatementTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List ClassBodyDeclaration )) -> Just _) = ListClassBodyDeclarationTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List Expression )) -> Just _) = ListExpressionTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List JCExpression )) -> Just _) = ListJCExpressionTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List JCStatement )) -> Just _) = ListJCStatementTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List JCTree )) -> Just _) = ListJCTreeTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List TypeDeclaration )) -> Just _) = ListTypeDeclarationTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( MMaybe JCExpression )) -> Just _) = MMaybeJCExpressionTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( MMaybe JCVariableDecl )) -> Just _) = MMaybeJCVariableDeclTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( MMaybe String )) -> Just _) = MMaybeStringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( Prod UType String )) -> Just _) = ProdUTypeStringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe UType) -> Just _) = UTypeTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ULit) -> Just _) = ULitTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe CompilationUnit) -> Just _) = CompilationUnitTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe TypeDeclaration) -> Just _) = TypeDeclarationTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just _) = ClassDeclarationTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ClassBody) -> Just _) = ClassBodyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ClassBodyDeclaration) -> Just _) = ClassBodyDeclarationTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just _) = ClassMemberDeclarationTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe MethodHeader) -> Just _) = MethodHeaderTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe MethodBody) -> Just _) = MethodBodyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe MethodDeclarator) -> Just _) = MethodDeclaratorTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just _) = BlockStatementTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Statement) -> Just _) = StatementTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Expression) -> Just _) = ExpressionTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just _) = AssignmentTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe VariableDeclarator) -> Just _) = VariableDeclaratorTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe VariableInitializer) -> Just _) = VariableInitializerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe RelExp) -> Just _) = RelExpTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just _) = AdditiveExpTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just _) = PostfixExpTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Primary) -> Just _) = PrimaryTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCCompilationUnit) -> Just _) = JCCompilationUnitTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCTree) -> Just _) = JCTreeTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCExpression) -> Just _) = JCExpressionTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCPolyExpression) -> Just _) = JCPolyExpressionTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCStatement) -> Just _) = JCStatementTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCClassDecl) -> Just _) = JCClassDeclTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCVariableDecl) -> Just _) = JCVariableDeclTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe JCMethodDecl) -> Just _) = JCMethodDeclTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Tag) -> Just _) = TagTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Integer) -> Just _) = IntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe String) -> Just _) = StringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Char) -> Just _) = CharTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Bool) -> Just _) = BoolTag

splice :: OSDyn -> RLink -> SDyn -> SDyn
splice osDyn imag s0 = insSubtree sReg (fetch' (askDynTyTag osDyn) osDyn imag) s0
  where
    ((sReg,_),(Void,[])) = imag

repSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
repSubtree CompilationUnitJCCompilationUnitS0 ((fromDynamic :: Dynamic -> Maybe CompilationUnit) -> Just (CompilationUnit ltyDecsl0)) ((fromDynamic :: Dynamic -> Maybe CompilationUnit) -> Just (CompilationUnit rtyDecsl0)) = toDyn (CompilationUnit rtyDecsl0 :: CompilationUnit)
repSubtree TypeDeclarationJCTreeS0 ((fromDynamic :: Dynamic -> Maybe TypeDeclaration) -> Just (TypeDeclarationSkip ";")) ((fromDynamic :: Dynamic -> Maybe TypeDeclaration) -> Just (TypeDeclarationSkip ";")) = toDyn (TypeDeclarationSkip ";" :: TypeDeclaration)
repSubtree TypeDeclarationJCTreeS1 ((fromDynamic :: Dynamic -> Maybe TypeDeclaration) -> Just (FromClassDeclaration lclassl0)) ((fromDynamic :: Dynamic -> Maybe TypeDeclaration) -> Just (FromClassDeclaration rclassl0)) = toDyn (FromClassDeclaration rclassl0 :: TypeDeclaration)
repSubtree ClassDeclarationJCTreeS0 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration0 fromWild0fromWild0
                                                                                                                         "class"
                                                                                                                         lnl0
                                                                                                                         "extends"
                                                                                                                         lsupl1
                                                                                                                         lbodyl2)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration0 _
                                                                                                                                                                                                                        "class"
                                                                                                                                                                                                                        rnl0
                                                                                                                                                                                                                        "extends"
                                                                                                                                                                                                                        rsupl1
                                                                                                                                                                                                                        rbodyl2)) = toDyn (NormalClassDeclaration0 fromWild0fromWild0 "class" rnl0 "extends" rsupl1 rbodyl2 :: ClassDeclaration)
repSubtree ClassDeclarationJCTreeS1 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration1 fromWild0fromWild0
                                                                                                                         lmdfl0
                                                                                                                         "class"
                                                                                                                         lnl1
                                                                                                                         "extends"
                                                                                                                         lsupl2
                                                                                                                         lbodyl3)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration1 _
                                                                                                                                                                                                                        rmdfl0
                                                                                                                                                                                                                        "class"
                                                                                                                                                                                                                        rnl1
                                                                                                                                                                                                                        "extends"
                                                                                                                                                                                                                        rsupl2
                                                                                                                                                                                                                        rbodyl3)) = toDyn (NormalClassDeclaration1 fromWild0fromWild0 rmdfl0 "class" rnl1 "extends" rsupl2 rbodyl3 :: ClassDeclaration)
repSubtree ClassDeclarationJCTreeS2 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration2 fromWild0fromWild0
                                                                                                                         "class"
                                                                                                                         lnl0
                                                                                                                         lbodyl1)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration2 _
                                                                                                                                                                                                                        "class"
                                                                                                                                                                                                                        rnl0
                                                                                                                                                                                                                        rbodyl1)) = toDyn (NormalClassDeclaration2 fromWild0fromWild0 "class" rnl0 rbodyl1 :: ClassDeclaration)
repSubtree ClassDeclarationJCTreeS3 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration3 fromWild0fromWild0
                                                                                                                         lmdfl0
                                                                                                                         "class"
                                                                                                                         lnl1
                                                                                                                         lbodyl2)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration3 _
                                                                                                                                                                                                                        rmdfl0
                                                                                                                                                                                                                        "class"
                                                                                                                                                                                                                        rnl1
                                                                                                                                                                                                                        rbodyl2)) = toDyn (NormalClassDeclaration3 fromWild0fromWild0 rmdfl0 "class" rnl1 rbodyl2 :: ClassDeclaration)
repSubtree ClassBodyListJCTreeS0 ((fromDynamic :: Dynamic -> Maybe ClassBody) -> Just (ClassBody0 "{"
                                                                                                  "}")) ((fromDynamic :: Dynamic -> Maybe ClassBody) -> Just (ClassBody0 "{"
                                                                                                                                                                         "}")) = toDyn (ClassBody0 "{" "}" :: ClassBody)
repSubtree ClassBodyListJCTreeS1 ((fromDynamic :: Dynamic -> Maybe ClassBody) -> Just (ClassBody1 "{"
                                                                                                  ldecsl0
                                                                                                  "}")) ((fromDynamic :: Dynamic -> Maybe ClassBody) -> Just (ClassBody1 "{"
                                                                                                                                                                         rdecsl0
                                                                                                                                                                         "}")) = toDyn (ClassBody1 "{" rdecsl0 "}" :: ClassBody)
repSubtree ClassBodyDeclarationJCTreeS0 ((fromDynamic :: Dynamic -> Maybe ClassBodyDeclaration) -> Just (FromClassMemberDeclaration ldecl0)) ((fromDynamic :: Dynamic -> Maybe ClassBodyDeclaration) -> Just (FromClassMemberDeclaration rdecl0)) = toDyn (FromClassMemberDeclaration rdecl0 :: ClassBodyDeclaration)
repSubtree ClassBodyDeclarationJCTreeS1 ((fromDynamic :: Dynamic -> Maybe ClassBodyDeclaration) -> Just (FromInstanceInitializer ldecl0)) ((fromDynamic :: Dynamic -> Maybe ClassBodyDeclaration) -> Just (FromInstanceInitializer rdecl0)) = toDyn (FromInstanceInitializer rdecl0 :: ClassBodyDeclaration)
repSubtree ClassMemberDeclarationJCTreeS0 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration0 fromWild0fromWild0
                                                                                                                               ltyl0
                                                                                                                               (VariableDeclarator0 lvarNamel1)
                                                                                                                               ";")) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration0 _
                                                                                                                                                                                                                          rtyl0
                                                                                                                                                                                                                          (VariableDeclarator0 rvarNamel1)
                                                                                                                                                                                                                          ";")) = toDyn (FieldDeclaration0 fromWild0fromWild0 rtyl0 (VariableDeclarator0 rvarNamel1) ";" :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS1 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration1 fromWild0fromWild0
                                                                                                                               lmdfl0
                                                                                                                               ltyl1
                                                                                                                               (VariableDeclarator0 lvarNamel2)
                                                                                                                               ";")) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration1 _
                                                                                                                                                                                                                          rmdfl0
                                                                                                                                                                                                                          rtyl1
                                                                                                                                                                                                                          (VariableDeclarator0 rvarNamel2)
                                                                                                                                                                                                                          ";")) = toDyn (FieldDeclaration1 fromWild0fromWild0 rmdfl0 rtyl1 (VariableDeclarator0 rvarNamel2) ";" :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS2 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration0 fromWild0fromWild0
                                                                                                                               ltyl0
                                                                                                                               (VariableDeclarator1 lvarNamel1
                                                                                                                                                    (VariableInitializer "="
                                                                                                                                                                         linitVall2))
                                                                                                                               ";")) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration0 _
                                                                                                                                                                                                                          rtyl0
                                                                                                                                                                                                                          (VariableDeclarator1 rvarNamel1
                                                                                                                                                                                                                                               (VariableInitializer "="
                                                                                                                                                                                                                                                                    rinitVall2))
                                                                                                                                                                                                                          ";")) = toDyn (FieldDeclaration0 fromWild0fromWild0 rtyl0 (VariableDeclarator1 rvarNamel1 (VariableInitializer "=" rinitVall2)) ";" :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS3 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration1 fromWild0fromWild0
                                                                                                                               lmdfl0
                                                                                                                               ltyl1
                                                                                                                               (VariableDeclarator1 lvarNamel2
                                                                                                                                                    (VariableInitializer "="
                                                                                                                                                                         linitVall3))
                                                                                                                               ";")) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (FieldDeclaration1 _
                                                                                                                                                                                                                          rmdfl0
                                                                                                                                                                                                                          rtyl1
                                                                                                                                                                                                                          (VariableDeclarator1 rvarNamel2
                                                                                                                                                                                                                                               (VariableInitializer "="
                                                                                                                                                                                                                                                                    rinitVall3))
                                                                                                                                                                                                                          ";")) = toDyn (FieldDeclaration1 fromWild0fromWild0 rmdfl0 rtyl1 (VariableDeclarator1 rvarNamel2 (VariableInitializer "=" rinitVall3)) ";" :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS4 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration0 fromWild0fromWild0
                                                                                                                                (MethodHeader lresTypel0
                                                                                                                                              (MethodDeclarator0 lmethNamel1
                                                                                                                                                                 "("
                                                                                                                                                                 ")"))
                                                                                                                                lbodyl2)) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration0 _
                                                                                                                                                                                                                                (MethodHeader rresTypel0
                                                                                                                                                                                                                                              (MethodDeclarator0 rmethNamel1
                                                                                                                                                                                                                                                                 "("
                                                                                                                                                                                                                                                                 ")"))
                                                                                                                                                                                                                                rbodyl2)) = toDyn (MethodDeclaration0 fromWild0fromWild0 (MethodHeader rresTypel0 (MethodDeclarator0 rmethNamel1 "(" ")")) rbodyl2 :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS5 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration1 fromWild0fromWild0
                                                                                                                                lmdfl0
                                                                                                                                (MethodHeader lresTypel1
                                                                                                                                              (MethodDeclarator0 lmethNamel2
                                                                                                                                                                 "("
                                                                                                                                                                 ")"))
                                                                                                                                lbodyl3)) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration1 _
                                                                                                                                                                                                                                rmdfl0
                                                                                                                                                                                                                                (MethodHeader rresTypel1
                                                                                                                                                                                                                                              (MethodDeclarator0 rmethNamel2
                                                                                                                                                                                                                                                                 "("
                                                                                                                                                                                                                                                                 ")"))
                                                                                                                                                                                                                                rbodyl3)) = toDyn (MethodDeclaration1 fromWild0fromWild0 rmdfl0 (MethodHeader rresTypel1 (MethodDeclarator0 rmethNamel2 "(" ")")) rbodyl3 :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS6 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration0 fromWild0fromWild0
                                                                                                                                (MethodHeader lresTypel0
                                                                                                                                              (MethodDeclarator1 lmethNamel1
                                                                                                                                                                 "("
                                                                                                                                                                 largl2
                                                                                                                                                                 ")"))
                                                                                                                                lbodyl3)) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration0 _
                                                                                                                                                                                                                                (MethodHeader rresTypel0
                                                                                                                                                                                                                                              (MethodDeclarator1 rmethNamel1
                                                                                                                                                                                                                                                                 "("
                                                                                                                                                                                                                                                                 rargl2
                                                                                                                                                                                                                                                                 ")"))
                                                                                                                                                                                                                                rbodyl3)) = toDyn (MethodDeclaration0 fromWild0fromWild0 (MethodHeader rresTypel0 (MethodDeclarator1 rmethNamel1 "(" rargl2 ")")) rbodyl3 :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS7 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration1 fromWild0fromWild0
                                                                                                                                lmdfl0
                                                                                                                                (MethodHeader lresTypel1
                                                                                                                                              (MethodDeclarator1 lmethNamel2
                                                                                                                                                                 "("
                                                                                                                                                                 largl3
                                                                                                                                                                 ")"))
                                                                                                                                lbodyl4)) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MethodDeclaration1 _
                                                                                                                                                                                                                                rmdfl0
                                                                                                                                                                                                                                (MethodHeader rresTypel1
                                                                                                                                                                                                                                              (MethodDeclarator1 rmethNamel2
                                                                                                                                                                                                                                                                 "("
                                                                                                                                                                                                                                                                 rargl3
                                                                                                                                                                                                                                                                 ")"))
                                                                                                                                                                                                                                rbodyl4)) = toDyn (MethodDeclaration1 fromWild0fromWild0 rmdfl0 (MethodHeader rresTypel1 (MethodDeclarator1 rmethNamel2 "(" rargl3 ")")) rbodyl4 :: ClassMemberDeclaration)
repSubtree ClassMemberDeclarationJCTreeS8 ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MemberFromClassDeclaration lclassDecl0)) ((fromDynamic :: Dynamic -> Maybe ClassMemberDeclaration) -> Just (MemberFromClassDeclaration rclassDecl0)) = toDyn (MemberFromClassDeclaration rclassDecl0 :: ClassMemberDeclaration)
repSubtree EEitherUTypeStringJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe ( EEither UType String )) -> Just (LLeft lresTypel0)) ((fromDynamic :: Dynamic -> Maybe ( EEither UType String )) -> Just (LLeft rresTypel0)) = toDyn (LLeft rresTypel0 :: ( EEither UType String ))
repSubtree EEitherUTypeStringJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe ( EEither UType String )) -> Just (RRight "void")) ((fromDynamic :: Dynamic -> Maybe ( EEither UType String )) -> Just (RRight "void")) = toDyn (RRight "void" :: ( EEither UType String ))
repSubtree ProdUTypeStringJCVariableDeclS0 ((fromDynamic :: Dynamic -> Maybe ( Prod UType String )) -> Just (Prod ltyl0
                                                                                                                  lnamel1)) ((fromDynamic :: Dynamic -> Maybe ( Prod UType String )) -> Just (Prod rtyl0
                                                                                                                                                                                                   rnamel1)) = toDyn (Prod rtyl0 rnamel1 :: ( Prod UType String ))
repSubtree MethodBodyListJCStatementS0 ((fromDynamic :: Dynamic -> Maybe MethodBody) -> Just (MethodBody0 lstmtsl0)) ((fromDynamic :: Dynamic -> Maybe MethodBody) -> Just (MethodBody0 rstmtsl0)) = toDyn (MethodBody0 rstmtsl0 :: MethodBody)
repSubtree MethodBodyListJCStatementS1 ((fromDynamic :: Dynamic -> Maybe MethodBody) -> Just (MethodBody1 ";")) ((fromDynamic :: Dynamic -> Maybe MethodBody) -> Just (MethodBody1 ";")) = toDyn (MethodBody1 ";" :: MethodBody)
repSubtree BlockStatementJCStatementS0 ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (LocalVariableDeclaration ltyl0
                                                                                                                           (VariableDeclarator0 lvarNamel1))) ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (LocalVariableDeclaration rtyl0
                                                                                                                                                                                                                                                  (VariableDeclarator0 rvarNamel1))) = toDyn (LocalVariableDeclaration rtyl0 (VariableDeclarator0 rvarNamel1) :: BlockStatement)
repSubtree BlockStatementJCStatementS1 ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (LocalVariableDeclaration ltyl0
                                                                                                                           (VariableDeclarator1 lvarNamel1
                                                                                                                                                (VariableInitializer "="
                                                                                                                                                                     linitVall2)))) ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (LocalVariableDeclaration rtyl0
                                                                                                                                                                                                                                                                        (VariableDeclarator1 rvarNamel1
                                                                                                                                                                                                                                                                                             (VariableInitializer "="
                                                                                                                                                                                                                                                                                                                  rinitVall2)))) = toDyn (LocalVariableDeclaration rtyl0 (VariableDeclarator1 rvarNamel1 (VariableInitializer "=" rinitVall2)) :: BlockStatement)
repSubtree BlockStatementJCStatementS2 ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (BlockFromClassDeclaration lclassDecl0)) ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (BlockFromClassDeclaration rclassDecl0)) = toDyn (BlockFromClassDeclaration rclassDecl0 :: BlockStatement)
repSubtree BlockStatementJCStatementS3 ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (FromStatement lstmtl0)) ((fromDynamic :: Dynamic -> Maybe BlockStatement) -> Just (FromStatement rstmtl0)) = toDyn (FromStatement rstmtl0 :: BlockStatement)
repSubtree ClassDeclarationJCClassDeclS0 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration0 fromWild0fromWild0
                                                                                                                              "class"
                                                                                                                              lnl0
                                                                                                                              "extends"
                                                                                                                              lsupl1
                                                                                                                              lbodyl2)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration0 _
                                                                                                                                                                                                                             "class"
                                                                                                                                                                                                                             rnl0
                                                                                                                                                                                                                             "extends"
                                                                                                                                                                                                                             rsupl1
                                                                                                                                                                                                                             rbodyl2)) = toDyn (NormalClassDeclaration0 fromWild0fromWild0 "class" rnl0 "extends" rsupl1 rbodyl2 :: ClassDeclaration)
repSubtree ClassDeclarationJCClassDeclS1 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration1 fromWild0fromWild0
                                                                                                                              lmdfl0
                                                                                                                              "class"
                                                                                                                              lnl1
                                                                                                                              "extends"
                                                                                                                              lsupl2
                                                                                                                              lbodyl3)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration1 _
                                                                                                                                                                                                                             rmdfl0
                                                                                                                                                                                                                             "class"
                                                                                                                                                                                                                             rnl1
                                                                                                                                                                                                                             "extends"
                                                                                                                                                                                                                             rsupl2
                                                                                                                                                                                                                             rbodyl3)) = toDyn (NormalClassDeclaration1 fromWild0fromWild0 rmdfl0 "class" rnl1 "extends" rsupl2 rbodyl3 :: ClassDeclaration)
repSubtree ClassDeclarationJCClassDeclS2 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration2 fromWild0fromWild0
                                                                                                                              "class"
                                                                                                                              lnl0
                                                                                                                              lbodyl1)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration2 _
                                                                                                                                                                                                                             "class"
                                                                                                                                                                                                                             rnl0
                                                                                                                                                                                                                             rbodyl1)) = toDyn (NormalClassDeclaration2 fromWild0fromWild0 "class" rnl0 rbodyl1 :: ClassDeclaration)
repSubtree ClassDeclarationJCClassDeclS3 ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration3 fromWild0fromWild0
                                                                                                                              lmdfl0
                                                                                                                              "class"
                                                                                                                              lnl1
                                                                                                                              lbodyl2)) ((fromDynamic :: Dynamic -> Maybe ClassDeclaration) -> Just (NormalClassDeclaration3 _
                                                                                                                                                                                                                             rmdfl0
                                                                                                                                                                                                                             "class"
                                                                                                                                                                                                                             rnl1
                                                                                                                                                                                                                             rbodyl2)) = toDyn (NormalClassDeclaration3 fromWild0fromWild0 rmdfl0 "class" rnl1 rbodyl2 :: ClassDeclaration)
repSubtree ExpressionJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe Expression) -> Just (AssignExp lexpl0)) ((fromDynamic :: Dynamic -> Maybe Expression) -> Just (AssignExp rexpl0)) = toDyn (AssignExp rexpl0 :: Expression)
repSubtree ExpressionJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe Expression) -> Just (MethodInvocation0 lmethNamel0
                                                                                                             "("
                                                                                                             ")")) ((fromDynamic :: Dynamic -> Maybe Expression) -> Just (MethodInvocation0 rmethNamel0
                                                                                                                                                                                            "("
                                                                                                                                                                                            ")")) = toDyn (MethodInvocation0 rmethNamel0 "(" ")" :: Expression)
repSubtree ExpressionJCExpressionS2 ((fromDynamic :: Dynamic -> Maybe Expression) -> Just (MethodInvocation1 lmethNamel0
                                                                                                             "("
                                                                                                             largl1
                                                                                                             ")")) ((fromDynamic :: Dynamic -> Maybe Expression) -> Just (MethodInvocation1 rmethNamel0
                                                                                                                                                                                            "("
                                                                                                                                                                                            rargl1
                                                                                                                                                                                            ")")) = toDyn (MethodInvocation1 rmethNamel0 "(" rargl1 ")" :: Expression)
repSubtree StatementJCStatementS0 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (ExpressionStatement lexprl0
                                                                                                            ";")) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (ExpressionStatement rexprl0
                                                                                                                                                                                            ";")) = toDyn (ExpressionStatement rexprl0 ";" :: Statement)
repSubtree StatementJCStatementS1 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (IfThenElse "if"
                                                                                                   "("
                                                                                                   lcondl0
                                                                                                   ")"
                                                                                                   ltrueStmtl1
                                                                                                   "else"
                                                                                                   lfalseStmtl2)) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (IfThenElse "if"
                                                                                                                                                                                   "("
                                                                                                                                                                                   rcondl0
                                                                                                                                                                                   ")"
                                                                                                                                                                                   rtrueStmtl1
                                                                                                                                                                                   "else"
                                                                                                                                                                                   rfalseStmtl2)) = toDyn (IfThenElse "if" "(" rcondl0 ")" rtrueStmtl1 "else" rfalseStmtl2 :: Statement)
repSubtree StatementJCStatementS2 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (BasicFor "for"
                                                                                                 "("
                                                                                                 lvarDecll0
                                                                                                 ";"
                                                                                                 lexpl1
                                                                                                 ";"
                                                                                                 lupdl2
                                                                                                 ")"
                                                                                                 lstmtl3)) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (BasicFor "for"
                                                                                                                                                                          "("
                                                                                                                                                                          rvarDecll0
                                                                                                                                                                          ";"
                                                                                                                                                                          rexpl1
                                                                                                                                                                          ";"
                                                                                                                                                                          rupdl2
                                                                                                                                                                          ")"
                                                                                                                                                                          rstmtl3)) = toDyn (BasicFor "for" "(" rvarDecll0 ";" rexpl1 ";" rupdl2 ")" rstmtl3 :: Statement)
repSubtree StatementJCStatementS3 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (While "while"
                                                                                              "("
                                                                                              lexpl0
                                                                                              ")"
                                                                                              lstmtl1)) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (While "while"
                                                                                                                                                                    "("
                                                                                                                                                                    rexpl0
                                                                                                                                                                    ")"
                                                                                                                                                                    rstmtl1)) = toDyn (While "while" "(" rexpl0 ")" rstmtl1 :: Statement)
repSubtree StatementJCStatementS4 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (EnhancedFor "for"
                                                                                                    "("
                                                                                                    ltyl0
                                                                                                    lvarl1
                                                                                                    ":"
                                                                                                    lexpl2
                                                                                                    ")"
                                                                                                    lstmtl3)) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (EnhancedFor "for"
                                                                                                                                                                                "("
                                                                                                                                                                                rtyl0
                                                                                                                                                                                rvarl1
                                                                                                                                                                                ":"
                                                                                                                                                                                rexpl2
                                                                                                                                                                                ")"
                                                                                                                                                                                rstmtl3)) = toDyn (EnhancedFor "for" "(" rtyl0 rvarl1 ":" rexpl2 ")" rstmtl3 :: Statement)
repSubtree StatementJCStatementS5 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (FromBlockStatement lblockl0)) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (FromBlockStatement rblockl0)) = toDyn (FromBlockStatement rblockl0 :: Statement)
repSubtree StatementListJCStatementS0 ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (FromBlockStatement lblockl0)) ((fromDynamic :: Dynamic -> Maybe Statement) -> Just (FromBlockStatement rblockl0)) = toDyn (FromBlockStatement rblockl0 :: Statement)
repSubtree AssignmentJCStatementS0 ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (Assignment lnamel0
                                                                                                     "="
                                                                                                     lrhsl1)) ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (Assignment rnamel0
                                                                                                                                                                                "="
                                                                                                                                                                                rrhsl1)) = toDyn (Assignment rnamel0 "=" rrhsl1 :: Assignment)
repSubtree AssignmentJCStatementS1 ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (FromRelExp lrelExpl0)) ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (FromRelExp rrelExpl0)) = toDyn (FromRelExp rrelExpl0 :: Assignment)
repSubtree AssignmentJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (Assignment lnamel0
                                                                                                      "="
                                                                                                      lrhsl1)) ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (Assignment rnamel0
                                                                                                                                                                                 "="
                                                                                                                                                                                 rrhsl1)) = toDyn (Assignment rnamel0 "=" rrhsl1 :: Assignment)
repSubtree AssignmentJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (FromRelExp lrelExpl0)) ((fromDynamic :: Dynamic -> Maybe Assignment) -> Just (FromRelExp rrelExpl0)) = toDyn (FromRelExp rrelExpl0 :: Assignment)
repSubtree RelExpJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe RelExp) -> Just (RelExp0 llhsl0
                                                                                           "<"
                                                                                           lrhsl1)) ((fromDynamic :: Dynamic -> Maybe RelExp) -> Just (RelExp0 rlhsl0
                                                                                                                                                               "<"
                                                                                                                                                               rrhsl1)) = toDyn (RelExp0 rlhsl0 "<" rrhsl1 :: RelExp)
repSubtree RelExpJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe RelExp) -> Just (FromAdditiveExp laddExpl0)) ((fromDynamic :: Dynamic -> Maybe RelExp) -> Just (FromAdditiveExp raddExpl0)) = toDyn (FromAdditiveExp raddExpl0 :: RelExp)
repSubtree AdditiveExpJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just (AdditiveExp0 llhsl0
                                                                                                          "+"
                                                                                                          lrhsl1)) ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just (AdditiveExp0 rlhsl0
                                                                                                                                                                                        "+"
                                                                                                                                                                                        rrhsl1)) = toDyn (AdditiveExp0 rlhsl0 "+" rrhsl1 :: AdditiveExp)
repSubtree AdditiveExpJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just (AdditiveExp0 llhsl0
                                                                                                          "-"
                                                                                                          lrhsl1)) ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just (AdditiveExp0 rlhsl0
                                                                                                                                                                                        "-"
                                                                                                                                                                                        rrhsl1)) = toDyn (AdditiveExp0 rlhsl0 "-" rrhsl1 :: AdditiveExp)
repSubtree AdditiveExpJCExpressionS2 ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just (FromPostfixExp lpostExpl0)) ((fromDynamic :: Dynamic -> Maybe AdditiveExp) -> Just (FromPostfixExp rpostExpl0)) = toDyn (FromPostfixExp rpostExpl0 :: AdditiveExp)
repSubtree PostfixExpJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (PostIncExp lpfixl0
                                                                                                      "++")) ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (PostIncExp rpfixl0
                                                                                                                                                                               "++")) = toDyn (PostIncExp rpfixl0 "++" :: PostfixExp)
repSubtree PostfixExpJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (ExpN lidl0)) ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (ExpN ridl0)) = toDyn (ExpN ridl0 :: PostfixExp)
repSubtree PostfixExpJCExpressionS2 ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (PrimaryLit llitl0))) ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (PrimaryLit rlitl0))) = toDyn (FromPrimary (PrimaryLit rlitl0) :: PostfixExp)
repSubtree PostfixExpJCExpressionS3 ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (FieldAccess (ExpN lnl0)
                                                                                                                    "."
                                                                                                                    lfnamel1))) ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (FieldAccess (ExpN rnl0)
                                                                                                                                                                                                                "."
                                                                                                                                                                                                                rfnamel1))) = toDyn (FromPrimary (FieldAccess (ExpN rnl0) "." rfnamel1) :: PostfixExp)
repSubtree PostfixExpJCExpressionS4 ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (ArrayAccess lnl0
                                                                                                                    "["
                                                                                                                    lexpl1
                                                                                                                    "]"))) ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (ArrayAccess rnl0
                                                                                                                                                                                                           "["
                                                                                                                                                                                                           rexpl1
                                                                                                                                                                                                           "]"))) = toDyn (FromPrimary (ArrayAccess rnl0 "[" rexpl1 "]") :: PostfixExp)
repSubtree PostfixExpJCExpressionS5 ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (Paren "("
                                                                                                              lexpl0
                                                                                                              ")"))) ((fromDynamic :: Dynamic -> Maybe PostfixExp) -> Just (FromPrimary (Paren "("
                                                                                                                                                                                               rexpl0
                                                                                                                                                                                               ")"))) = toDyn (FromPrimary (Paren "(" rexpl0 ")") :: PostfixExp)
repSubtree ListTypeDeclarationListJCTreeS0 ((fromDynamic :: Dynamic -> Maybe ( List TypeDeclaration )) -> Just (Cons ltDecl0
                                                                                                                     ltDecsl1)) ((fromDynamic :: Dynamic -> Maybe ( List TypeDeclaration )) -> Just (Cons rtDecl0
                                                                                                                                                                                                          rtDecsl1)) = toDyn (Cons rtDecl0 rtDecsl1 :: ( List TypeDeclaration ))
repSubtree ListTypeDeclarationListJCTreeS1 ((fromDynamic :: Dynamic -> Maybe ( List TypeDeclaration )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List TypeDeclaration )) -> Just (Nil)) = toDyn (Nil :: ( List TypeDeclaration ))
repSubtree ListClassBodyDeclarationListJCTreeS0 ((fromDynamic :: Dynamic -> Maybe ( List ClassBodyDeclaration )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List ClassBodyDeclaration )) -> Just (Nil)) = toDyn (Nil :: ( List ClassBodyDeclaration ))
repSubtree ListClassBodyDeclarationListJCTreeS1 ((fromDynamic :: Dynamic -> Maybe ( List ClassBodyDeclaration )) -> Just (Cons lal0
                                                                                                                               lasl1)) ((fromDynamic :: Dynamic -> Maybe ( List ClassBodyDeclaration )) -> Just (Cons ral0
                                                                                                                                                                                                                      rasl1)) = toDyn (Cons ral0 rasl1 :: ( List ClassBodyDeclaration ))
repSubtree ListBlockStatementListJCStatementS0 ((fromDynamic :: Dynamic -> Maybe ( List BlockStatement )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List BlockStatement )) -> Just (Nil)) = toDyn (Nil :: ( List BlockStatement ))
repSubtree ListBlockStatementListJCStatementS1 ((fromDynamic :: Dynamic -> Maybe ( List BlockStatement )) -> Just (Cons lal0
                                                                                                                        lasl1)) ((fromDynamic :: Dynamic -> Maybe ( List BlockStatement )) -> Just (Cons ral0
                                                                                                                                                                                                         rasl1)) = toDyn (Cons ral0 rasl1 :: ( List BlockStatement ))
repSubtree ListExpressionListJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe ( List Expression )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List Expression )) -> Just (Nil)) = toDyn (Nil :: ( List Expression ))
repSubtree ListExpressionListJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe ( List Expression )) -> Just (Cons lel0
                                                                                                                 lesl1)) ((fromDynamic :: Dynamic -> Maybe ( List Expression )) -> Just (Cons rel0
                                                                                                                                                                                              resl1)) = toDyn (Cons rel0 resl1 :: ( List Expression ))
repSubtree ListAssignmentListJCStatementS0 ((fromDynamic :: Dynamic -> Maybe ( List Assignment )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List Assignment )) -> Just (Nil)) = toDyn (Nil :: ( List Assignment ))
repSubtree ListAssignmentListJCStatementS1 ((fromDynamic :: Dynamic -> Maybe ( List Assignment )) -> Just (Cons lassl0
                                                                                                                lasssl1)) ((fromDynamic :: Dynamic -> Maybe ( List Assignment )) -> Just (Cons rassl0
                                                                                                                                                                                               rasssl1)) = toDyn (Cons rassl0 rasssl1 :: ( List Assignment ))
repSubtree UTypeUTypeS0 ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UInteger)) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UInteger)) = toDyn (UInteger :: UType)
repSubtree UTypeUTypeS1 ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UString)) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UString)) = toDyn (UString :: UType)
repSubtree UTypeUTypeS2 ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UBool)) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UBool)) = toDyn (UBool :: UType)
repSubtree UTypeUTypeS3 ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UVoid)) ((fromDynamic :: Dynamic -> Maybe UType) -> Just (UVoid)) = toDyn (UVoid :: UType)
repSubtree ULitULitS0 ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UIntegerLit lil0)) ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UIntegerLit ril0)) = toDyn (UIntegerLit ril0 :: ULit)
repSubtree ULitULitS1 ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UStringLit lsl0)) ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UStringLit rsl0)) = toDyn (UStringLit rsl0 :: ULit)
repSubtree ULitULitS2 ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UBoolLit lbl0)) ((fromDynamic :: Dynamic -> Maybe ULit) -> Just (UBoolLit rbl0)) = toDyn (UBoolLit rbl0 :: ULit)
repSubtree IntegerR dynS1 dynS2 = dynS1
repSubtree StringR dynS1 dynS2 = dynS1
repSubtree CharR dynS1 dynS2 = dynS1
repSubtree BoolR dynS1 dynS2 = dynS1

insSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
insSubtree TypeDeclarationJCTreeS1 ((fromDynamic :: Dynamic -> Maybe (TypeDeclaration)) -> Just (FromClassDeclaration theHole)) s0 = toDyn (FromClassDeclaration s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ClassDeclarationNull
insSubtree ClassBodyDeclarationJCTreeS0 ((fromDynamic :: Dynamic -> Maybe (ClassBodyDeclaration)) -> Just (FromClassMemberDeclaration theHole)) s0 = toDyn (FromClassMemberDeclaration s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ClassMemberDeclarationNull
insSubtree ClassMemberDeclarationJCTreeS8 ((fromDynamic :: Dynamic -> Maybe (ClassMemberDeclaration)) -> Just (MemberFromClassDeclaration theHole)) s0 = toDyn (MemberFromClassDeclaration s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ClassDeclarationNull
insSubtree ClassBodyListJCTreeS1 ((fromDynamic :: Dynamic -> Maybe (ClassBody)) -> Just (ClassBody1 "{"
                                                                                                    theHole
                                                                                                    "}")) s0 = toDyn (ClassBody1 "{" s1 "}")
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ListNull
insSubtree ExpressionJCExpressionS0 ((fromDynamic :: Dynamic -> Maybe (Expression)) -> Just (AssignExp theHole)) s0 = toDyn (AssignExp s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) AssignmentNull
insSubtree AssignmentJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe (Assignment)) -> Just (FromRelExp theHole)) s0 = toDyn (FromRelExp s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) RelExpNull
insSubtree RelExpJCExpressionS1 ((fromDynamic :: Dynamic -> Maybe (RelExp)) -> Just (FromAdditiveExp theHole)) s0 = toDyn (FromAdditiveExp s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) AdditiveExpNull
insSubtree AdditiveExpJCExpressionS2 ((fromDynamic :: Dynamic -> Maybe (AdditiveExp)) -> Just (FromPostfixExp theHole)) s0 = toDyn (FromPostfixExp s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) PostfixExpNull
insSubtree PostfixExpJCExpressionS5 ((fromDynamic :: Dynamic -> Maybe (PostfixExp)) -> Just (FromPrimary (Paren "("
                                                                                                                theHole
                                                                                                                ")"))) s0 = toDyn (FromPrimary (Paren "(" s1 ")"))
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ExpressionNull
insSubtree MethodBodyListJCStatementS0 ((fromDynamic :: Dynamic -> Maybe (MethodBody)) -> Just (MethodBody0 theHole)) s0 = toDyn (MethodBody0 s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ListNull
insSubtree StatementListJCStatementS0 ((fromDynamic :: Dynamic -> Maybe (Statement)) -> Just (FromBlockStatement theHole)) s0 = toDyn (FromBlockStatement s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ListNull
insSubtree BlockStatementJCStatementS3 ((fromDynamic :: Dynamic -> Maybe (BlockStatement)) -> Just (FromStatement theHole)) s0 = toDyn (FromStatement s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) StatementNull

data RegPat
    = AdditiveExpJCExpressionS0
    | AdditiveExpJCExpressionS1
    | ExpressionJCExpressionS0
    | AssignmentJCExpressionS0
    | AssignmentJCStatementS0
    | StatementJCStatementS2
    | BlockStatementJCStatementS2
    | ClassBodyListJCTreeS0
    | ClassBodyListJCTreeS1
    | CompilationUnitJCCompilationUnitS0
    | ListAssignmentListJCStatementS1
    | ListBlockStatementListJCStatementS1
    | ListClassBodyDeclarationListJCTreeS1
    | ListExpressionListJCExpressionS1
    | ListExpressionListJCExpressionV1
    | MethodBodyListJCStatementV1
    | ListAssignmentListJCStatementV1
    | ListBlockStatementListJCStatementV1
    | ListClassBodyDeclarationListJCTreeV1
    | ListTypeDeclarationListJCTreeV0
    | ListTypeDeclarationListJCTreeS0
    | StatementJCStatementS4
    | PostfixExpJCExpressionS1
    | StatementJCStatementS0
    | ClassMemberDeclarationJCTreeS0
    | ClassMemberDeclarationJCTreeS2
    | ClassMemberDeclarationJCTreeS1
    | ClassMemberDeclarationJCTreeS3
    | RelExpJCExpressionS1
    | StatementJCStatementS5
    | StatementListJCStatementS0
    | TypeDeclarationJCTreeS1
    | ClassBodyDeclarationJCTreeS0
    | ClassBodyDeclarationJCTreeS1
    | StatementJCStatementV5
    | BlockStatementJCStatementV2
    | AssignmentJCStatementV0
    | AssignmentJCStatementV1
    | StatementJCStatementV0
    | PostfixExpJCExpressionV2
    | ClassMemberDeclarationJCTreeV5
    | ClassMemberDeclarationJCTreeV7
    | ClassMemberDeclarationJCTreeV4
    | ClassMemberDeclarationJCTreeV6
    | ExpressionJCExpressionV1
    | ExpressionJCExpressionV2
    | ClassBodyDeclarationJCTreeV1
    | ClassDeclarationJCTreeV1
    | ClassDeclarationJCTreeV3
    | ClassDeclarationJCTreeV0
    | ClassDeclarationJCTreeV2
    | ClassMemberDeclarationJCTreeV1
    | ClassMemberDeclarationJCTreeV3
    | ClassMemberDeclarationJCTreeV0
    | ClassMemberDeclarationJCTreeV2
    | TypeDeclarationJCTreeV0
    | BlockStatementJCStatementV0
    | BlockStatementJCStatementV1
    | AdditiveExpJCExpressionS2
    | PostfixExpJCExpressionS4
    | PostfixExpJCExpressionS3
    | PostfixExpJCExpressionS5
    | PostfixExpJCExpressionS2
    | AssignmentJCExpressionS1
    | AssignmentJCStatementS1
    | BlockStatementJCStatementS3
    | StatementJCStatementS1
    | PostfixExpJCExpressionV4
    | AssignmentJCExpressionV0
    | RelExpJCExpressionV0
    | AdditiveExpJCExpressionV1
    | AdditiveExpJCExpressionV0
    | ClassDeclarationJCClassDeclV1
    | ClassDeclarationJCClassDeclV3
    | ClassDeclarationJCClassDeclV0
    | ClassDeclarationJCClassDeclV2
    | CompilationUnitJCCompilationUnitV0
    | PostfixExpJCExpressionV3
    | StatementJCStatementV4
    | StatementJCStatementV3
    | StatementJCStatementV2
    | PostfixExpJCExpressionV1
    | StatementJCStatementV1
    | EEitherUTypeStringJCExpressionV1
    | EEitherUTypeStringJCExpressionV0
    | PostfixExpJCExpressionV0
    | ProdUTypeStringJCVariableDeclV0
    | EEitherUTypeStringJCExpressionS0
    | BlockStatementJCStatementS0
    | BlockStatementJCStatementS1
    | ClassMemberDeclarationJCTreeS8
    | MethodBodyListJCStatementS0
    | MethodBodyListJCStatementS1
    | ClassMemberDeclarationJCTreeS4
    | ClassMemberDeclarationJCTreeS6
    | ClassMemberDeclarationJCTreeS5
    | ClassMemberDeclarationJCTreeS7
    | ExpressionJCExpressionS1
    | ExpressionJCExpressionS2
    | ListAssignmentListJCStatementS0
    | ListBlockStatementListJCStatementS0
    | ListClassBodyDeclarationListJCTreeS0
    | ListExpressionListJCExpressionS0
    | ListExpressionListJCExpressionV0
    | ListAssignmentListJCStatementV0
    | ListBlockStatementListJCStatementV0
    | ClassBodyListJCTreeV0
    | ListClassBodyDeclarationListJCTreeV0
    | ListTypeDeclarationListJCTreeV1
    | ListTypeDeclarationListJCTreeS1
    | ClassDeclarationJCClassDeclS0
    | ClassDeclarationJCTreeS0
    | ClassDeclarationJCClassDeclS1
    | ClassDeclarationJCTreeS1
    | ClassDeclarationJCClassDeclS2
    | ClassDeclarationJCTreeS2
    | ClassDeclarationJCClassDeclS3
    | ClassDeclarationJCTreeS3
    | PostfixExpJCExpressionS0
    | ProdUTypeStringJCVariableDeclS0
    | EEitherUTypeStringJCExpressionS1
    | RelExpJCExpressionS0
    | TypeDeclarationJCTreeS0
    | UTypeUTypeS2
    | ULitULitS2
    | UTypeUTypeS0
    | ULitULitS0
    | UTypeUTypeS1
    | ULitULitS1
    | UTypeUTypeS3
    | StatementJCStatementS3
    | IntegerR
    | StringR
    | CharR
    | BoolR
    | Void
    deriving (Eq, Show, Ord, Read)