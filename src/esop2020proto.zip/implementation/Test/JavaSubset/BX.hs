{-# LANGUAGE ViewPatterns #-}
module BX where

import BXDef
import Prelude hiding (putChar)
import Data.Maybe (isJust, isNothing, fromJust)
import Data.List (partition, sortBy, sort)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Dynamic
import Text.Show.Pretty (pPrint, ppShow)

topGetCompilationUnitJCCompilationUnit :: CompilationUnit ->
                                          (JCCompilationUnit, [RLink])

topGetCompilationUnitJCCompilationUnit s = let (view,
                                                rlinks) = getCompilationUnitJCCompilationUnit s
                                            in (view, rlinks)

topGetTypeDeclarationJCTree :: TypeDeclaration -> (JCTree, [RLink])

topGetTypeDeclarationJCTree s = let (view,
                                     rlinks) = getTypeDeclarationJCTree s
                                 in (view, rlinks)

topGetClassDeclarationJCTree :: ClassDeclaration ->
                                (JCTree, [RLink])

topGetClassDeclarationJCTree s = let (view,
                                      rlinks) = getClassDeclarationJCTree s
                                  in (view, rlinks)

topGetClassBodyListJCTree :: ClassBody -> (List JCTree, [RLink])

topGetClassBodyListJCTree s = let (view,
                                   rlinks) = getClassBodyListJCTree s
                               in (view, rlinks)

topGetClassBodyDeclarationJCTree :: ClassBodyDeclaration ->
                                    (JCTree, [RLink])

topGetClassBodyDeclarationJCTree s = let (view,
                                          rlinks) = getClassBodyDeclarationJCTree s
                                      in (view, rlinks)

topGetClassMemberDeclarationJCTree :: ClassMemberDeclaration ->
                                      (JCTree, [RLink])

topGetClassMemberDeclarationJCTree s = let (view,
                                            rlinks) = getClassMemberDeclarationJCTree s
                                        in (view, rlinks)

topGetEEitherUTypeStringJCExpression :: EEither UType String ->
                                        (JCExpression, [RLink])

topGetEEitherUTypeStringJCExpression s = let (view,
                                              rlinks) = getEEitherUTypeStringJCExpression s
                                          in (view, rlinks)

topGetProdUTypeStringJCVariableDecl :: Prod UType String ->
                                       (JCVariableDecl, [RLink])

topGetProdUTypeStringJCVariableDecl s = let (view,
                                             rlinks) = getProdUTypeStringJCVariableDecl s
                                         in (view, rlinks)

topGetMethodBodyListJCStatement :: MethodBody ->
                                   (List JCStatement, [RLink])

topGetMethodBodyListJCStatement s = let (view,
                                         rlinks) = getMethodBodyListJCStatement s
                                     in (view, rlinks)

topGetBlockStatementJCStatement :: BlockStatement ->
                                   (JCStatement, [RLink])

topGetBlockStatementJCStatement s = let (view,
                                         rlinks) = getBlockStatementJCStatement s
                                     in (view, rlinks)

topGetClassDeclarationJCClassDecl :: ClassDeclaration ->
                                     (JCClassDecl, [RLink])

topGetClassDeclarationJCClassDecl s = let (view,
                                           rlinks) = getClassDeclarationJCClassDecl s
                                       in (view, rlinks)

topGetExpressionJCExpression :: Expression ->
                                (JCExpression, [RLink])

topGetExpressionJCExpression s = let (view,
                                      rlinks) = getExpressionJCExpression s
                                  in (view, rlinks)

topGetStatementJCStatement :: Statement -> (JCStatement, [RLink])

topGetStatementJCStatement s = let (view,
                                    rlinks) = getStatementJCStatement s
                                in (view, rlinks)

topGetStatementListJCStatement :: Statement ->
                                  (List JCStatement, [RLink])

topGetStatementListJCStatement s = let (view,
                                        rlinks) = getStatementListJCStatement s
                                    in (view, rlinks)

topGetAssignmentJCStatement :: Assignment -> (JCStatement, [RLink])

topGetAssignmentJCStatement s = let (view,
                                     rlinks) = getAssignmentJCStatement s
                                 in (view, rlinks)

topGetAssignmentJCExpression :: Assignment ->
                                (JCExpression, [RLink])

topGetAssignmentJCExpression s = let (view,
                                      rlinks) = getAssignmentJCExpression s
                                  in (view, rlinks)

topGetRelExpJCExpression :: RelExp -> (JCExpression, [RLink])

topGetRelExpJCExpression s = let (view,
                                  rlinks) = getRelExpJCExpression s
                              in (view, rlinks)

topGetAdditiveExpJCExpression :: AdditiveExp ->
                                 (JCExpression, [RLink])

topGetAdditiveExpJCExpression s = let (view,
                                       rlinks) = getAdditiveExpJCExpression s
                                   in (view, rlinks)

topGetPostfixExpJCExpression :: PostfixExp ->
                                (JCExpression, [RLink])

topGetPostfixExpJCExpression s = let (view,
                                      rlinks) = getPostfixExpJCExpression s
                                  in (view, rlinks)

topGetListTypeDeclarationListJCTree :: List TypeDeclaration ->
                                       (List JCTree, [RLink])

topGetListTypeDeclarationListJCTree s = let (view,
                                             rlinks) = getListTypeDeclarationListJCTree s
                                         in (view, rlinks)

topGetListClassBodyDeclarationListJCTree :: List ClassBodyDeclaration ->
                                            (List JCTree, [RLink])

topGetListClassBodyDeclarationListJCTree s = let (view,
                                                  rlinks) = getListClassBodyDeclarationListJCTree s
                                              in (view, rlinks)

topGetListBlockStatementListJCStatement :: List BlockStatement ->
                                           (List JCStatement, [RLink])

topGetListBlockStatementListJCStatement s = let (view,
                                                 rlinks) = getListBlockStatementListJCStatement s
                                             in (view, rlinks)

topGetListExpressionListJCExpression :: List Expression ->
                                        (List JCExpression, [RLink])

topGetListExpressionListJCExpression s = let (view,
                                              rlinks) = getListExpressionListJCExpression s
                                          in (view, rlinks)

topGetListAssignmentListJCStatement :: List Assignment ->
                                       (List JCStatement, [RLink])

topGetListAssignmentListJCStatement s = let (view,
                                             rlinks) = getListAssignmentListJCStatement s
                                         in (view, rlinks)

topGetUTypeUType :: UType -> (UType, [RLink])

topGetUTypeUType s = let (view, rlinks) = getUTypeUType s
                      in (view, rlinks)

topGetULitULit :: ULit -> (ULit, [RLink])

topGetULitULit s = let (view, rlinks) = getULitULit s
                    in (view, rlinks)

getCompilationUnitJCCompilationUnit :: CompilationUnit ->
                                       (JCCompilationUnit, [RLink])

getCompilationUnitJCCompilationUnit (CompilationUnit tyDecsl0) = (JCCompilationUnit tyDecsr0,
                                                                  l0 : ls')
                                        where (tyDecsr0,
                                               tyDecsr0ls) = getListTypeDeclarationListJCTree tyDecsl0
                                              preS_tyDecsr0 = [0]
                                              preV_tyDecsr0 = [0]
                                              tyDecsr0ls' = map (addPathH (preS_tyDecsr0,
                                                                           preV_tyDecsr0)) tyDecsr0ls
                                              l0 = ((CompilationUnitJCCompilationUnitS0, []),
                                                    (CompilationUnitJCCompilationUnitV0, []))
                                              ls' = concat [tyDecsr0ls']

getTypeDeclarationJCTree :: TypeDeclaration -> (JCTree, [RLink])

getTypeDeclarationJCTree (TypeDeclarationSkip ";") = (FromJCStatement JCSkip,
                                                      l0 : ls')
                             where l0 = ((TypeDeclarationJCTreeS0, []),
                                         (TypeDeclarationJCTreeV0, []))
                                   ls' = concat []
getTypeDeclarationJCTree (FromClassDeclaration classl0) = (classr0,
                                                           l0 : ls')
                             where (classr0, classr0ls) = getClassDeclarationJCTree classl0
                                   preS_classr0 = [0]
                                   preV_classr0 = []
                                   classr0ls' = map (addPathH (preS_classr0,
                                                               preV_classr0)) classr0ls
                                   l0 = ((TypeDeclarationJCTreeS1, []), (Void, []))
                                   ls' = concat [classr0ls']

getClassDeclarationJCTree :: ClassDeclaration -> (JCTree, [RLink])

getClassDeclarationJCTree (NormalClassDeclaration0 _
                                                   "class"
                                                   nl0
                                                   "extends"
                                                   supl1
                                                   bodyl2) = (FromJCStatement (FromJCClassDecl (JCClassDecl NNothing nr0 (JJust (JCIdent supr1)) bodyr2)),
                                                              l0 : ls')
                              where (nr0, nr0ls) = getStringString nl0
                                    preS_nr0 = [2]
                                    preV_nr0 = [0, 0, 1]
                                    nr0ls' = map (addPathH (preS_nr0, preV_nr0)) nr0ls
                                    (supr1, supr1ls) = getStringString supl1
                                    preS_supr1 = [4]
                                    preV_supr1 = [0, 0, 2, 0, 0]
                                    supr1ls' = map (addPathH (preS_supr1, preV_supr1)) supr1ls
                                    (bodyr2, bodyr2ls) = getClassBodyListJCTree bodyl2
                                    preS_bodyr2 = [5]
                                    preV_bodyr2 = [0, 0, 3]
                                    bodyr2ls' = map (addPathH (preS_bodyr2, preV_bodyr2)) bodyr2ls
                                    l0 = ((ClassDeclarationJCTreeS0, []),
                                          (ClassDeclarationJCTreeV0, []))
                                    ls' = concat [nr0ls', supr1ls', bodyr2ls']
getClassDeclarationJCTree (NormalClassDeclaration1 _
                                                   mdfl0
                                                   "class"
                                                   nl1
                                                   "extends"
                                                   supl2
                                                   bodyl3) = (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust mdfr0) nr1 (JJust (JCIdent supr2)) bodyr3)),
                                                              l0 : ls')
                              where (mdfr0, mdfr0ls) = getStringString mdfl0
                                    preS_mdfr0 = [1]
                                    preV_mdfr0 = [0, 0, 0, 0]
                                    mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                    (nr1, nr1ls) = getStringString nl1
                                    preS_nr1 = [3]
                                    preV_nr1 = [0, 0, 1]
                                    nr1ls' = map (addPathH (preS_nr1, preV_nr1)) nr1ls
                                    (supr2, supr2ls) = getStringString supl2
                                    preS_supr2 = [5]
                                    preV_supr2 = [0, 0, 2, 0, 0]
                                    supr2ls' = map (addPathH (preS_supr2, preV_supr2)) supr2ls
                                    (bodyr3, bodyr3ls) = getClassBodyListJCTree bodyl3
                                    preS_bodyr3 = [6]
                                    preV_bodyr3 = [0, 0, 3]
                                    bodyr3ls' = map (addPathH (preS_bodyr3, preV_bodyr3)) bodyr3ls
                                    l0 = ((ClassDeclarationJCTreeS1, []),
                                          (ClassDeclarationJCTreeV1, []))
                                    ls' = concat [mdfr0ls', nr1ls', supr2ls', bodyr3ls']
getClassDeclarationJCTree (NormalClassDeclaration2 _
                                                   "class"
                                                   nl0
                                                   bodyl1) = (FromJCStatement (FromJCClassDecl (JCClassDecl NNothing nr0 NNothing bodyr1)),
                                                              l0 : ls')
                              where (nr0, nr0ls) = getStringString nl0
                                    preS_nr0 = [2]
                                    preV_nr0 = [0, 0, 1]
                                    nr0ls' = map (addPathH (preS_nr0, preV_nr0)) nr0ls
                                    (bodyr1, bodyr1ls) = getClassBodyListJCTree bodyl1
                                    preS_bodyr1 = [3]
                                    preV_bodyr1 = [0, 0, 3]
                                    bodyr1ls' = map (addPathH (preS_bodyr1, preV_bodyr1)) bodyr1ls
                                    l0 = ((ClassDeclarationJCTreeS2, []),
                                          (ClassDeclarationJCTreeV2, []))
                                    ls' = concat [nr0ls', bodyr1ls']
getClassDeclarationJCTree (NormalClassDeclaration3 _
                                                   mdfl0
                                                   "class"
                                                   nl1
                                                   bodyl2) = (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust mdfr0) nr1 NNothing bodyr2)),
                                                              l0 : ls')
                              where (mdfr0, mdfr0ls) = getStringString mdfl0
                                    preS_mdfr0 = [1]
                                    preV_mdfr0 = [0, 0, 0, 0]
                                    mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                    (nr1, nr1ls) = getStringString nl1
                                    preS_nr1 = [3]
                                    preV_nr1 = [0, 0, 1]
                                    nr1ls' = map (addPathH (preS_nr1, preV_nr1)) nr1ls
                                    (bodyr2, bodyr2ls) = getClassBodyListJCTree bodyl2
                                    preS_bodyr2 = [4]
                                    preV_bodyr2 = [0, 0, 3]
                                    bodyr2ls' = map (addPathH (preS_bodyr2, preV_bodyr2)) bodyr2ls
                                    l0 = ((ClassDeclarationJCTreeS3, []),
                                          (ClassDeclarationJCTreeV3, []))
                                    ls' = concat [mdfr0ls', nr1ls', bodyr2ls']

getClassBodyListJCTree :: ClassBody -> (List JCTree, [RLink])

getClassBodyListJCTree (ClassBody0 "{" "}") = (Nil, l0 : ls')
                           where l0 = ((ClassBodyListJCTreeS0, []),
                                       (ClassBodyListJCTreeV0, []))
                                 ls' = concat []
getClassBodyListJCTree (ClassBody1 "{" decsl0 "}") = (decsr0,
                                                      l0 : ls')
                           where (decsr0,
                                  decsr0ls) = getListClassBodyDeclarationListJCTree decsl0
                                 preS_decsr0 = [1]
                                 preV_decsr0 = []
                                 decsr0ls' = map (addPathH (preS_decsr0, preV_decsr0)) decsr0ls
                                 l0 = ((ClassBodyListJCTreeS1, []), (Void, []))
                                 ls' = concat [decsr0ls']

getClassBodyDeclarationJCTree :: ClassBodyDeclaration ->
                                 (JCTree, [RLink])

getClassBodyDeclarationJCTree (FromClassMemberDeclaration decl0) = (decr0,
                                                                    l0 : ls')
                                  where (decr0, decr0ls) = getClassMemberDeclarationJCTree decl0
                                        preS_decr0 = [0]
                                        preV_decr0 = []
                                        decr0ls' = map (addPathH (preS_decr0, preV_decr0)) decr0ls
                                        l0 = ((ClassBodyDeclarationJCTreeS0, []), (Void, []))
                                        ls' = concat [decr0ls']
getClassBodyDeclarationJCTree (FromInstanceInitializer decl0) = (FromJCStatement (FromJCBlock decr0),
                                                                 l0 : ls')
                                  where (decr0,
                                         decr0ls) = getListBlockStatementListJCStatement decl0
                                        preS_decr0 = [0]
                                        preV_decr0 = [0, 0]
                                        decr0ls' = map (addPathH (preS_decr0, preV_decr0)) decr0ls
                                        l0 = ((ClassBodyDeclarationJCTreeS1, []),
                                              (ClassBodyDeclarationJCTreeV1, []))
                                        ls' = concat [decr0ls']

getClassMemberDeclarationJCTree :: ClassMemberDeclaration ->
                                   (JCTree, [RLink])

getClassMemberDeclarationJCTree (FieldDeclaration0 _
                                                   tyl0
                                                   (VariableDeclarator0 varNamel1)
                                                   ";") = (FromJCStatement (FromJCVariableDecl (JCVariableDecl NNothing varNamer0 (JCPrimitiveTypeTree tyr1) NNothing)),
                                                           l0 : ls')
                                    where (varNamer0, varNamer0ls) = getStringString varNamel1
                                          preS_varNamer0 = [2, 0]
                                          preV_varNamer0 = [0, 0, 1]
                                          varNamer0ls' = map (addPathH (preS_varNamer0,
                                                                        preV_varNamer0)) varNamer0ls
                                          (tyr1, tyr1ls) = getUTypeUType tyl0
                                          preS_tyr1 = [1]
                                          preV_tyr1 = [0, 0, 2, 0]
                                          tyr1ls' = map (addPathH (preS_tyr1, preV_tyr1)) tyr1ls
                                          l0 = ((ClassMemberDeclarationJCTreeS0, []),
                                                (ClassMemberDeclarationJCTreeV0, []))
                                          ls' = concat [varNamer0ls', tyr1ls']
getClassMemberDeclarationJCTree (FieldDeclaration1 _
                                                   mdfl0
                                                   tyl1
                                                   (VariableDeclarator0 varNamel2)
                                                   ";") = (FromJCStatement (FromJCVariableDecl (JCVariableDecl (JJust mdfr0) varNamer1 (JCPrimitiveTypeTree tyr2) NNothing)),
                                                           l0 : ls')
                                    where (mdfr0, mdfr0ls) = getStringString mdfl0
                                          preS_mdfr0 = [1]
                                          preV_mdfr0 = [0, 0, 0, 0]
                                          mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                          (varNamer1, varNamer1ls) = getStringString varNamel2
                                          preS_varNamer1 = [3, 0]
                                          preV_varNamer1 = [0, 0, 1]
                                          varNamer1ls' = map (addPathH (preS_varNamer1,
                                                                        preV_varNamer1)) varNamer1ls
                                          (tyr2, tyr2ls) = getUTypeUType tyl1
                                          preS_tyr2 = [2]
                                          preV_tyr2 = [0, 0, 2, 0]
                                          tyr2ls' = map (addPathH (preS_tyr2, preV_tyr2)) tyr2ls
                                          l0 = ((ClassMemberDeclarationJCTreeS1, []),
                                                (ClassMemberDeclarationJCTreeV1, []))
                                          ls' = concat [mdfr0ls', varNamer1ls', tyr2ls']
getClassMemberDeclarationJCTree (FieldDeclaration0 _
                                                   tyl0
                                                   (VariableDeclarator1 varNamel1
                                                                        (VariableInitializer "="
                                                                                             initVall2))
                                                   ";") = (FromJCStatement (FromJCVariableDecl (JCVariableDecl NNothing varNamer0 (JCPrimitiveTypeTree tyr1) (JJust initValr2))),
                                                           l0 : ls')
                                    where (varNamer0, varNamer0ls) = getStringString varNamel1
                                          preS_varNamer0 = [2, 0]
                                          preV_varNamer0 = [0, 0, 1]
                                          varNamer0ls' = map (addPathH (preS_varNamer0,
                                                                        preV_varNamer0)) varNamer0ls
                                          (tyr1, tyr1ls) = getUTypeUType tyl0
                                          preS_tyr1 = [1]
                                          preV_tyr1 = [0, 0, 2, 0]
                                          tyr1ls' = map (addPathH (preS_tyr1, preV_tyr1)) tyr1ls
                                          (initValr2,
                                           initValr2ls) = getExpressionJCExpression initVall2
                                          preS_initValr2 = [2, 1, 1]
                                          preV_initValr2 = [0, 0, 3, 0]
                                          initValr2ls' = map (addPathH (preS_initValr2,
                                                                        preV_initValr2)) initValr2ls
                                          l0 = ((ClassMemberDeclarationJCTreeS2, []),
                                                (ClassMemberDeclarationJCTreeV2, []))
                                          ls' = concat [varNamer0ls', tyr1ls', initValr2ls']
getClassMemberDeclarationJCTree (FieldDeclaration1 _
                                                   mdfl0
                                                   tyl1
                                                   (VariableDeclarator1 varNamel2
                                                                        (VariableInitializer "="
                                                                                             initVall3))
                                                   ";") = (FromJCStatement (FromJCVariableDecl (JCVariableDecl (JJust mdfr0) varNamer1 (JCPrimitiveTypeTree tyr2) (JJust initValr3))),
                                                           l0 : ls')
                                    where (mdfr0, mdfr0ls) = getStringString mdfl0
                                          preS_mdfr0 = [1]
                                          preV_mdfr0 = [0, 0, 0, 0]
                                          mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                          (varNamer1, varNamer1ls) = getStringString varNamel2
                                          preS_varNamer1 = [3, 0]
                                          preV_varNamer1 = [0, 0, 1]
                                          varNamer1ls' = map (addPathH (preS_varNamer1,
                                                                        preV_varNamer1)) varNamer1ls
                                          (tyr2, tyr2ls) = getUTypeUType tyl1
                                          preS_tyr2 = [2]
                                          preV_tyr2 = [0, 0, 2, 0]
                                          tyr2ls' = map (addPathH (preS_tyr2, preV_tyr2)) tyr2ls
                                          (initValr3,
                                           initValr3ls) = getExpressionJCExpression initVall3
                                          preS_initValr3 = [3, 1, 1]
                                          preV_initValr3 = [0, 0, 3, 0]
                                          initValr3ls' = map (addPathH (preS_initValr3,
                                                                        preV_initValr3)) initValr3ls
                                          l0 = ((ClassMemberDeclarationJCTreeS3, []),
                                                (ClassMemberDeclarationJCTreeV3, []))
                                          ls' = concat [mdfr0ls',
                                                        varNamer1ls',
                                                        tyr2ls',
                                                        initValr3ls']
getClassMemberDeclarationJCTree (MethodDeclaration0 _
                                                    (MethodHeader resTypel0
                                                                  (MethodDeclarator0 methNamel1
                                                                                     "("
                                                                                     ")"))
                                                    bodyl2) = (FromJCMethodDecl (JCMethodDecl NNothing methNamer0 resTyper1 NNothing bodyr2),
                                                               l0 : ls')
                                    where (methNamer0, methNamer0ls) = getStringString methNamel1
                                          preS_methNamer0 = [1, 1, 0]
                                          preV_methNamer0 = [0, 1]
                                          methNamer0ls' = map (addPathH (preS_methNamer0,
                                                                         preV_methNamer0)) methNamer0ls
                                          (resTyper1,
                                           resTyper1ls) = getEEitherUTypeStringJCExpression resTypel0
                                          preS_resTyper1 = [1, 0]
                                          preV_resTyper1 = [0, 2]
                                          resTyper1ls' = map (addPathH (preS_resTyper1,
                                                                        preV_resTyper1)) resTyper1ls
                                          (bodyr2, bodyr2ls) = getMethodBodyListJCStatement bodyl2
                                          preS_bodyr2 = [2]
                                          preV_bodyr2 = [0, 4]
                                          bodyr2ls' = map (addPathH (preS_bodyr2,
                                                                     preV_bodyr2)) bodyr2ls
                                          l0 = ((ClassMemberDeclarationJCTreeS4, []),
                                                (ClassMemberDeclarationJCTreeV4, []))
                                          ls' = concat [methNamer0ls', resTyper1ls', bodyr2ls']
getClassMemberDeclarationJCTree (MethodDeclaration1 _
                                                    mdfl0
                                                    (MethodHeader resTypel1
                                                                  (MethodDeclarator0 methNamel2
                                                                                     "("
                                                                                     ")"))
                                                    bodyl3) = (FromJCMethodDecl (JCMethodDecl (JJust mdfr0) methNamer1 resTyper2 NNothing bodyr3),
                                                               l0 : ls')
                                    where (mdfr0, mdfr0ls) = getStringString mdfl0
                                          preS_mdfr0 = [1]
                                          preV_mdfr0 = [0, 0, 0]
                                          mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                          (methNamer1, methNamer1ls) = getStringString methNamel2
                                          preS_methNamer1 = [2, 1, 0]
                                          preV_methNamer1 = [0, 1]
                                          methNamer1ls' = map (addPathH (preS_methNamer1,
                                                                         preV_methNamer1)) methNamer1ls
                                          (resTyper2,
                                           resTyper2ls) = getEEitherUTypeStringJCExpression resTypel1
                                          preS_resTyper2 = [2, 0]
                                          preV_resTyper2 = [0, 2]
                                          resTyper2ls' = map (addPathH (preS_resTyper2,
                                                                        preV_resTyper2)) resTyper2ls
                                          (bodyr3, bodyr3ls) = getMethodBodyListJCStatement bodyl3
                                          preS_bodyr3 = [3]
                                          preV_bodyr3 = [0, 4]
                                          bodyr3ls' = map (addPathH (preS_bodyr3,
                                                                     preV_bodyr3)) bodyr3ls
                                          l0 = ((ClassMemberDeclarationJCTreeS5, []),
                                                (ClassMemberDeclarationJCTreeV5, []))
                                          ls' = concat [mdfr0ls',
                                                        methNamer1ls',
                                                        resTyper2ls',
                                                        bodyr3ls']
getClassMemberDeclarationJCTree (MethodDeclaration0 _
                                                    (MethodHeader resTypel0
                                                                  (MethodDeclarator1 methNamel1
                                                                                     "("
                                                                                     argl2
                                                                                     ")"))
                                                    bodyl3) = (FromJCMethodDecl (JCMethodDecl NNothing methNamer0 resTyper1 (JJust argr2) bodyr3),
                                                               l0 : ls')
                                    where (methNamer0, methNamer0ls) = getStringString methNamel1
                                          preS_methNamer0 = [1, 1, 0]
                                          preV_methNamer0 = [0, 1]
                                          methNamer0ls' = map (addPathH (preS_methNamer0,
                                                                         preV_methNamer0)) methNamer0ls
                                          (resTyper1,
                                           resTyper1ls) = getEEitherUTypeStringJCExpression resTypel0
                                          preS_resTyper1 = [1, 0]
                                          preV_resTyper1 = [0, 2]
                                          resTyper1ls' = map (addPathH (preS_resTyper1,
                                                                        preV_resTyper1)) resTyper1ls
                                          (argr2, argr2ls) = getProdUTypeStringJCVariableDecl argl2
                                          preS_argr2 = [1, 1, 2]
                                          preV_argr2 = [0, 3, 0]
                                          argr2ls' = map (addPathH (preS_argr2, preV_argr2)) argr2ls
                                          (bodyr3, bodyr3ls) = getMethodBodyListJCStatement bodyl3
                                          preS_bodyr3 = [2]
                                          preV_bodyr3 = [0, 4]
                                          bodyr3ls' = map (addPathH (preS_bodyr3,
                                                                     preV_bodyr3)) bodyr3ls
                                          l0 = ((ClassMemberDeclarationJCTreeS6, []),
                                                (ClassMemberDeclarationJCTreeV6, []))
                                          ls' = concat [methNamer0ls',
                                                        resTyper1ls',
                                                        argr2ls',
                                                        bodyr3ls']
getClassMemberDeclarationJCTree (MethodDeclaration1 _
                                                    mdfl0
                                                    (MethodHeader resTypel1
                                                                  (MethodDeclarator1 methNamel2
                                                                                     "("
                                                                                     argl3
                                                                                     ")"))
                                                    bodyl4) = (FromJCMethodDecl (JCMethodDecl (JJust mdfr0) methNamer1 resTyper2 (JJust argr3) bodyr4),
                                                               l0 : ls')
                                    where (mdfr0, mdfr0ls) = getStringString mdfl0
                                          preS_mdfr0 = [1]
                                          preV_mdfr0 = [0, 0, 0]
                                          mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                          (methNamer1, methNamer1ls) = getStringString methNamel2
                                          preS_methNamer1 = [2, 1, 0]
                                          preV_methNamer1 = [0, 1]
                                          methNamer1ls' = map (addPathH (preS_methNamer1,
                                                                         preV_methNamer1)) methNamer1ls
                                          (resTyper2,
                                           resTyper2ls) = getEEitherUTypeStringJCExpression resTypel1
                                          preS_resTyper2 = [2, 0]
                                          preV_resTyper2 = [0, 2]
                                          resTyper2ls' = map (addPathH (preS_resTyper2,
                                                                        preV_resTyper2)) resTyper2ls
                                          (argr3, argr3ls) = getProdUTypeStringJCVariableDecl argl3
                                          preS_argr3 = [2, 1, 2]
                                          preV_argr3 = [0, 3, 0]
                                          argr3ls' = map (addPathH (preS_argr3, preV_argr3)) argr3ls
                                          (bodyr4, bodyr4ls) = getMethodBodyListJCStatement bodyl4
                                          preS_bodyr4 = [3]
                                          preV_bodyr4 = [0, 4]
                                          bodyr4ls' = map (addPathH (preS_bodyr4,
                                                                     preV_bodyr4)) bodyr4ls
                                          l0 = ((ClassMemberDeclarationJCTreeS7, []),
                                                (ClassMemberDeclarationJCTreeV7, []))
                                          ls' = concat [mdfr0ls',
                                                        methNamer1ls',
                                                        resTyper2ls',
                                                        argr3ls',
                                                        bodyr4ls']
getClassMemberDeclarationJCTree (MemberFromClassDeclaration classDecl0) = (classDecr0,
                                                                           l0 : ls')
                                    where (classDecr0,
                                           classDecr0ls) = getClassDeclarationJCTree classDecl0
                                          preS_classDecr0 = [0]
                                          preV_classDecr0 = []
                                          classDecr0ls' = map (addPathH (preS_classDecr0,
                                                                         preV_classDecr0)) classDecr0ls
                                          l0 = ((ClassMemberDeclarationJCTreeS8, []), (Void, []))
                                          ls' = concat [classDecr0ls']

getEEitherUTypeStringJCExpression :: EEither UType String ->
                                     (JCExpression, [RLink])

getEEitherUTypeStringJCExpression (LLeft resTypel0) = (JCPrimitiveTypeTree resTyper0,
                                                       l0 : ls')
                                      where (resTyper0, resTyper0ls) = getUTypeUType resTypel0
                                            preS_resTyper0 = [0]
                                            preV_resTyper0 = [0]
                                            resTyper0ls' = map (addPathH (preS_resTyper0,
                                                                          preV_resTyper0)) resTyper0ls
                                            l0 = ((EEitherUTypeStringJCExpressionS0, []),
                                                  (EEitherUTypeStringJCExpressionV0, []))
                                            ls' = concat [resTyper0ls']
getEEitherUTypeStringJCExpression (RRight "void") = (JCPrimitiveTypeTree UVoid,
                                                     l0 : ls')
                                      where l0 = ((EEitherUTypeStringJCExpressionS1, []),
                                                  (EEitherUTypeStringJCExpressionV1, []))
                                            ls' = concat []

getProdUTypeStringJCVariableDecl :: Prod UType String ->
                                    (JCVariableDecl, [RLink])

getProdUTypeStringJCVariableDecl (Prod tyl0
                                       namel1) = (JCVariableDecl NNothing namer0 (JCPrimitiveTypeTree tyr1) NNothing,
                                                  l0 : ls')
                                     where (namer0, namer0ls) = getStringString namel1
                                           preS_namer0 = [1]
                                           preV_namer0 = [1]
                                           namer0ls' = map (addPathH (preS_namer0,
                                                                      preV_namer0)) namer0ls
                                           (tyr1, tyr1ls) = getUTypeUType tyl0
                                           preS_tyr1 = [0]
                                           preV_tyr1 = [2, 0]
                                           tyr1ls' = map (addPathH (preS_tyr1, preV_tyr1)) tyr1ls
                                           l0 = ((ProdUTypeStringJCVariableDeclS0, []),
                                                 (ProdUTypeStringJCVariableDeclV0, []))
                                           ls' = concat [namer0ls', tyr1ls']

getMethodBodyListJCStatement :: MethodBody ->
                                (List JCStatement, [RLink])

getMethodBodyListJCStatement (MethodBody0 stmtsl0) = (stmtsr0,
                                                      l0 : ls')
                                 where (stmtsr0,
                                        stmtsr0ls) = getListBlockStatementListJCStatement stmtsl0
                                       preS_stmtsr0 = [0]
                                       preV_stmtsr0 = []
                                       stmtsr0ls' = map (addPathH (preS_stmtsr0,
                                                                   preV_stmtsr0)) stmtsr0ls
                                       l0 = ((MethodBodyListJCStatementS0, []), (Void, []))
                                       ls' = concat [stmtsr0ls']
getMethodBodyListJCStatement (MethodBody1 ";") = (Cons JCSkip Nil,
                                                  l0 : ls')
                                 where l0 = ((MethodBodyListJCStatementS1, []),
                                             (MethodBodyListJCStatementV1, []))
                                       ls' = concat []

getBlockStatementJCStatement :: BlockStatement ->
                                (JCStatement, [RLink])

getBlockStatementJCStatement (LocalVariableDeclaration tyl0
                                                       (VariableDeclarator0 varNamel1)) = (FromJCVariableDecl (JCVariableDecl NNothing varNamer0 (JCPrimitiveTypeTree tyr1) NNothing),
                                                                                           l0 : ls')
                                 where (varNamer0, varNamer0ls) = getStringString varNamel1
                                       preS_varNamer0 = [1, 0]
                                       preV_varNamer0 = [0, 1]
                                       varNamer0ls' = map (addPathH (preS_varNamer0,
                                                                     preV_varNamer0)) varNamer0ls
                                       (tyr1, tyr1ls) = getUTypeUType tyl0
                                       preS_tyr1 = [0]
                                       preV_tyr1 = [0, 2, 0]
                                       tyr1ls' = map (addPathH (preS_tyr1, preV_tyr1)) tyr1ls
                                       l0 = ((BlockStatementJCStatementS0, []),
                                             (BlockStatementJCStatementV0, []))
                                       ls' = concat [varNamer0ls', tyr1ls']
getBlockStatementJCStatement (LocalVariableDeclaration tyl0
                                                       (VariableDeclarator1 varNamel1
                                                                            (VariableInitializer "="
                                                                                                 initVall2))) = (FromJCVariableDecl (JCVariableDecl NNothing varNamer0 (JCPrimitiveTypeTree tyr1) (JJust initValr2)),
                                                                                                                 l0 : ls')
                                 where (varNamer0, varNamer0ls) = getStringString varNamel1
                                       preS_varNamer0 = [1, 0]
                                       preV_varNamer0 = [0, 1]
                                       varNamer0ls' = map (addPathH (preS_varNamer0,
                                                                     preV_varNamer0)) varNamer0ls
                                       (tyr1, tyr1ls) = getUTypeUType tyl0
                                       preS_tyr1 = [0]
                                       preV_tyr1 = [0, 2, 0]
                                       tyr1ls' = map (addPathH (preS_tyr1, preV_tyr1)) tyr1ls
                                       (initValr2,
                                        initValr2ls) = getExpressionJCExpression initVall2
                                       preS_initValr2 = [1, 1, 1]
                                       preV_initValr2 = [0, 3, 0]
                                       initValr2ls' = map (addPathH (preS_initValr2,
                                                                     preV_initValr2)) initValr2ls
                                       l0 = ((BlockStatementJCStatementS1, []),
                                             (BlockStatementJCStatementV1, []))
                                       ls' = concat [varNamer0ls', tyr1ls', initValr2ls']
getBlockStatementJCStatement (BlockFromClassDeclaration classDecl0) = (FromJCClassDecl classDecr0,
                                                                       l0 : ls')
                                 where (classDecr0,
                                        classDecr0ls) = getClassDeclarationJCClassDecl classDecl0
                                       preS_classDecr0 = [0]
                                       preV_classDecr0 = [0]
                                       classDecr0ls' = map (addPathH (preS_classDecr0,
                                                                      preV_classDecr0)) classDecr0ls
                                       l0 = ((BlockStatementJCStatementS2, []),
                                             (BlockStatementJCStatementV2, []))
                                       ls' = concat [classDecr0ls']
getBlockStatementJCStatement (FromStatement stmtl0) = (stmtr0,
                                                       l0 : ls')
                                 where (stmtr0, stmtr0ls) = getStatementJCStatement stmtl0
                                       preS_stmtr0 = [0]
                                       preV_stmtr0 = []
                                       stmtr0ls' = map (addPathH (preS_stmtr0,
                                                                  preV_stmtr0)) stmtr0ls
                                       l0 = ((BlockStatementJCStatementS3, []), (Void, []))
                                       ls' = concat [stmtr0ls']

getClassDeclarationJCClassDecl :: ClassDeclaration ->
                                  (JCClassDecl, [RLink])

getClassDeclarationJCClassDecl (NormalClassDeclaration0 _
                                                        "class"
                                                        nl0
                                                        "extends"
                                                        supl1
                                                        bodyl2) = (JCClassDecl NNothing nr0 (JJust (JCIdent supr1)) bodyr2,
                                                                   l0 : ls')
                                   where (nr0, nr0ls) = getStringString nl0
                                         preS_nr0 = [2]
                                         preV_nr0 = [1]
                                         nr0ls' = map (addPathH (preS_nr0, preV_nr0)) nr0ls
                                         (supr1, supr1ls) = getStringString supl1
                                         preS_supr1 = [4]
                                         preV_supr1 = [2, 0, 0]
                                         supr1ls' = map (addPathH (preS_supr1, preV_supr1)) supr1ls
                                         (bodyr2, bodyr2ls) = getClassBodyListJCTree bodyl2
                                         preS_bodyr2 = [5]
                                         preV_bodyr2 = [3]
                                         bodyr2ls' = map (addPathH (preS_bodyr2,
                                                                    preV_bodyr2)) bodyr2ls
                                         l0 = ((ClassDeclarationJCClassDeclS0, []),
                                               (ClassDeclarationJCClassDeclV0, []))
                                         ls' = concat [nr0ls', supr1ls', bodyr2ls']
getClassDeclarationJCClassDecl (NormalClassDeclaration1 _
                                                        mdfl0
                                                        "class"
                                                        nl1
                                                        "extends"
                                                        supl2
                                                        bodyl3) = (JCClassDecl (JJust mdfr0) nr1 (JJust (JCIdent supr2)) bodyr3,
                                                                   l0 : ls')
                                   where (mdfr0, mdfr0ls) = getStringString mdfl0
                                         preS_mdfr0 = [1]
                                         preV_mdfr0 = [0, 0]
                                         mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                         (nr1, nr1ls) = getStringString nl1
                                         preS_nr1 = [3]
                                         preV_nr1 = [1]
                                         nr1ls' = map (addPathH (preS_nr1, preV_nr1)) nr1ls
                                         (supr2, supr2ls) = getStringString supl2
                                         preS_supr2 = [5]
                                         preV_supr2 = [2, 0, 0]
                                         supr2ls' = map (addPathH (preS_supr2, preV_supr2)) supr2ls
                                         (bodyr3, bodyr3ls) = getClassBodyListJCTree bodyl3
                                         preS_bodyr3 = [6]
                                         preV_bodyr3 = [3]
                                         bodyr3ls' = map (addPathH (preS_bodyr3,
                                                                    preV_bodyr3)) bodyr3ls
                                         l0 = ((ClassDeclarationJCClassDeclS1, []),
                                               (ClassDeclarationJCClassDeclV1, []))
                                         ls' = concat [mdfr0ls', nr1ls', supr2ls', bodyr3ls']
getClassDeclarationJCClassDecl (NormalClassDeclaration2 _
                                                        "class"
                                                        nl0
                                                        bodyl1) = (JCClassDecl NNothing nr0 NNothing bodyr1,
                                                                   l0 : ls')
                                   where (nr0, nr0ls) = getStringString nl0
                                         preS_nr0 = [2]
                                         preV_nr0 = [1]
                                         nr0ls' = map (addPathH (preS_nr0, preV_nr0)) nr0ls
                                         (bodyr1, bodyr1ls) = getClassBodyListJCTree bodyl1
                                         preS_bodyr1 = [3]
                                         preV_bodyr1 = [3]
                                         bodyr1ls' = map (addPathH (preS_bodyr1,
                                                                    preV_bodyr1)) bodyr1ls
                                         l0 = ((ClassDeclarationJCClassDeclS2, []),
                                               (ClassDeclarationJCClassDeclV2, []))
                                         ls' = concat [nr0ls', bodyr1ls']
getClassDeclarationJCClassDecl (NormalClassDeclaration3 _
                                                        mdfl0
                                                        "class"
                                                        nl1
                                                        bodyl2) = (JCClassDecl (JJust mdfr0) nr1 NNothing bodyr2,
                                                                   l0 : ls')
                                   where (mdfr0, mdfr0ls) = getStringString mdfl0
                                         preS_mdfr0 = [1]
                                         preV_mdfr0 = [0, 0]
                                         mdfr0ls' = map (addPathH (preS_mdfr0, preV_mdfr0)) mdfr0ls
                                         (nr1, nr1ls) = getStringString nl1
                                         preS_nr1 = [3]
                                         preV_nr1 = [1]
                                         nr1ls' = map (addPathH (preS_nr1, preV_nr1)) nr1ls
                                         (bodyr2, bodyr2ls) = getClassBodyListJCTree bodyl2
                                         preS_bodyr2 = [4]
                                         preV_bodyr2 = [3]
                                         bodyr2ls' = map (addPathH (preS_bodyr2,
                                                                    preV_bodyr2)) bodyr2ls
                                         l0 = ((ClassDeclarationJCClassDeclS3, []),
                                               (ClassDeclarationJCClassDeclV3, []))
                                         ls' = concat [mdfr0ls', nr1ls', bodyr2ls']

getExpressionJCExpression :: Expression -> (JCExpression, [RLink])

getExpressionJCExpression (AssignExp expl0) = (expr0, l0 : ls')
                              where (expr0, expr0ls) = getAssignmentJCExpression expl0
                                    preS_expr0 = [0]
                                    preV_expr0 = []
                                    expr0ls' = map (addPathH (preS_expr0, preV_expr0)) expr0ls
                                    l0 = ((ExpressionJCExpressionS0, []), (Void, []))
                                    ls' = concat [expr0ls']
getExpressionJCExpression (MethodInvocation0 methNamel0
                                             "("
                                             ")") = (FromJCPolyExpression (JCMethodInvocation Nil (JCIdent methNamer0) NNothing),
                                                     l0 : ls')
                              where (methNamer0, methNamer0ls) = getStringString methNamel0
                                    preS_methNamer0 = [0]
                                    preV_methNamer0 = [0, 1, 0]
                                    methNamer0ls' = map (addPathH (preS_methNamer0,
                                                                   preV_methNamer0)) methNamer0ls
                                    l0 = ((ExpressionJCExpressionS1, []),
                                          (ExpressionJCExpressionV1, []))
                                    ls' = concat [methNamer0ls']
getExpressionJCExpression (MethodInvocation1 methNamel0
                                             "("
                                             argl1
                                             ")") = (FromJCPolyExpression (JCMethodInvocation Nil (JCIdent methNamer0) (JJust argr1)),
                                                     l0 : ls')
                              where (methNamer0, methNamer0ls) = getStringString methNamel0
                                    preS_methNamer0 = [0]
                                    preV_methNamer0 = [0, 1, 0]
                                    methNamer0ls' = map (addPathH (preS_methNamer0,
                                                                   preV_methNamer0)) methNamer0ls
                                    (argr1, argr1ls) = getExpressionJCExpression argl1
                                    preS_argr1 = [2]
                                    preV_argr1 = [0, 2, 0]
                                    argr1ls' = map (addPathH (preS_argr1, preV_argr1)) argr1ls
                                    l0 = ((ExpressionJCExpressionS2, []),
                                          (ExpressionJCExpressionV2, []))
                                    ls' = concat [methNamer0ls', argr1ls']

getStatementJCStatement :: Statement -> (JCStatement, [RLink])

getStatementJCStatement (ExpressionStatement exprl0
                                             ";") = (FromJCExpressionStatement exprr0, l0 : ls')
                            where (exprr0, exprr0ls) = getExpressionJCExpression exprl0
                                  preS_exprr0 = [0]
                                  preV_exprr0 = [0]
                                  exprr0ls' = map (addPathH (preS_exprr0, preV_exprr0)) exprr0ls
                                  l0 = ((StatementJCStatementS0, []), (StatementJCStatementV0, []))
                                  ls' = concat [exprr0ls']
getStatementJCStatement (IfThenElse "if"
                                    "("
                                    condl0
                                    ")"
                                    trueStmtl1
                                    "else"
                                    falseStmtl2) = (JCIf condr0 trueStmtr1 falseStmtr2, l0 : ls')
                            where (condr0, condr0ls) = getExpressionJCExpression condl0
                                  preS_condr0 = [2]
                                  preV_condr0 = [0]
                                  condr0ls' = map (addPathH (preS_condr0, preV_condr0)) condr0ls
                                  (trueStmtr1, trueStmtr1ls) = getStatementJCStatement trueStmtl1
                                  preS_trueStmtr1 = [4]
                                  preV_trueStmtr1 = [1]
                                  trueStmtr1ls' = map (addPathH (preS_trueStmtr1,
                                                                 preV_trueStmtr1)) trueStmtr1ls
                                  (falseStmtr2, falseStmtr2ls) = getStatementJCStatement falseStmtl2
                                  preS_falseStmtr2 = [6]
                                  preV_falseStmtr2 = [2]
                                  falseStmtr2ls' = map (addPathH (preS_falseStmtr2,
                                                                  preV_falseStmtr2)) falseStmtr2ls
                                  l0 = ((StatementJCStatementS1, []), (StatementJCStatementV1, []))
                                  ls' = concat [condr0ls', trueStmtr1ls', falseStmtr2ls']
getStatementJCStatement (BasicFor "for"
                                  "("
                                  varDecll0
                                  ";"
                                  expl1
                                  ";"
                                  updl2
                                  ")"
                                  stmtl3) = (JCForLoop varDeclr0 expr1 updr2 stmtr3, l0 : ls')
                            where (varDeclr0,
                                   varDeclr0ls) = getListBlockStatementListJCStatement varDecll0
                                  preS_varDeclr0 = [2]
                                  preV_varDeclr0 = [0]
                                  varDeclr0ls' = map (addPathH (preS_varDeclr0,
                                                                preV_varDeclr0)) varDeclr0ls
                                  (expr1, expr1ls) = getExpressionJCExpression expl1
                                  preS_expr1 = [4]
                                  preV_expr1 = [1]
                                  expr1ls' = map (addPathH (preS_expr1, preV_expr1)) expr1ls
                                  (updr2, updr2ls) = getListExpressionListJCExpression updl2
                                  preS_updr2 = [6]
                                  preV_updr2 = [2]
                                  updr2ls' = map (addPathH (preS_updr2, preV_updr2)) updr2ls
                                  (stmtr3, stmtr3ls) = getStatementJCStatement stmtl3
                                  preS_stmtr3 = [8]
                                  preV_stmtr3 = [3]
                                  stmtr3ls' = map (addPathH (preS_stmtr3, preV_stmtr3)) stmtr3ls
                                  l0 = ((StatementJCStatementS2, []), (StatementJCStatementV2, []))
                                  ls' = concat [varDeclr0ls', expr1ls', updr2ls', stmtr3ls']
getStatementJCStatement (While "while"
                               "("
                               expl0
                               ")"
                               stmtl1) = (JCForLoop Nil expr0 Nil stmtr1, l0 : ls')
                            where (expr0, expr0ls) = getExpressionJCExpression expl0
                                  preS_expr0 = [2]
                                  preV_expr0 = [1]
                                  expr0ls' = map (addPathH (preS_expr0, preV_expr0)) expr0ls
                                  (stmtr1, stmtr1ls) = getStatementJCStatement stmtl1
                                  preS_stmtr1 = [4]
                                  preV_stmtr1 = [3]
                                  stmtr1ls' = map (addPathH (preS_stmtr1, preV_stmtr1)) stmtr1ls
                                  l0 = ((StatementJCStatementS3, []), (StatementJCStatementV3, []))
                                  ls' = concat [expr0ls', stmtr1ls']
getStatementJCStatement (EnhancedFor "for"
                                     "("
                                     tyl0
                                     varl1
                                     ":"
                                     expl2
                                     ")"
                                     stmtl3) = (JCForLoop (Cons (FromJCVariableDecl (JCVariableDecl NNothing "i" (JCPrimitiveTypeTree UInteger) (JJust (FromJCLiteral (UIntegerLit 0))))) Nil) (JCBinary LESSTHAN (JCIdent "i") (JCFieldAccess expr0 "length") "<") (Cons (JCUnary POSTINC (JCIdent "i") "++") Nil) (FromJCBlock (Cons (FromJCVariableDecl (JCVariableDecl NNothing varr1 (JCPrimitiveTypeTree tyr2) (JJust (JCArrayAccess expr3 (JCIdent "i"))))) stmtr4)),
                                                l0 : ls')
                            where (expr0, expr0ls) = getExpressionJCExpression expl2
                                  preS_expr0 = [5]
                                  preV_expr0 = [1, 2, 0]
                                  expr0ls' = map (addPathH (preS_expr0, preV_expr0)) expr0ls
                                  (varr1, varr1ls) = getStringString varl1
                                  preS_varr1 = [3]
                                  preV_varr1 = [3, 0, 0, 0, 1]
                                  varr1ls' = map (addPathH (preS_varr1, preV_varr1)) varr1ls
                                  (tyr2, tyr2ls) = getUTypeUType tyl0
                                  preS_tyr2 = [2]
                                  preV_tyr2 = [3, 0, 0, 0, 2, 0]
                                  tyr2ls' = map (addPathH (preS_tyr2, preV_tyr2)) tyr2ls
                                  (expr3, expr3ls) = getExpressionJCExpression expl2
                                  preS_expr3 = [5]
                                  preV_expr3 = [3, 0, 0, 0, 3, 0, 0]
                                  expr3ls' = map (addPathH (preS_expr3, preV_expr3)) expr3ls
                                  (stmtr4, stmtr4ls) = getStatementListJCStatement stmtl3
                                  preS_stmtr4 = [7]
                                  preV_stmtr4 = [3, 0, 1]
                                  stmtr4ls' = map (addPathH (preS_stmtr4, preV_stmtr4)) stmtr4ls
                                  l0 = ((StatementJCStatementS4, []), (StatementJCStatementV4, []))
                                  ls' = concat [expr0ls', varr1ls', tyr2ls', expr3ls', stmtr4ls']
getStatementJCStatement (FromBlockStatement blockl0) = (FromJCBlock blockr0,
                                                        l0 : ls')
                            where (blockr0,
                                   blockr0ls) = getListBlockStatementListJCStatement blockl0
                                  preS_blockr0 = [0]
                                  preV_blockr0 = [0]
                                  blockr0ls' = map (addPathH (preS_blockr0, preV_blockr0)) blockr0ls
                                  l0 = ((StatementJCStatementS5, []), (StatementJCStatementV5, []))
                                  ls' = concat [blockr0ls']

getStatementListJCStatement :: Statement ->
                               (List JCStatement, [RLink])

getStatementListJCStatement (FromBlockStatement blockl0) = (blockr0,
                                                            l0 : ls')
                                where (blockr0,
                                       blockr0ls) = getListBlockStatementListJCStatement blockl0
                                      preS_blockr0 = [0]
                                      preV_blockr0 = []
                                      blockr0ls' = map (addPathH (preS_blockr0,
                                                                  preV_blockr0)) blockr0ls
                                      l0 = ((StatementListJCStatementS0, []), (Void, []))
                                      ls' = concat [blockr0ls']

getAssignmentJCStatement :: Assignment -> (JCStatement, [RLink])

getAssignmentJCStatement (Assignment namel0
                                     "="
                                     rhsl1) = (FromJCExpressionStatement (JCAssign (JCIdent namer0) rhsr1),
                                               l0 : ls')
                             where (namer0, namer0ls) = getStringString namel0
                                   preS_namer0 = [0]
                                   preV_namer0 = [0, 0, 0]
                                   namer0ls' = map (addPathH (preS_namer0, preV_namer0)) namer0ls
                                   (rhsr1, rhsr1ls) = getExpressionJCExpression rhsl1
                                   preS_rhsr1 = [2]
                                   preV_rhsr1 = [0, 1]
                                   rhsr1ls' = map (addPathH (preS_rhsr1, preV_rhsr1)) rhsr1ls
                                   l0 = ((AssignmentJCStatementS0, []),
                                         (AssignmentJCStatementV0, []))
                                   ls' = concat [namer0ls', rhsr1ls']
getAssignmentJCStatement (FromRelExp relExpl0) = (FromJCExpressionStatement relExpr0,
                                                  l0 : ls')
                             where (relExpr0, relExpr0ls) = getRelExpJCExpression relExpl0
                                   preS_relExpr0 = [0]
                                   preV_relExpr0 = [0]
                                   relExpr0ls' = map (addPathH (preS_relExpr0,
                                                                preV_relExpr0)) relExpr0ls
                                   l0 = ((AssignmentJCStatementS1, []),
                                         (AssignmentJCStatementV1, []))
                                   ls' = concat [relExpr0ls']

getAssignmentJCExpression :: Assignment -> (JCExpression, [RLink])

getAssignmentJCExpression (Assignment namel0
                                      "="
                                      rhsl1) = (JCAssign (JCIdent namer0) rhsr1, l0 : ls')
                              where (namer0, namer0ls) = getStringString namel0
                                    preS_namer0 = [0]
                                    preV_namer0 = [0, 0]
                                    namer0ls' = map (addPathH (preS_namer0, preV_namer0)) namer0ls
                                    (rhsr1, rhsr1ls) = getExpressionJCExpression rhsl1
                                    preS_rhsr1 = [2]
                                    preV_rhsr1 = [1]
                                    rhsr1ls' = map (addPathH (preS_rhsr1, preV_rhsr1)) rhsr1ls
                                    l0 = ((AssignmentJCExpressionS0, []),
                                          (AssignmentJCExpressionV0, []))
                                    ls' = concat [namer0ls', rhsr1ls']
getAssignmentJCExpression (FromRelExp relExpl0) = (relExpr0,
                                                   l0 : ls')
                              where (relExpr0, relExpr0ls) = getRelExpJCExpression relExpl0
                                    preS_relExpr0 = [0]
                                    preV_relExpr0 = []
                                    relExpr0ls' = map (addPathH (preS_relExpr0,
                                                                 preV_relExpr0)) relExpr0ls
                                    l0 = ((AssignmentJCExpressionS1, []), (Void, []))
                                    ls' = concat [relExpr0ls']

getRelExpJCExpression :: RelExp -> (JCExpression, [RLink])

getRelExpJCExpression (RelExp0 lhsl0
                               "<"
                               rhsl1) = (JCBinary LESSTHAN lhsr0 rhsr1 "<", l0 : ls')
                          where (lhsr0, lhsr0ls) = getRelExpJCExpression lhsl0
                                preS_lhsr0 = [0]
                                preV_lhsr0 = [1]
                                lhsr0ls' = map (addPathH (preS_lhsr0, preV_lhsr0)) lhsr0ls
                                (rhsr1, rhsr1ls) = getPostfixExpJCExpression rhsl1
                                preS_rhsr1 = [2]
                                preV_rhsr1 = [2]
                                rhsr1ls' = map (addPathH (preS_rhsr1, preV_rhsr1)) rhsr1ls
                                l0 = ((RelExpJCExpressionS0, []), (RelExpJCExpressionV0, []))
                                ls' = concat [lhsr0ls', rhsr1ls']
getRelExpJCExpression (FromAdditiveExp addExpl0) = (addExpr0,
                                                    l0 : ls')
                          where (addExpr0, addExpr0ls) = getAdditiveExpJCExpression addExpl0
                                preS_addExpr0 = [0]
                                preV_addExpr0 = []
                                addExpr0ls' = map (addPathH (preS_addExpr0,
                                                             preV_addExpr0)) addExpr0ls
                                l0 = ((RelExpJCExpressionS1, []), (Void, []))
                                ls' = concat [addExpr0ls']

getAdditiveExpJCExpression :: AdditiveExp ->
                              (JCExpression, [RLink])

getAdditiveExpJCExpression (AdditiveExp0 lhsl0
                                         "+"
                                         rhsl1) = (JCBinary PLUS lhsr0 rhsr1 "+", l0 : ls')
                               where (lhsr0, lhsr0ls) = getAdditiveExpJCExpression lhsl0
                                     preS_lhsr0 = [0]
                                     preV_lhsr0 = [1]
                                     lhsr0ls' = map (addPathH (preS_lhsr0, preV_lhsr0)) lhsr0ls
                                     (rhsr1, rhsr1ls) = getPostfixExpJCExpression rhsl1
                                     preS_rhsr1 = [2]
                                     preV_rhsr1 = [2]
                                     rhsr1ls' = map (addPathH (preS_rhsr1, preV_rhsr1)) rhsr1ls
                                     l0 = ((AdditiveExpJCExpressionS0, []),
                                           (AdditiveExpJCExpressionV0, []))
                                     ls' = concat [lhsr0ls', rhsr1ls']
getAdditiveExpJCExpression (AdditiveExp0 lhsl0
                                         "-"
                                         rhsl1) = (JCBinary MINUS lhsr0 rhsr1 "-", l0 : ls')
                               where (lhsr0, lhsr0ls) = getAdditiveExpJCExpression lhsl0
                                     preS_lhsr0 = [0]
                                     preV_lhsr0 = [1]
                                     lhsr0ls' = map (addPathH (preS_lhsr0, preV_lhsr0)) lhsr0ls
                                     (rhsr1, rhsr1ls) = getPostfixExpJCExpression rhsl1
                                     preS_rhsr1 = [2]
                                     preV_rhsr1 = [2]
                                     rhsr1ls' = map (addPathH (preS_rhsr1, preV_rhsr1)) rhsr1ls
                                     l0 = ((AdditiveExpJCExpressionS1, []),
                                           (AdditiveExpJCExpressionV1, []))
                                     ls' = concat [lhsr0ls', rhsr1ls']
getAdditiveExpJCExpression (FromPostfixExp postExpl0) = (postExpr0,
                                                         l0 : ls')
                               where (postExpr0,
                                      postExpr0ls) = getPostfixExpJCExpression postExpl0
                                     preS_postExpr0 = [0]
                                     preV_postExpr0 = []
                                     postExpr0ls' = map (addPathH (preS_postExpr0,
                                                                   preV_postExpr0)) postExpr0ls
                                     l0 = ((AdditiveExpJCExpressionS2, []), (Void, []))
                                     ls' = concat [postExpr0ls']

getPostfixExpJCExpression :: PostfixExp -> (JCExpression, [RLink])

getPostfixExpJCExpression (PostIncExp pfixl0
                                      "++") = (JCUnary POSTINC pfixr0 "++", l0 : ls')
                              where (pfixr0, pfixr0ls) = getPostfixExpJCExpression pfixl0
                                    preS_pfixr0 = [0]
                                    preV_pfixr0 = [1]
                                    pfixr0ls' = map (addPathH (preS_pfixr0, preV_pfixr0)) pfixr0ls
                                    l0 = ((PostfixExpJCExpressionS0, []),
                                          (PostfixExpJCExpressionV0, []))
                                    ls' = concat [pfixr0ls']
getPostfixExpJCExpression (ExpN idl0) = (JCIdent idr0, l0 : ls')
                              where (idr0, idr0ls) = getStringString idl0
                                    preS_idr0 = [0]
                                    preV_idr0 = [0]
                                    idr0ls' = map (addPathH (preS_idr0, preV_idr0)) idr0ls
                                    l0 = ((PostfixExpJCExpressionS1, []),
                                          (PostfixExpJCExpressionV1, []))
                                    ls' = concat [idr0ls']
getPostfixExpJCExpression (FromPrimary (PrimaryLit litl0)) = (FromJCLiteral litr0,
                                                              l0 : ls')
                              where (litr0, litr0ls) = getULitULit litl0
                                    preS_litr0 = [0, 0]
                                    preV_litr0 = [0]
                                    litr0ls' = map (addPathH (preS_litr0, preV_litr0)) litr0ls
                                    l0 = ((PostfixExpJCExpressionS2, []),
                                          (PostfixExpJCExpressionV2, []))
                                    ls' = concat [litr0ls']
getPostfixExpJCExpression (FromPrimary (FieldAccess (ExpN nl0)
                                                    "."
                                                    fnamel1)) = (JCFieldAccess (JCIdent nr0) fnamer1,
                                                                 l0 : ls')
                              where (nr0, nr0ls) = getStringString nl0
                                    preS_nr0 = [0, 0, 0]
                                    preV_nr0 = [0, 0]
                                    nr0ls' = map (addPathH (preS_nr0, preV_nr0)) nr0ls
                                    (fnamer1, fnamer1ls) = getStringString fnamel1
                                    preS_fnamer1 = [0, 2]
                                    preV_fnamer1 = [1]
                                    fnamer1ls' = map (addPathH (preS_fnamer1,
                                                                preV_fnamer1)) fnamer1ls
                                    l0 = ((PostfixExpJCExpressionS3, []),
                                          (PostfixExpJCExpressionV3, []))
                                    ls' = concat [nr0ls', fnamer1ls']
getPostfixExpJCExpression (FromPrimary (ArrayAccess nl0
                                                    "["
                                                    expl1
                                                    "]")) = (JCArrayAccess (JCIdent nr0) expr1,
                                                             l0 : ls')
                              where (nr0, nr0ls) = getStringString nl0
                                    preS_nr0 = [0, 0]
                                    preV_nr0 = [0, 0]
                                    nr0ls' = map (addPathH (preS_nr0, preV_nr0)) nr0ls
                                    (expr1, expr1ls) = getExpressionJCExpression expl1
                                    preS_expr1 = [0, 2]
                                    preV_expr1 = [1]
                                    expr1ls' = map (addPathH (preS_expr1, preV_expr1)) expr1ls
                                    l0 = ((PostfixExpJCExpressionS4, []),
                                          (PostfixExpJCExpressionV4, []))
                                    ls' = concat [nr0ls', expr1ls']
getPostfixExpJCExpression (FromPrimary (Paren "("
                                              expl0
                                              ")")) = (expr0, l0 : ls')
                              where (expr0, expr0ls) = getExpressionJCExpression expl0
                                    preS_expr0 = [0, 1]
                                    preV_expr0 = []
                                    expr0ls' = map (addPathH (preS_expr0, preV_expr0)) expr0ls
                                    l0 = ((PostfixExpJCExpressionS5, []), (Void, []))
                                    ls' = concat [expr0ls']

getListTypeDeclarationListJCTree :: List TypeDeclaration ->
                                    (List JCTree, [RLink])

getListTypeDeclarationListJCTree (Cons tDecl0
                                       tDecsl1) = (Cons tDecr0 tDecsr1, l0 : ls')
                                     where (tDecr0, tDecr0ls) = getTypeDeclarationJCTree tDecl0
                                           preS_tDecr0 = [0]
                                           preV_tDecr0 = [0]
                                           tDecr0ls' = map (addPathH (preS_tDecr0,
                                                                      preV_tDecr0)) tDecr0ls
                                           (tDecsr1,
                                            tDecsr1ls) = getListTypeDeclarationListJCTree tDecsl1
                                           preS_tDecsr1 = [1]
                                           preV_tDecsr1 = [1]
                                           tDecsr1ls' = map (addPathH (preS_tDecsr1,
                                                                       preV_tDecsr1)) tDecsr1ls
                                           l0 = ((ListTypeDeclarationListJCTreeS0, []),
                                                 (ListTypeDeclarationListJCTreeV0, []))
                                           ls' = concat [tDecr0ls', tDecsr1ls']
getListTypeDeclarationListJCTree (Nil) = (Nil, l0 : ls')
                                     where l0 = ((ListTypeDeclarationListJCTreeS1, []),
                                                 (ListTypeDeclarationListJCTreeV1, []))
                                           ls' = concat []

getListClassBodyDeclarationListJCTree :: List ClassBodyDeclaration ->
                                         (List JCTree, [RLink])

getListClassBodyDeclarationListJCTree (Nil) = (Nil, l0 : ls')
                                          where l0 = ((ListClassBodyDeclarationListJCTreeS0, []),
                                                      (ListClassBodyDeclarationListJCTreeV0, []))
                                                ls' = concat []
getListClassBodyDeclarationListJCTree (Cons al0
                                            asl1) = (Cons ar0 asr1, l0 : ls')
                                          where (ar0, ar0ls) = getClassBodyDeclarationJCTree al0
                                                preS_ar0 = [0]
                                                preV_ar0 = [0]
                                                ar0ls' = map (addPathH (preS_ar0, preV_ar0)) ar0ls
                                                (asr1,
                                                 asr1ls) = getListClassBodyDeclarationListJCTree asl1
                                                preS_asr1 = [1]
                                                preV_asr1 = [1]
                                                asr1ls' = map (addPathH (preS_asr1,
                                                                         preV_asr1)) asr1ls
                                                l0 = ((ListClassBodyDeclarationListJCTreeS1, []),
                                                      (ListClassBodyDeclarationListJCTreeV1, []))
                                                ls' = concat [ar0ls', asr1ls']

getListBlockStatementListJCStatement :: List BlockStatement ->
                                        (List JCStatement, [RLink])

getListBlockStatementListJCStatement (Nil) = (Nil, l0 : ls')
                                         where l0 = ((ListBlockStatementListJCStatementS0, []),
                                                     (ListBlockStatementListJCStatementV0, []))
                                               ls' = concat []
getListBlockStatementListJCStatement (Cons al0
                                           asl1) = (Cons ar0 asr1, l0 : ls')
                                         where (ar0, ar0ls) = getBlockStatementJCStatement al0
                                               preS_ar0 = [0]
                                               preV_ar0 = [0]
                                               ar0ls' = map (addPathH (preS_ar0, preV_ar0)) ar0ls
                                               (asr1,
                                                asr1ls) = getListBlockStatementListJCStatement asl1
                                               preS_asr1 = [1]
                                               preV_asr1 = [1]
                                               asr1ls' = map (addPathH (preS_asr1,
                                                                        preV_asr1)) asr1ls
                                               l0 = ((ListBlockStatementListJCStatementS1, []),
                                                     (ListBlockStatementListJCStatementV1, []))
                                               ls' = concat [ar0ls', asr1ls']

getListExpressionListJCExpression :: List Expression ->
                                     (List JCExpression, [RLink])

getListExpressionListJCExpression (Nil) = (Nil, l0 : ls')
                                      where l0 = ((ListExpressionListJCExpressionS0, []),
                                                  (ListExpressionListJCExpressionV0, []))
                                            ls' = concat []
getListExpressionListJCExpression (Cons el0 esl1) = (Cons er0 esr1,
                                                     l0 : ls')
                                      where (er0, er0ls) = getExpressionJCExpression el0
                                            preS_er0 = [0]
                                            preV_er0 = [0]
                                            er0ls' = map (addPathH (preS_er0, preV_er0)) er0ls
                                            (esr1, esr1ls) = getListExpressionListJCExpression esl1
                                            preS_esr1 = [1]
                                            preV_esr1 = [1]
                                            esr1ls' = map (addPathH (preS_esr1, preV_esr1)) esr1ls
                                            l0 = ((ListExpressionListJCExpressionS1, []),
                                                  (ListExpressionListJCExpressionV1, []))
                                            ls' = concat [er0ls', esr1ls']

getListAssignmentListJCStatement :: List Assignment ->
                                    (List JCStatement, [RLink])

getListAssignmentListJCStatement (Nil) = (Nil, l0 : ls')
                                     where l0 = ((ListAssignmentListJCStatementS0, []),
                                                 (ListAssignmentListJCStatementV0, []))
                                           ls' = concat []
getListAssignmentListJCStatement (Cons assl0
                                       asssl1) = (Cons assr0 asssr1, l0 : ls')
                                     where (assr0, assr0ls) = getAssignmentJCStatement assl0
                                           preS_assr0 = [0]
                                           preV_assr0 = [0]
                                           assr0ls' = map (addPathH (preS_assr0,
                                                                     preV_assr0)) assr0ls
                                           (asssr1,
                                            asssr1ls) = getListAssignmentListJCStatement asssl1
                                           preS_asssr1 = [1]
                                           preV_asssr1 = [1]
                                           asssr1ls' = map (addPathH (preS_asssr1,
                                                                      preV_asssr1)) asssr1ls
                                           l0 = ((ListAssignmentListJCStatementS1, []),
                                                 (ListAssignmentListJCStatementV1, []))
                                           ls' = concat [assr0ls', asssr1ls']

getUTypeUType :: UType -> (UType, [RLink])

getUTypeUType (UInteger) = (UInteger, l0 : ls')
                  where l0 = ((UTypeUTypeS0, []), (UTypeUTypeS0, []))
                        ls' = concat []
getUTypeUType (UString) = (UString, l0 : ls')
                  where l0 = ((UTypeUTypeS1, []), (UTypeUTypeS1, []))
                        ls' = concat []
getUTypeUType (UBool) = (UBool, l0 : ls')
                  where l0 = ((UTypeUTypeS2, []), (UTypeUTypeS2, []))
                        ls' = concat []
getUTypeUType (UVoid) = (UVoid, l0 : ls')
                  where l0 = ((UTypeUTypeS3, []), (UTypeUTypeS3, []))
                        ls' = concat []

getULitULit :: ULit -> (ULit, [RLink])

getULitULit (UIntegerLit il0) = (UIntegerLit ir0, l0 : ls')
                where (ir0, ir0ls) = getIntegerInteger il0
                      preS_ir0 = [0]
                      preV_ir0 = [0]
                      ir0ls' = map (addPathH (preS_ir0, preV_ir0)) ir0ls
                      l0 = ((ULitULitS0, []), (ULitULitS0, []))
                      ls' = concat [ir0ls']
getULitULit (UStringLit sl0) = (UStringLit sr0, l0 : ls')
                where (sr0, sr0ls) = getStringString sl0
                      preS_sr0 = [0]
                      preV_sr0 = [0]
                      sr0ls' = map (addPathH (preS_sr0, preV_sr0)) sr0ls
                      l0 = ((ULitULitS1, []), (ULitULitS1, []))
                      ls' = concat [sr0ls']
getULitULit (UBoolLit bl0) = (UBoolLit br0, l0 : ls')
                where (br0, br0ls) = getBoolBool bl0
                      preS_br0 = [0]
                      preV_br0 = [0]
                      br0ls' = map (addPathH (preS_br0, preV_br0)) br0ls
                      l0 = ((ULitULitS2, []), (ULitULitS2, []))
                      ls' = concat [br0ls']

getIntegerInteger s = (s, [((IntegerR, []), (IntegerR, []))])

getStringString s = (s, [((StringR, []), (StringR, []))])

getCharChar s = (s, [((CharR, []), (CharR, []))])

getBoolBool s = (s, [((BoolR, []), (BoolR, []))])

put :: OSTyTag ->
       STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

put osTy sTy vTy osDyn vDyn env | not (hasTopLink env) = putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env

put osTy sTy vTy osDyn vDyn env | hasTopLink env = putWithLinks osTy sTy vTy osDyn vDyn env

putNoLink :: OSTyTag ->
             STyTag -> VTyTag -> RegPat -> OSDyn -> VDyn -> [RLink] -> SDyn

putNoLink _ (IntegerTag) (IntegerTag) _ _ dynV _ = dynV

putNoLink _ (StringTag) (StringTag) _ _ dynV _ = dynV

putNoLink _ (CharTag) (CharTag) _ _ dynV _ = dynV

putNoLink _ (BoolTag) (BoolTag) _ _ dynV _ = dynV

putNoLink osTy (ClassDeclarationTag) (JCClassDeclTag) ClassDeclarationJCClassDeclS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCClassDecl)) -> Just (JCClassDecl (NNothing)
                                                                                                                                                                nr0
                                                                                                                                                                (JJust (JCIdent supr1))
                                                                                                                                                                bodyr2)) env = toDyn ((NormalClassDeclaration0 "DEF_VAL" "class" res_nr0 "extends" res_supr1 res_bodyr2) :: ClassDeclaration)
              where preS_nr0 = [2]
                    preV_nr0 = [1]
                    env_nr0 = map (delPathH ([], preV_nr0)) (filterEnv preV_nr0 env)
                    res_nr0 :: ( String )
                    res_nr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr0) env_nr0))
                    preS_supr1 = [4]
                    preV_supr1 = [2, 0, 0]
                    env_supr1 = map (delPathH ([],
                                               preV_supr1)) (filterEnv preV_supr1 env)
                    res_supr1 :: ( String )
                    res_supr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn supr1) env_supr1))
                    preS_bodyr2 = [5]
                    preV_bodyr2 = [3]
                    env_bodyr2 = map (delPathH ([],
                                                preV_bodyr2)) (filterEnv preV_bodyr2 env)
                    res_bodyr2 :: ( ClassBody )
                    res_bodyr2 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr2) env_bodyr2))
putNoLink osTy (ClassDeclarationTag) (JCClassDeclTag) ClassDeclarationJCClassDeclS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCClassDecl)) -> Just (JCClassDecl (JJust mdfr0)
                                                                                                                                                                nr1
                                                                                                                                                                (JJust (JCIdent supr2))
                                                                                                                                                                bodyr3)) env = toDyn ((NormalClassDeclaration1 "DEF_VAL" res_mdfr0 "class" res_nr1 "extends" res_supr2 res_bodyr3) :: ClassDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_nr1 = [3]
                    preV_nr1 = [1]
                    env_nr1 = map (delPathH ([], preV_nr1)) (filterEnv preV_nr1 env)
                    res_nr1 :: ( String )
                    res_nr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr1) env_nr1))
                    preS_supr2 = [5]
                    preV_supr2 = [2, 0, 0]
                    env_supr2 = map (delPathH ([],
                                               preV_supr2)) (filterEnv preV_supr2 env)
                    res_supr2 :: ( String )
                    res_supr2 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn supr2) env_supr2))
                    preS_bodyr3 = [6]
                    preV_bodyr3 = [3]
                    env_bodyr3 = map (delPathH ([],
                                                preV_bodyr3)) (filterEnv preV_bodyr3 env)
                    res_bodyr3 :: ( ClassBody )
                    res_bodyr3 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr3) env_bodyr3))
putNoLink osTy (ClassDeclarationTag) (JCClassDeclTag) ClassDeclarationJCClassDeclS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCClassDecl)) -> Just (JCClassDecl (NNothing)
                                                                                                                                                                nr0
                                                                                                                                                                (NNothing)
                                                                                                                                                                bodyr1)) env = toDyn ((NormalClassDeclaration2 "DEF_VAL" "class" res_nr0 res_bodyr1) :: ClassDeclaration)
              where preS_nr0 = [2]
                    preV_nr0 = [1]
                    env_nr0 = map (delPathH ([], preV_nr0)) (filterEnv preV_nr0 env)
                    res_nr0 :: ( String )
                    res_nr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr0) env_nr0))
                    preS_bodyr1 = [3]
                    preV_bodyr1 = [3]
                    env_bodyr1 = map (delPathH ([],
                                                preV_bodyr1)) (filterEnv preV_bodyr1 env)
                    res_bodyr1 :: ( ClassBody )
                    res_bodyr1 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr1) env_bodyr1))
putNoLink osTy (ClassDeclarationTag) (JCClassDeclTag) ClassDeclarationJCClassDeclS3 osDyn ((fromDynamic :: Dynamic -> Maybe (JCClassDecl)) -> Just (JCClassDecl (JJust mdfr0)
                                                                                                                                                                nr1
                                                                                                                                                                (NNothing)
                                                                                                                                                                bodyr2)) env = toDyn ((NormalClassDeclaration3 "DEF_VAL" res_mdfr0 "class" res_nr1 res_bodyr2) :: ClassDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_nr1 = [3]
                    preV_nr1 = [1]
                    env_nr1 = map (delPathH ([], preV_nr1)) (filterEnv preV_nr1 env)
                    res_nr1 :: ( String )
                    res_nr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr1) env_nr1))
                    preS_bodyr2 = [4]
                    preV_bodyr2 = [3]
                    env_bodyr2 = map (delPathH ([],
                                                preV_bodyr2)) (filterEnv preV_bodyr2 env)
                    res_bodyr2 :: ( ClassBody )
                    res_bodyr2 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr2) env_bodyr2))

putNoLink osTy (CompilationUnitTag) (JCCompilationUnitTag) CompilationUnitJCCompilationUnitS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCCompilationUnit)) -> Just (JCCompilationUnit tyDecsr0)) env = toDyn ((CompilationUnit res_tyDecsr0) :: CompilationUnit)
              where preS_tyDecsr0 = [0]
                    preV_tyDecsr0 = [0]
                    env_tyDecsr0 = map (delPathH ([],
                                                  preV_tyDecsr0)) (filterEnv preV_tyDecsr0 env)
                    res_tyDecsr0 :: ( List TypeDeclaration )
                    res_tyDecsr0 = fromJust (fromDynamic (put osTy ListTypeDeclarationTag ListJCTreeTag osDyn (toDyn tyDecsr0) env_tyDecsr0))

putNoLink osTy (EEitherUTypeStringTag) (JCExpressionTag) EEitherUTypeStringJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCPrimitiveTypeTree resTyper0)) env = toDyn ((LLeft res_resTyper0) :: ( EEither UType String ))
              where preS_resTyper0 = [0]
                    preV_resTyper0 = [0]
                    env_resTyper0 = map (delPathH ([],
                                                   preV_resTyper0)) (filterEnv preV_resTyper0 env)
                    res_resTyper0 :: ( UType )
                    res_resTyper0 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn resTyper0) env_resTyper0))
putNoLink osTy (EEitherUTypeStringTag) (JCExpressionTag) EEitherUTypeStringJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCPrimitiveTypeTree (UVoid))) env = toDyn ((RRight "void") :: ( EEither UType String ))

putNoLink osTy (ExpressionTag) (JCExpressionTag) ExpressionJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just expr0) env = toDyn ((AssignExp res_expr0) :: Expression)
              where preS_expr0 = [0]
                    preV_expr0 = []
                    env_expr0 = map (delPathH ([],
                                               preV_expr0)) (filterEnv preV_expr0 env)
                    res_expr0 :: ( Assignment )
                    res_expr0 = fromJust (fromDynamic (put osTy AssignmentTag JCExpressionTag osDyn (toDyn expr0) env_expr0))
putNoLink osTy (ExpressionTag) (JCExpressionTag) ExpressionJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (FromJCPolyExpression (JCMethodInvocation (Nil)
                                                                                                                                                                                    (JCIdent methNamer0)
                                                                                                                                                                                    (NNothing)))) env = toDyn ((MethodInvocation0 res_methNamer0 "(" ")") :: Expression)
              where preS_methNamer0 = [0]
                    preV_methNamer0 = [0, 1, 0]
                    env_methNamer0 = map (delPathH ([],
                                                    preV_methNamer0)) (filterEnv preV_methNamer0 env)
                    res_methNamer0 :: ( String )
                    res_methNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn methNamer0) env_methNamer0))
putNoLink osTy (ExpressionTag) (JCExpressionTag) ExpressionJCExpressionS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (FromJCPolyExpression (JCMethodInvocation (Nil)
                                                                                                                                                                                    (JCIdent methNamer0)
                                                                                                                                                                                    (JJust argr1)))) env = toDyn ((MethodInvocation1 res_methNamer0 "(" res_argr1 ")") :: Expression)
              where preS_methNamer0 = [0]
                    preV_methNamer0 = [0, 1, 0]
                    env_methNamer0 = map (delPathH ([],
                                                    preV_methNamer0)) (filterEnv preV_methNamer0 env)
                    res_methNamer0 :: ( String )
                    res_methNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn methNamer0) env_methNamer0))
                    preS_argr1 = [2]
                    preV_argr1 = [0, 2, 0]
                    env_argr1 = map (delPathH ([],
                                               preV_argr1)) (filterEnv preV_argr1 env)
                    res_argr1 :: ( Expression )
                    res_argr1 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn argr1) env_argr1))

putNoLink osTy (AssignmentTag) (JCExpressionTag) AssignmentJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCAssign (JCIdent namer0)
                                                                                                                                                    rhsr1)) env = toDyn ((Assignment res_namer0 "=" res_rhsr1) :: Assignment)
              where preS_namer0 = [0]
                    preV_namer0 = [0, 0]
                    env_namer0 = map (delPathH ([],
                                                preV_namer0)) (filterEnv preV_namer0 env)
                    res_namer0 :: ( String )
                    res_namer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn namer0) env_namer0))
                    preS_rhsr1 = [2]
                    preV_rhsr1 = [1]
                    env_rhsr1 = map (delPathH ([],
                                               preV_rhsr1)) (filterEnv preV_rhsr1 env)
                    res_rhsr1 :: ( Expression )
                    res_rhsr1 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn rhsr1) env_rhsr1))
putNoLink osTy (AssignmentTag) (JCExpressionTag) AssignmentJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just relExpr0) env = toDyn ((FromRelExp res_relExpr0) :: Assignment)
              where preS_relExpr0 = [0]
                    preV_relExpr0 = []
                    env_relExpr0 = map (delPathH ([],
                                                  preV_relExpr0)) (filterEnv preV_relExpr0 env)
                    res_relExpr0 :: ( RelExp )
                    res_relExpr0 = fromJust (fromDynamic (put osTy RelExpTag JCExpressionTag osDyn (toDyn relExpr0) env_relExpr0))

putNoLink osTy (RelExpTag) (JCExpressionTag) RelExpJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCBinary (LESSTHAN)
                                                                                                                                            lhsr0
                                                                                                                                            rhsr1
                                                                                                                                            "<")) env = toDyn ((RelExp0 res_lhsr0 "<" res_rhsr1) :: RelExp)
              where preS_lhsr0 = [0]
                    preV_lhsr0 = [1]
                    env_lhsr0 = map (delPathH ([],
                                               preV_lhsr0)) (filterEnv preV_lhsr0 env)
                    res_lhsr0 :: ( RelExp )
                    res_lhsr0 = fromJust (fromDynamic (put osTy RelExpTag JCExpressionTag osDyn (toDyn lhsr0) env_lhsr0))
                    preS_rhsr1 = [2]
                    preV_rhsr1 = [2]
                    env_rhsr1 = map (delPathH ([],
                                               preV_rhsr1)) (filterEnv preV_rhsr1 env)
                    res_rhsr1 :: ( PostfixExp )
                    res_rhsr1 = fromJust (fromDynamic (put osTy PostfixExpTag JCExpressionTag osDyn (toDyn rhsr1) env_rhsr1))
putNoLink osTy (RelExpTag) (JCExpressionTag) RelExpJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just addExpr0) env = toDyn ((FromAdditiveExp res_addExpr0) :: RelExp)
              where preS_addExpr0 = [0]
                    preV_addExpr0 = []
                    env_addExpr0 = map (delPathH ([],
                                                  preV_addExpr0)) (filterEnv preV_addExpr0 env)
                    res_addExpr0 :: ( AdditiveExp )
                    res_addExpr0 = fromJust (fromDynamic (put osTy AdditiveExpTag JCExpressionTag osDyn (toDyn addExpr0) env_addExpr0))

putNoLink osTy (AdditiveExpTag) (JCExpressionTag) AdditiveExpJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCBinary (PLUS)
                                                                                                                                                      lhsr0
                                                                                                                                                      rhsr1
                                                                                                                                                      "+")) env = toDyn ((AdditiveExp0 res_lhsr0 "+" res_rhsr1) :: AdditiveExp)
              where preS_lhsr0 = [0]
                    preV_lhsr0 = [1]
                    env_lhsr0 = map (delPathH ([],
                                               preV_lhsr0)) (filterEnv preV_lhsr0 env)
                    res_lhsr0 :: ( AdditiveExp )
                    res_lhsr0 = fromJust (fromDynamic (put osTy AdditiveExpTag JCExpressionTag osDyn (toDyn lhsr0) env_lhsr0))
                    preS_rhsr1 = [2]
                    preV_rhsr1 = [2]
                    env_rhsr1 = map (delPathH ([],
                                               preV_rhsr1)) (filterEnv preV_rhsr1 env)
                    res_rhsr1 :: ( PostfixExp )
                    res_rhsr1 = fromJust (fromDynamic (put osTy PostfixExpTag JCExpressionTag osDyn (toDyn rhsr1) env_rhsr1))
putNoLink osTy (AdditiveExpTag) (JCExpressionTag) AdditiveExpJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCBinary (MINUS)
                                                                                                                                                      lhsr0
                                                                                                                                                      rhsr1
                                                                                                                                                      "-")) env = toDyn ((AdditiveExp0 res_lhsr0 "-" res_rhsr1) :: AdditiveExp)
              where preS_lhsr0 = [0]
                    preV_lhsr0 = [1]
                    env_lhsr0 = map (delPathH ([],
                                               preV_lhsr0)) (filterEnv preV_lhsr0 env)
                    res_lhsr0 :: ( AdditiveExp )
                    res_lhsr0 = fromJust (fromDynamic (put osTy AdditiveExpTag JCExpressionTag osDyn (toDyn lhsr0) env_lhsr0))
                    preS_rhsr1 = [2]
                    preV_rhsr1 = [2]
                    env_rhsr1 = map (delPathH ([],
                                               preV_rhsr1)) (filterEnv preV_rhsr1 env)
                    res_rhsr1 :: ( PostfixExp )
                    res_rhsr1 = fromJust (fromDynamic (put osTy PostfixExpTag JCExpressionTag osDyn (toDyn rhsr1) env_rhsr1))
putNoLink osTy (AdditiveExpTag) (JCExpressionTag) AdditiveExpJCExpressionS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just postExpr0) env = toDyn ((FromPostfixExp res_postExpr0) :: AdditiveExp)
              where preS_postExpr0 = [0]
                    preV_postExpr0 = []
                    env_postExpr0 = map (delPathH ([],
                                                   preV_postExpr0)) (filterEnv preV_postExpr0 env)
                    res_postExpr0 :: ( PostfixExp )
                    res_postExpr0 = fromJust (fromDynamic (put osTy PostfixExpTag JCExpressionTag osDyn (toDyn postExpr0) env_postExpr0))

putNoLink osTy (PostfixExpTag) (JCExpressionTag) PostfixExpJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCUnary (POSTINC)
                                                                                                                                                   pfixr0
                                                                                                                                                   "++")) env = toDyn ((PostIncExp res_pfixr0 "++") :: PostfixExp)
              where preS_pfixr0 = [0]
                    preV_pfixr0 = [1]
                    env_pfixr0 = map (delPathH ([],
                                                preV_pfixr0)) (filterEnv preV_pfixr0 env)
                    res_pfixr0 :: ( PostfixExp )
                    res_pfixr0 = fromJust (fromDynamic (put osTy PostfixExpTag JCExpressionTag osDyn (toDyn pfixr0) env_pfixr0))
putNoLink osTy (PostfixExpTag) (JCExpressionTag) PostfixExpJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCIdent idr0)) env = toDyn ((ExpN res_idr0) :: PostfixExp)
              where preS_idr0 = [0]
                    preV_idr0 = [0]
                    env_idr0 = map (delPathH ([], preV_idr0)) (filterEnv preV_idr0 env)
                    res_idr0 :: ( String )
                    res_idr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn idr0) env_idr0))
putNoLink osTy (PostfixExpTag) (JCExpressionTag) PostfixExpJCExpressionS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (FromJCLiteral litr0)) env = toDyn ((FromPrimary (PrimaryLit res_litr0)) :: PostfixExp)
              where preS_litr0 = [0, 0]
                    preV_litr0 = [0]
                    env_litr0 = map (delPathH ([],
                                               preV_litr0)) (filterEnv preV_litr0 env)
                    res_litr0 :: ( ULit )
                    res_litr0 = fromJust (fromDynamic (put osTy ULitTag ULitTag osDyn (toDyn litr0) env_litr0))
putNoLink osTy (PostfixExpTag) (JCExpressionTag) PostfixExpJCExpressionS3 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCFieldAccess (JCIdent nr0)
                                                                                                                                                         fnamer1)) env = toDyn ((FromPrimary (FieldAccess (ExpN res_nr0) "." res_fnamer1)) :: PostfixExp)
              where preS_nr0 = [0, 0, 0]
                    preV_nr0 = [0, 0]
                    env_nr0 = map (delPathH ([], preV_nr0)) (filterEnv preV_nr0 env)
                    res_nr0 :: ( String )
                    res_nr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr0) env_nr0))
                    preS_fnamer1 = [0, 2]
                    preV_fnamer1 = [1]
                    env_fnamer1 = map (delPathH ([],
                                                 preV_fnamer1)) (filterEnv preV_fnamer1 env)
                    res_fnamer1 :: ( String )
                    res_fnamer1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn fnamer1) env_fnamer1))
putNoLink osTy (PostfixExpTag) (JCExpressionTag) PostfixExpJCExpressionS4 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just (JCArrayAccess (JCIdent nr0)
                                                                                                                                                         expr1)) env = toDyn ((FromPrimary (ArrayAccess res_nr0 "[" res_expr1 "]")) :: PostfixExp)
              where preS_nr0 = [0, 0]
                    preV_nr0 = [0, 0]
                    env_nr0 = map (delPathH ([], preV_nr0)) (filterEnv preV_nr0 env)
                    res_nr0 :: ( String )
                    res_nr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr0) env_nr0))
                    preS_expr1 = [0, 2]
                    preV_expr1 = [1]
                    env_expr1 = map (delPathH ([],
                                               preV_expr1)) (filterEnv preV_expr1 env)
                    res_expr1 :: ( Expression )
                    res_expr1 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn expr1) env_expr1))
putNoLink osTy (PostfixExpTag) (JCExpressionTag) PostfixExpJCExpressionS5 osDyn ((fromDynamic :: Dynamic -> Maybe (JCExpression)) -> Just expr0) env = toDyn ((FromPrimary (Paren "(" res_expr0 ")")) :: PostfixExp)
              where preS_expr0 = [0, 1]
                    preV_expr0 = []
                    env_expr0 = map (delPathH ([],
                                               preV_expr0)) (filterEnv preV_expr0 env)
                    res_expr0 :: ( Expression )
                    res_expr0 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn expr0) env_expr0))

putNoLink osTy (BlockStatementTag) (JCStatementTag) BlockStatementJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                                   varNamer0
                                                                                                                                                                                   (JCPrimitiveTypeTree tyr1)
                                                                                                                                                                                   (NNothing)))) env = toDyn ((LocalVariableDeclaration res_tyr1 (VariableDeclarator0 res_varNamer0)) :: BlockStatement)
              where preS_varNamer0 = [1, 0]
                    preV_varNamer0 = [0, 1]
                    env_varNamer0 = map (delPathH ([],
                                                   preV_varNamer0)) (filterEnv preV_varNamer0 env)
                    res_varNamer0 :: ( String )
                    res_varNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varNamer0) env_varNamer0))
                    preS_tyr1 = [0]
                    preV_tyr1 = [0, 2, 0]
                    env_tyr1 = map (delPathH ([], preV_tyr1)) (filterEnv preV_tyr1 env)
                    res_tyr1 :: ( UType )
                    res_tyr1 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr1) env_tyr1))
putNoLink osTy (BlockStatementTag) (JCStatementTag) BlockStatementJCStatementS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                                   varNamer0
                                                                                                                                                                                   (JCPrimitiveTypeTree tyr1)
                                                                                                                                                                                   (JJust initValr2)))) env = toDyn ((LocalVariableDeclaration res_tyr1 (VariableDeclarator1 res_varNamer0 (VariableInitializer "=" res_initValr2))) :: BlockStatement)
              where preS_varNamer0 = [1, 0]
                    preV_varNamer0 = [0, 1]
                    env_varNamer0 = map (delPathH ([],
                                                   preV_varNamer0)) (filterEnv preV_varNamer0 env)
                    res_varNamer0 :: ( String )
                    res_varNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varNamer0) env_varNamer0))
                    preS_tyr1 = [0]
                    preV_tyr1 = [0, 2, 0]
                    env_tyr1 = map (delPathH ([], preV_tyr1)) (filterEnv preV_tyr1 env)
                    res_tyr1 :: ( UType )
                    res_tyr1 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr1) env_tyr1))
                    preS_initValr2 = [1, 1, 1]
                    preV_initValr2 = [0, 3, 0]
                    env_initValr2 = map (delPathH ([],
                                                   preV_initValr2)) (filterEnv preV_initValr2 env)
                    res_initValr2 :: ( Expression )
                    res_initValr2 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn initValr2) env_initValr2))
putNoLink osTy (BlockStatementTag) (JCStatementTag) BlockStatementJCStatementS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCClassDecl classDecr0)) env = toDyn ((BlockFromClassDeclaration res_classDecr0) :: BlockStatement)
              where preS_classDecr0 = [0]
                    preV_classDecr0 = [0]
                    env_classDecr0 = map (delPathH ([],
                                                    preV_classDecr0)) (filterEnv preV_classDecr0 env)
                    res_classDecr0 :: ( ClassDeclaration )
                    res_classDecr0 = fromJust (fromDynamic (put osTy ClassDeclarationTag JCClassDeclTag osDyn (toDyn classDecr0) env_classDecr0))
putNoLink osTy (BlockStatementTag) (JCStatementTag) BlockStatementJCStatementS3 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just stmtr0) env = toDyn ((FromStatement res_stmtr0) :: BlockStatement)
              where preS_stmtr0 = [0]
                    preV_stmtr0 = []
                    env_stmtr0 = map (delPathH ([],
                                                preV_stmtr0)) (filterEnv preV_stmtr0 env)
                    res_stmtr0 :: ( Statement )
                    res_stmtr0 = fromJust (fromDynamic (put osTy StatementTag JCStatementTag osDyn (toDyn stmtr0) env_stmtr0))

putNoLink osTy (StatementTag) (JCStatementTag) StatementJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCExpressionStatement exprr0)) env = toDyn ((ExpressionStatement res_exprr0 ";") :: Statement)
              where preS_exprr0 = [0]
                    preV_exprr0 = [0]
                    env_exprr0 = map (delPathH ([],
                                                preV_exprr0)) (filterEnv preV_exprr0 env)
                    res_exprr0 :: ( Expression )
                    res_exprr0 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn exprr0) env_exprr0))
putNoLink osTy (StatementTag) (JCStatementTag) StatementJCStatementS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (JCIf condr0
                                                                                                                                           trueStmtr1
                                                                                                                                           falseStmtr2)) env = toDyn ((IfThenElse "if" "(" res_condr0 ")" res_trueStmtr1 "else" res_falseStmtr2) :: Statement)
              where preS_condr0 = [2]
                    preV_condr0 = [0]
                    env_condr0 = map (delPathH ([],
                                                preV_condr0)) (filterEnv preV_condr0 env)
                    res_condr0 :: ( Expression )
                    res_condr0 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn condr0) env_condr0))
                    preS_trueStmtr1 = [4]
                    preV_trueStmtr1 = [1]
                    env_trueStmtr1 = map (delPathH ([],
                                                    preV_trueStmtr1)) (filterEnv preV_trueStmtr1 env)
                    res_trueStmtr1 :: ( Statement )
                    res_trueStmtr1 = fromJust (fromDynamic (put osTy StatementTag JCStatementTag osDyn (toDyn trueStmtr1) env_trueStmtr1))
                    preS_falseStmtr2 = [6]
                    preV_falseStmtr2 = [2]
                    env_falseStmtr2 = map (delPathH ([],
                                                     preV_falseStmtr2)) (filterEnv preV_falseStmtr2 env)
                    res_falseStmtr2 :: ( Statement )
                    res_falseStmtr2 = fromJust (fromDynamic (put osTy StatementTag JCStatementTag osDyn (toDyn falseStmtr2) env_falseStmtr2))
putNoLink osTy (StatementTag) (JCStatementTag) StatementJCStatementS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (JCForLoop varDeclr0
                                                                                                                                                expr1
                                                                                                                                                updr2
                                                                                                                                                stmtr3)) env = toDyn ((BasicFor "for" "(" res_varDeclr0 ";" res_expr1 ";" res_updr2 ")" res_stmtr3) :: Statement)
              where preS_varDeclr0 = [2]
                    preV_varDeclr0 = [0]
                    env_varDeclr0 = map (delPathH ([],
                                                   preV_varDeclr0)) (filterEnv preV_varDeclr0 env)
                    res_varDeclr0 :: ( List BlockStatement )
                    res_varDeclr0 = fromJust (fromDynamic (put osTy ListBlockStatementTag ListJCStatementTag osDyn (toDyn varDeclr0) env_varDeclr0))
                    preS_expr1 = [4]
                    preV_expr1 = [1]
                    env_expr1 = map (delPathH ([],
                                               preV_expr1)) (filterEnv preV_expr1 env)
                    res_expr1 :: ( Expression )
                    res_expr1 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn expr1) env_expr1))
                    preS_updr2 = [6]
                    preV_updr2 = [2]
                    env_updr2 = map (delPathH ([],
                                               preV_updr2)) (filterEnv preV_updr2 env)
                    res_updr2 :: ( List Expression )
                    res_updr2 = fromJust (fromDynamic (put osTy ListExpressionTag ListJCExpressionTag osDyn (toDyn updr2) env_updr2))
                    preS_stmtr3 = [8]
                    preV_stmtr3 = [3]
                    env_stmtr3 = map (delPathH ([],
                                                preV_stmtr3)) (filterEnv preV_stmtr3 env)
                    res_stmtr3 :: ( Statement )
                    res_stmtr3 = fromJust (fromDynamic (put osTy StatementTag JCStatementTag osDyn (toDyn stmtr3) env_stmtr3))
putNoLink osTy (StatementTag) (JCStatementTag) StatementJCStatementS3 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (JCForLoop (Nil)
                                                                                                                                                expr0
                                                                                                                                                (Nil)
                                                                                                                                                stmtr1)) env = toDyn ((While "while" "(" res_expr0 ")" res_stmtr1) :: Statement)
              where preS_expr0 = [2]
                    preV_expr0 = [1]
                    env_expr0 = map (delPathH ([],
                                               preV_expr0)) (filterEnv preV_expr0 env)
                    res_expr0 :: ( Expression )
                    res_expr0 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn expr0) env_expr0))
                    preS_stmtr1 = [4]
                    preV_stmtr1 = [3]
                    env_stmtr1 = map (delPathH ([],
                                                preV_stmtr1)) (filterEnv preV_stmtr1 env)
                    res_stmtr1 :: ( Statement )
                    res_stmtr1 = fromJust (fromDynamic (put osTy StatementTag JCStatementTag osDyn (toDyn stmtr1) env_stmtr1))
putNoLink osTy (StatementTag) (JCStatementTag) StatementJCStatementS4 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (JCForLoop (Cons (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                                          "i"
                                                                                                                                                                                          (JCPrimitiveTypeTree (UInteger))
                                                                                                                                                                                          (JJust (FromJCLiteral (UIntegerLit 0)))))
                                                                                                                                                      (Nil))
                                                                                                                                                (JCBinary (LESSTHAN)
                                                                                                                                                          (JCIdent "i")
                                                                                                                                                          (JCFieldAccess expr0
                                                                                                                                                                         "length")
                                                                                                                                                          "<")
                                                                                                                                                (Cons (JCUnary (POSTINC)
                                                                                                                                                               (JCIdent "i")
                                                                                                                                                               "++")
                                                                                                                                                      (Nil))
                                                                                                                                                (FromJCBlock (Cons (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                                                       varr1
                                                                                                                                                                                                       (JCPrimitiveTypeTree tyr2)
                                                                                                                                                                                                       (JJust (JCArrayAccess expr3
                                                                                                                                                                                                                             (JCIdent "i")))))
                                                                                                                                                                   stmtr4)))) env = if nonLinearCheck == True
                                                                                                                                                                                     then toDyn ((EnhancedFor "for" "(" res_tyr2 res_varr1 ":" res_expr0 ")" res_stmtr4) :: Statement)
                                                                                                                                                                                     else (error "ERROR. In the put direction, in the view, subtrees bound to nonlinear patterns differ.")
              where preS_expr0 = [5]
                    preV_expr0 = [1, 2, 0]
                    env_expr0 = map (delPathH ([],
                                               preV_expr0)) (filterEnv preV_expr0 env)
                    res_expr0 :: ( Expression )
                    res_expr0 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn expr0) env_expr0))
                    preS_varr1 = [3]
                    preV_varr1 = [3, 0, 0, 0, 1]
                    env_varr1 = map (delPathH ([],
                                               preV_varr1)) (filterEnv preV_varr1 env)
                    res_varr1 :: ( String )
                    res_varr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varr1) env_varr1))
                    preS_tyr2 = [2]
                    preV_tyr2 = [3, 0, 0, 0, 2, 0]
                    env_tyr2 = map (delPathH ([], preV_tyr2)) (filterEnv preV_tyr2 env)
                    res_tyr2 :: ( UType )
                    res_tyr2 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr2) env_tyr2))
                    preS_expr3 = [5]
                    preV_expr3 = [3, 0, 0, 0, 3, 0, 0]
                    env_expr3 = map (delPathH ([],
                                               preV_expr3)) (filterEnv preV_expr3 env)
                    res_expr3 :: ( Expression )
                    res_expr3 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn expr3) env_expr3))
                    preS_stmtr4 = [7]
                    preV_stmtr4 = [3, 0, 1]
                    env_stmtr4 = map (delPathH ([],
                                                preV_stmtr4)) (filterEnv preV_stmtr4 env)
                    res_stmtr4 :: ( Statement )
                    res_stmtr4 = fromJust (fromDynamic (put osTy StatementTag ListJCStatementTag osDyn (toDyn stmtr4) env_stmtr4))
                    nonLinearCheck = all (== res_expr0) [res_expr3] && all (== res_expr0) [res_expr3]
putNoLink osTy (StatementTag) (JCStatementTag) StatementJCStatementS5 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCBlock blockr0)) env = toDyn ((FromBlockStatement res_blockr0) :: Statement)
              where preS_blockr0 = [0]
                    preV_blockr0 = [0]
                    env_blockr0 = map (delPathH ([],
                                                 preV_blockr0)) (filterEnv preV_blockr0 env)
                    res_blockr0 :: ( List BlockStatement )
                    res_blockr0 = fromJust (fromDynamic (put osTy ListBlockStatementTag ListJCStatementTag osDyn (toDyn blockr0) env_blockr0))

putNoLink osTy (AssignmentTag) (JCStatementTag) AssignmentJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCExpressionStatement (JCAssign (JCIdent namer0)
                                                                                                                                                                            rhsr1))) env = toDyn ((Assignment res_namer0 "=" res_rhsr1) :: Assignment)
              where preS_namer0 = [0]
                    preV_namer0 = [0, 0, 0]
                    env_namer0 = map (delPathH ([],
                                                preV_namer0)) (filterEnv preV_namer0 env)
                    res_namer0 :: ( String )
                    res_namer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn namer0) env_namer0))
                    preS_rhsr1 = [2]
                    preV_rhsr1 = [0, 1]
                    env_rhsr1 = map (delPathH ([],
                                               preV_rhsr1)) (filterEnv preV_rhsr1 env)
                    res_rhsr1 :: ( Expression )
                    res_rhsr1 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn rhsr1) env_rhsr1))
putNoLink osTy (AssignmentTag) (JCStatementTag) AssignmentJCStatementS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCStatement)) -> Just (FromJCExpressionStatement relExpr0)) env = toDyn ((FromRelExp res_relExpr0) :: Assignment)
              where preS_relExpr0 = [0]
                    preV_relExpr0 = [0]
                    env_relExpr0 = map (delPathH ([],
                                                  preV_relExpr0)) (filterEnv preV_relExpr0 env)
                    res_relExpr0 :: ( RelExp )
                    res_relExpr0 = fromJust (fromDynamic (put osTy RelExpTag JCExpressionTag osDyn (toDyn relExpr0) env_relExpr0))

putNoLink osTy (TypeDeclarationTag) (JCTreeTag) TypeDeclarationJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (JCSkip))) env = toDyn ((TypeDeclarationSkip ";") :: TypeDeclaration)
putNoLink osTy (TypeDeclarationTag) (JCTreeTag) TypeDeclarationJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just classr0) env = toDyn ((FromClassDeclaration res_classr0) :: TypeDeclaration)
              where preS_classr0 = [0]
                    preV_classr0 = []
                    env_classr0 = map (delPathH ([],
                                                 preV_classr0)) (filterEnv preV_classr0 env)
                    res_classr0 :: ( ClassDeclaration )
                    res_classr0 = fromJust (fromDynamic (put osTy ClassDeclarationTag JCTreeTag osDyn (toDyn classr0) env_classr0))

putNoLink osTy (ClassDeclarationTag) (JCTreeTag) ClassDeclarationJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (NNothing)
                                                                                                                                                                                   nr0
                                                                                                                                                                                   (JJust (JCIdent supr1))
                                                                                                                                                                                   bodyr2)))) env = toDyn ((NormalClassDeclaration0 "DEF_VAL" "class" res_nr0 "extends" res_supr1 res_bodyr2) :: ClassDeclaration)
              where preS_nr0 = [2]
                    preV_nr0 = [0, 0, 1]
                    env_nr0 = map (delPathH ([], preV_nr0)) (filterEnv preV_nr0 env)
                    res_nr0 :: ( String )
                    res_nr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr0) env_nr0))
                    preS_supr1 = [4]
                    preV_supr1 = [0, 0, 2, 0, 0]
                    env_supr1 = map (delPathH ([],
                                               preV_supr1)) (filterEnv preV_supr1 env)
                    res_supr1 :: ( String )
                    res_supr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn supr1) env_supr1))
                    preS_bodyr2 = [5]
                    preV_bodyr2 = [0, 0, 3]
                    env_bodyr2 = map (delPathH ([],
                                                preV_bodyr2)) (filterEnv preV_bodyr2 env)
                    res_bodyr2 :: ( ClassBody )
                    res_bodyr2 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr2) env_bodyr2))
putNoLink osTy (ClassDeclarationTag) (JCTreeTag) ClassDeclarationJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust mdfr0)
                                                                                                                                                                                   nr1
                                                                                                                                                                                   (JJust (JCIdent supr2))
                                                                                                                                                                                   bodyr3)))) env = toDyn ((NormalClassDeclaration1 "DEF_VAL" res_mdfr0 "class" res_nr1 "extends" res_supr2 res_bodyr3) :: ClassDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0, 0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_nr1 = [3]
                    preV_nr1 = [0, 0, 1]
                    env_nr1 = map (delPathH ([], preV_nr1)) (filterEnv preV_nr1 env)
                    res_nr1 :: ( String )
                    res_nr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr1) env_nr1))
                    preS_supr2 = [5]
                    preV_supr2 = [0, 0, 2, 0, 0]
                    env_supr2 = map (delPathH ([],
                                               preV_supr2)) (filterEnv preV_supr2 env)
                    res_supr2 :: ( String )
                    res_supr2 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn supr2) env_supr2))
                    preS_bodyr3 = [6]
                    preV_bodyr3 = [0, 0, 3]
                    env_bodyr3 = map (delPathH ([],
                                                preV_bodyr3)) (filterEnv preV_bodyr3 env)
                    res_bodyr3 :: ( ClassBody )
                    res_bodyr3 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr3) env_bodyr3))
putNoLink osTy (ClassDeclarationTag) (JCTreeTag) ClassDeclarationJCTreeS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (NNothing)
                                                                                                                                                                                   nr0
                                                                                                                                                                                   (NNothing)
                                                                                                                                                                                   bodyr1)))) env = toDyn ((NormalClassDeclaration2 "DEF_VAL" "class" res_nr0 res_bodyr1) :: ClassDeclaration)
              where preS_nr0 = [2]
                    preV_nr0 = [0, 0, 1]
                    env_nr0 = map (delPathH ([], preV_nr0)) (filterEnv preV_nr0 env)
                    res_nr0 :: ( String )
                    res_nr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr0) env_nr0))
                    preS_bodyr1 = [3]
                    preV_bodyr1 = [0, 0, 3]
                    env_bodyr1 = map (delPathH ([],
                                                preV_bodyr1)) (filterEnv preV_bodyr1 env)
                    res_bodyr1 :: ( ClassBody )
                    res_bodyr1 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr1) env_bodyr1))
putNoLink osTy (ClassDeclarationTag) (JCTreeTag) ClassDeclarationJCTreeS3 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCClassDecl (JCClassDecl (JJust mdfr0)
                                                                                                                                                                                   nr1
                                                                                                                                                                                   (NNothing)
                                                                                                                                                                                   bodyr2)))) env = toDyn ((NormalClassDeclaration3 "DEF_VAL" res_mdfr0 "class" res_nr1 res_bodyr2) :: ClassDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0, 0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_nr1 = [3]
                    preV_nr1 = [0, 0, 1]
                    env_nr1 = map (delPathH ([], preV_nr1)) (filterEnv preV_nr1 env)
                    res_nr1 :: ( String )
                    res_nr1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn nr1) env_nr1))
                    preS_bodyr2 = [4]
                    preV_bodyr2 = [0, 0, 3]
                    env_bodyr2 = map (delPathH ([],
                                                preV_bodyr2)) (filterEnv preV_bodyr2 env)
                    res_bodyr2 :: ( ClassBody )
                    res_bodyr2 = fromJust (fromDynamic (put osTy ClassBodyTag ListJCTreeTag osDyn (toDyn bodyr2) env_bodyr2))

putNoLink osTy (ClassBodyDeclarationTag) (JCTreeTag) ClassBodyDeclarationJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just decr0) env = toDyn ((FromClassMemberDeclaration res_decr0) :: ClassBodyDeclaration)
              where preS_decr0 = [0]
                    preV_decr0 = []
                    env_decr0 = map (delPathH ([],
                                               preV_decr0)) (filterEnv preV_decr0 env)
                    res_decr0 :: ( ClassMemberDeclaration )
                    res_decr0 = fromJust (fromDynamic (put osTy ClassMemberDeclarationTag JCTreeTag osDyn (toDyn decr0) env_decr0))
putNoLink osTy (ClassBodyDeclarationTag) (JCTreeTag) ClassBodyDeclarationJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCBlock decr0))) env = toDyn ((FromInstanceInitializer res_decr0) :: ClassBodyDeclaration)
              where preS_decr0 = [0]
                    preV_decr0 = [0, 0]
                    env_decr0 = map (delPathH ([],
                                               preV_decr0)) (filterEnv preV_decr0 env)
                    res_decr0 :: ( List BlockStatement )
                    res_decr0 = fromJust (fromDynamic (put osTy ListBlockStatementTag ListJCStatementTag osDyn (toDyn decr0) env_decr0))

putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                                                     varNamer0
                                                                                                                                                                                                     (JCPrimitiveTypeTree tyr1)
                                                                                                                                                                                                     (NNothing))))) env = toDyn ((FieldDeclaration0 "DEF_VAL" res_tyr1 (VariableDeclarator0 res_varNamer0) ";") :: ClassMemberDeclaration)
              where preS_varNamer0 = [2, 0]
                    preV_varNamer0 = [0, 0, 1]
                    env_varNamer0 = map (delPathH ([],
                                                   preV_varNamer0)) (filterEnv preV_varNamer0 env)
                    res_varNamer0 :: ( String )
                    res_varNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varNamer0) env_varNamer0))
                    preS_tyr1 = [1]
                    preV_tyr1 = [0, 0, 2, 0]
                    env_tyr1 = map (delPathH ([], preV_tyr1)) (filterEnv preV_tyr1 env)
                    res_tyr1 :: ( UType )
                    res_tyr1 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr1) env_tyr1))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (JJust mdfr0)
                                                                                                                                                                                                     varNamer1
                                                                                                                                                                                                     (JCPrimitiveTypeTree tyr2)
                                                                                                                                                                                                     (NNothing))))) env = toDyn ((FieldDeclaration1 "DEF_VAL" res_mdfr0 res_tyr2 (VariableDeclarator0 res_varNamer1) ";") :: ClassMemberDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0, 0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_varNamer1 = [3, 0]
                    preV_varNamer1 = [0, 0, 1]
                    env_varNamer1 = map (delPathH ([],
                                                   preV_varNamer1)) (filterEnv preV_varNamer1 env)
                    res_varNamer1 :: ( String )
                    res_varNamer1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varNamer1) env_varNamer1))
                    preS_tyr2 = [2]
                    preV_tyr2 = [0, 0, 2, 0]
                    env_tyr2 = map (delPathH ([], preV_tyr2)) (filterEnv preV_tyr2 env)
                    res_tyr2 :: ( UType )
                    res_tyr2 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr2) env_tyr2))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS2 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (NNothing)
                                                                                                                                                                                                     varNamer0
                                                                                                                                                                                                     (JCPrimitiveTypeTree tyr1)
                                                                                                                                                                                                     (JJust initValr2))))) env = toDyn ((FieldDeclaration0 "DEF_VAL" res_tyr1 (VariableDeclarator1 res_varNamer0 (VariableInitializer "=" res_initValr2)) ";") :: ClassMemberDeclaration)
              where preS_varNamer0 = [2, 0]
                    preV_varNamer0 = [0, 0, 1]
                    env_varNamer0 = map (delPathH ([],
                                                   preV_varNamer0)) (filterEnv preV_varNamer0 env)
                    res_varNamer0 :: ( String )
                    res_varNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varNamer0) env_varNamer0))
                    preS_tyr1 = [1]
                    preV_tyr1 = [0, 0, 2, 0]
                    env_tyr1 = map (delPathH ([], preV_tyr1)) (filterEnv preV_tyr1 env)
                    res_tyr1 :: ( UType )
                    res_tyr1 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr1) env_tyr1))
                    preS_initValr2 = [2, 1, 1]
                    preV_initValr2 = [0, 0, 3, 0]
                    env_initValr2 = map (delPathH ([],
                                                   preV_initValr2)) (filterEnv preV_initValr2 env)
                    res_initValr2 :: ( Expression )
                    res_initValr2 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn initValr2) env_initValr2))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS3 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCStatement (FromJCVariableDecl (JCVariableDecl (JJust mdfr0)
                                                                                                                                                                                                     varNamer1
                                                                                                                                                                                                     (JCPrimitiveTypeTree tyr2)
                                                                                                                                                                                                     (JJust initValr3))))) env = toDyn ((FieldDeclaration1 "DEF_VAL" res_mdfr0 res_tyr2 (VariableDeclarator1 res_varNamer1 (VariableInitializer "=" res_initValr3)) ";") :: ClassMemberDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0, 0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_varNamer1 = [3, 0]
                    preV_varNamer1 = [0, 0, 1]
                    env_varNamer1 = map (delPathH ([],
                                                   preV_varNamer1)) (filterEnv preV_varNamer1 env)
                    res_varNamer1 :: ( String )
                    res_varNamer1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn varNamer1) env_varNamer1))
                    preS_tyr2 = [2]
                    preV_tyr2 = [0, 0, 2, 0]
                    env_tyr2 = map (delPathH ([], preV_tyr2)) (filterEnv preV_tyr2 env)
                    res_tyr2 :: ( UType )
                    res_tyr2 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr2) env_tyr2))
                    preS_initValr3 = [3, 1, 1]
                    preV_initValr3 = [0, 0, 3, 0]
                    env_initValr3 = map (delPathH ([],
                                                   preV_initValr3)) (filterEnv preV_initValr3 env)
                    res_initValr3 :: ( Expression )
                    res_initValr3 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn initValr3) env_initValr3))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS4 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCMethodDecl (JCMethodDecl (NNothing)
                                                                                                                                                                                methNamer0
                                                                                                                                                                                resTyper1
                                                                                                                                                                                (NNothing)
                                                                                                                                                                                bodyr2))) env = toDyn ((MethodDeclaration0 "DEF_VAL" (MethodHeader res_resTyper1 (MethodDeclarator0 res_methNamer0 "(" ")")) res_bodyr2) :: ClassMemberDeclaration)
              where preS_methNamer0 = [1, 1, 0]
                    preV_methNamer0 = [0, 1]
                    env_methNamer0 = map (delPathH ([],
                                                    preV_methNamer0)) (filterEnv preV_methNamer0 env)
                    res_methNamer0 :: ( String )
                    res_methNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn methNamer0) env_methNamer0))
                    preS_resTyper1 = [1, 0]
                    preV_resTyper1 = [0, 2]
                    env_resTyper1 = map (delPathH ([],
                                                   preV_resTyper1)) (filterEnv preV_resTyper1 env)
                    res_resTyper1 :: ( EEither UType String )
                    res_resTyper1 = fromJust (fromDynamic (put osTy EEitherUTypeStringTag JCExpressionTag osDyn (toDyn resTyper1) env_resTyper1))
                    preS_bodyr2 = [2]
                    preV_bodyr2 = [0, 4]
                    env_bodyr2 = map (delPathH ([],
                                                preV_bodyr2)) (filterEnv preV_bodyr2 env)
                    res_bodyr2 :: ( MethodBody )
                    res_bodyr2 = fromJust (fromDynamic (put osTy MethodBodyTag ListJCStatementTag osDyn (toDyn bodyr2) env_bodyr2))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS5 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCMethodDecl (JCMethodDecl (JJust mdfr0)
                                                                                                                                                                                methNamer1
                                                                                                                                                                                resTyper2
                                                                                                                                                                                (NNothing)
                                                                                                                                                                                bodyr3))) env = toDyn ((MethodDeclaration1 "DEF_VAL" res_mdfr0 (MethodHeader res_resTyper2 (MethodDeclarator0 res_methNamer1 "(" ")")) res_bodyr3) :: ClassMemberDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_methNamer1 = [2, 1, 0]
                    preV_methNamer1 = [0, 1]
                    env_methNamer1 = map (delPathH ([],
                                                    preV_methNamer1)) (filterEnv preV_methNamer1 env)
                    res_methNamer1 :: ( String )
                    res_methNamer1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn methNamer1) env_methNamer1))
                    preS_resTyper2 = [2, 0]
                    preV_resTyper2 = [0, 2]
                    env_resTyper2 = map (delPathH ([],
                                                   preV_resTyper2)) (filterEnv preV_resTyper2 env)
                    res_resTyper2 :: ( EEither UType String )
                    res_resTyper2 = fromJust (fromDynamic (put osTy EEitherUTypeStringTag JCExpressionTag osDyn (toDyn resTyper2) env_resTyper2))
                    preS_bodyr3 = [3]
                    preV_bodyr3 = [0, 4]
                    env_bodyr3 = map (delPathH ([],
                                                preV_bodyr3)) (filterEnv preV_bodyr3 env)
                    res_bodyr3 :: ( MethodBody )
                    res_bodyr3 = fromJust (fromDynamic (put osTy MethodBodyTag ListJCStatementTag osDyn (toDyn bodyr3) env_bodyr3))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS6 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCMethodDecl (JCMethodDecl (NNothing)
                                                                                                                                                                                methNamer0
                                                                                                                                                                                resTyper1
                                                                                                                                                                                (JJust argr2)
                                                                                                                                                                                bodyr3))) env = toDyn ((MethodDeclaration0 "DEF_VAL" (MethodHeader res_resTyper1 (MethodDeclarator1 res_methNamer0 "(" res_argr2 ")")) res_bodyr3) :: ClassMemberDeclaration)
              where preS_methNamer0 = [1, 1, 0]
                    preV_methNamer0 = [0, 1]
                    env_methNamer0 = map (delPathH ([],
                                                    preV_methNamer0)) (filterEnv preV_methNamer0 env)
                    res_methNamer0 :: ( String )
                    res_methNamer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn methNamer0) env_methNamer0))
                    preS_resTyper1 = [1, 0]
                    preV_resTyper1 = [0, 2]
                    env_resTyper1 = map (delPathH ([],
                                                   preV_resTyper1)) (filterEnv preV_resTyper1 env)
                    res_resTyper1 :: ( EEither UType String )
                    res_resTyper1 = fromJust (fromDynamic (put osTy EEitherUTypeStringTag JCExpressionTag osDyn (toDyn resTyper1) env_resTyper1))
                    preS_argr2 = [1, 1, 2]
                    preV_argr2 = [0, 3, 0]
                    env_argr2 = map (delPathH ([],
                                               preV_argr2)) (filterEnv preV_argr2 env)
                    res_argr2 :: ( Prod UType String )
                    res_argr2 = fromJust (fromDynamic (put osTy ProdUTypeStringTag JCVariableDeclTag osDyn (toDyn argr2) env_argr2))
                    preS_bodyr3 = [2]
                    preV_bodyr3 = [0, 4]
                    env_bodyr3 = map (delPathH ([],
                                                preV_bodyr3)) (filterEnv preV_bodyr3 env)
                    res_bodyr3 :: ( MethodBody )
                    res_bodyr3 = fromJust (fromDynamic (put osTy MethodBodyTag ListJCStatementTag osDyn (toDyn bodyr3) env_bodyr3))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS7 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just (FromJCMethodDecl (JCMethodDecl (JJust mdfr0)
                                                                                                                                                                                methNamer1
                                                                                                                                                                                resTyper2
                                                                                                                                                                                (JJust argr3)
                                                                                                                                                                                bodyr4))) env = toDyn ((MethodDeclaration1 "DEF_VAL" res_mdfr0 (MethodHeader res_resTyper2 (MethodDeclarator1 res_methNamer1 "(" res_argr3 ")")) res_bodyr4) :: ClassMemberDeclaration)
              where preS_mdfr0 = [1]
                    preV_mdfr0 = [0, 0, 0]
                    env_mdfr0 = map (delPathH ([],
                                               preV_mdfr0)) (filterEnv preV_mdfr0 env)
                    res_mdfr0 :: ( String )
                    res_mdfr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn mdfr0) env_mdfr0))
                    preS_methNamer1 = [2, 1, 0]
                    preV_methNamer1 = [0, 1]
                    env_methNamer1 = map (delPathH ([],
                                                    preV_methNamer1)) (filterEnv preV_methNamer1 env)
                    res_methNamer1 :: ( String )
                    res_methNamer1 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn methNamer1) env_methNamer1))
                    preS_resTyper2 = [2, 0]
                    preV_resTyper2 = [0, 2]
                    env_resTyper2 = map (delPathH ([],
                                                   preV_resTyper2)) (filterEnv preV_resTyper2 env)
                    res_resTyper2 :: ( EEither UType String )
                    res_resTyper2 = fromJust (fromDynamic (put osTy EEitherUTypeStringTag JCExpressionTag osDyn (toDyn resTyper2) env_resTyper2))
                    preS_argr3 = [2, 1, 2]
                    preV_argr3 = [0, 3, 0]
                    env_argr3 = map (delPathH ([],
                                               preV_argr3)) (filterEnv preV_argr3 env)
                    res_argr3 :: ( Prod UType String )
                    res_argr3 = fromJust (fromDynamic (put osTy ProdUTypeStringTag JCVariableDeclTag osDyn (toDyn argr3) env_argr3))
                    preS_bodyr4 = [3]
                    preV_bodyr4 = [0, 4]
                    env_bodyr4 = map (delPathH ([],
                                                preV_bodyr4)) (filterEnv preV_bodyr4 env)
                    res_bodyr4 :: ( MethodBody )
                    res_bodyr4 = fromJust (fromDynamic (put osTy MethodBodyTag ListJCStatementTag osDyn (toDyn bodyr4) env_bodyr4))
putNoLink osTy (ClassMemberDeclarationTag) (JCTreeTag) ClassMemberDeclarationJCTreeS8 osDyn ((fromDynamic :: Dynamic -> Maybe (JCTree)) -> Just classDecr0) env = toDyn ((MemberFromClassDeclaration res_classDecr0) :: ClassMemberDeclaration)
              where preS_classDecr0 = [0]
                    preV_classDecr0 = []
                    env_classDecr0 = map (delPathH ([],
                                                    preV_classDecr0)) (filterEnv preV_classDecr0 env)
                    res_classDecr0 :: ( ClassDeclaration )
                    res_classDecr0 = fromJust (fromDynamic (put osTy ClassDeclarationTag JCTreeTag osDyn (toDyn classDecr0) env_classDecr0))

putNoLink osTy (ProdUTypeStringTag) (JCVariableDeclTag) ProdUTypeStringJCVariableDeclS0 osDyn ((fromDynamic :: Dynamic -> Maybe (JCVariableDecl)) -> Just (JCVariableDecl (NNothing)
                                                                                                                                                                          namer0
                                                                                                                                                                          (JCPrimitiveTypeTree tyr1)
                                                                                                                                                                          (NNothing))) env = toDyn ((Prod res_tyr1 res_namer0) :: ( Prod UType String ))
              where preS_namer0 = [1]
                    preV_namer0 = [1]
                    env_namer0 = map (delPathH ([],
                                                preV_namer0)) (filterEnv preV_namer0 env)
                    res_namer0 :: ( String )
                    res_namer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn namer0) env_namer0))
                    preS_tyr1 = [0]
                    preV_tyr1 = [2, 0]
                    env_tyr1 = map (delPathH ([], preV_tyr1)) (filterEnv preV_tyr1 env)
                    res_tyr1 :: ( UType )
                    res_tyr1 = fromJust (fromDynamic (put osTy UTypeTag UTypeTag osDyn (toDyn tyr1) env_tyr1))

putNoLink osTy (ListExpressionTag) (ListJCExpressionTag) ListExpressionListJCExpressionS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCExpression)) -> Just (Nil)) env = toDyn ((Nil) :: ( List Expression ))
putNoLink osTy (ListExpressionTag) (ListJCExpressionTag) ListExpressionListJCExpressionS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCExpression)) -> Just (Cons er0
                                                                                                                                                                     esr1)) env = toDyn ((Cons res_er0 res_esr1) :: ( List Expression ))
              where preS_er0 = [0]
                    preV_er0 = [0]
                    env_er0 = map (delPathH ([], preV_er0)) (filterEnv preV_er0 env)
                    res_er0 :: ( Expression )
                    res_er0 = fromJust (fromDynamic (put osTy ExpressionTag JCExpressionTag osDyn (toDyn er0) env_er0))
                    preS_esr1 = [1]
                    preV_esr1 = [1]
                    env_esr1 = map (delPathH ([], preV_esr1)) (filterEnv preV_esr1 env)
                    res_esr1 :: ( List Expression )
                    res_esr1 = fromJust (fromDynamic (put osTy ListExpressionTag ListJCExpressionTag osDyn (toDyn esr1) env_esr1))

putNoLink osTy (MethodBodyTag) (ListJCStatementTag) MethodBodyListJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just stmtsr0) env = toDyn ((MethodBody0 res_stmtsr0) :: MethodBody)
              where preS_stmtsr0 = [0]
                    preV_stmtsr0 = []
                    env_stmtsr0 = map (delPathH ([],
                                                 preV_stmtsr0)) (filterEnv preV_stmtsr0 env)
                    res_stmtsr0 :: ( List BlockStatement )
                    res_stmtsr0 = fromJust (fromDynamic (put osTy ListBlockStatementTag ListJCStatementTag osDyn (toDyn stmtsr0) env_stmtsr0))
putNoLink osTy (MethodBodyTag) (ListJCStatementTag) MethodBodyListJCStatementS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just (Cons (JCSkip)
                                                                                                                                                          (Nil))) env = toDyn ((MethodBody1 ";") :: MethodBody)

putNoLink osTy (StatementTag) (ListJCStatementTag) StatementListJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just blockr0) env = toDyn ((FromBlockStatement res_blockr0) :: Statement)
              where preS_blockr0 = [0]
                    preV_blockr0 = []
                    env_blockr0 = map (delPathH ([],
                                                 preV_blockr0)) (filterEnv preV_blockr0 env)
                    res_blockr0 :: ( List BlockStatement )
                    res_blockr0 = fromJust (fromDynamic (put osTy ListBlockStatementTag ListJCStatementTag osDyn (toDyn blockr0) env_blockr0))

putNoLink osTy (ListBlockStatementTag) (ListJCStatementTag) ListBlockStatementListJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just (Nil)) env = toDyn ((Nil) :: ( List BlockStatement ))
putNoLink osTy (ListBlockStatementTag) (ListJCStatementTag) ListBlockStatementListJCStatementS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just (Cons ar0
                                                                                                                                                                          asr1)) env = toDyn ((Cons res_ar0 res_asr1) :: ( List BlockStatement ))
              where preS_ar0 = [0]
                    preV_ar0 = [0]
                    env_ar0 = map (delPathH ([], preV_ar0)) (filterEnv preV_ar0 env)
                    res_ar0 :: ( BlockStatement )
                    res_ar0 = fromJust (fromDynamic (put osTy BlockStatementTag JCStatementTag osDyn (toDyn ar0) env_ar0))
                    preS_asr1 = [1]
                    preV_asr1 = [1]
                    env_asr1 = map (delPathH ([], preV_asr1)) (filterEnv preV_asr1 env)
                    res_asr1 :: ( List BlockStatement )
                    res_asr1 = fromJust (fromDynamic (put osTy ListBlockStatementTag ListJCStatementTag osDyn (toDyn asr1) env_asr1))

putNoLink osTy (ListAssignmentTag) (ListJCStatementTag) ListAssignmentListJCStatementS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just (Nil)) env = toDyn ((Nil) :: ( List Assignment ))
putNoLink osTy (ListAssignmentTag) (ListJCStatementTag) ListAssignmentListJCStatementS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCStatement)) -> Just (Cons assr0
                                                                                                                                                                  asssr1)) env = toDyn ((Cons res_assr0 res_asssr1) :: ( List Assignment ))
              where preS_assr0 = [0]
                    preV_assr0 = [0]
                    env_assr0 = map (delPathH ([],
                                               preV_assr0)) (filterEnv preV_assr0 env)
                    res_assr0 :: ( Assignment )
                    res_assr0 = fromJust (fromDynamic (put osTy AssignmentTag JCStatementTag osDyn (toDyn assr0) env_assr0))
                    preS_asssr1 = [1]
                    preV_asssr1 = [1]
                    env_asssr1 = map (delPathH ([],
                                                preV_asssr1)) (filterEnv preV_asssr1 env)
                    res_asssr1 :: ( List Assignment )
                    res_asssr1 = fromJust (fromDynamic (put osTy ListAssignmentTag ListJCStatementTag osDyn (toDyn asssr1) env_asssr1))

putNoLink osTy (ClassBodyTag) (ListJCTreeTag) ClassBodyListJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCTree)) -> Just (Nil)) env = toDyn ((ClassBody0 "{" "}") :: ClassBody)
putNoLink osTy (ClassBodyTag) (ListJCTreeTag) ClassBodyListJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCTree)) -> Just decsr0) env = toDyn ((ClassBody1 "{" res_decsr0 "}") :: ClassBody)
              where preS_decsr0 = [1]
                    preV_decsr0 = []
                    env_decsr0 = map (delPathH ([],
                                                preV_decsr0)) (filterEnv preV_decsr0 env)
                    res_decsr0 :: ( List ClassBodyDeclaration )
                    res_decsr0 = fromJust (fromDynamic (put osTy ListClassBodyDeclarationTag ListJCTreeTag osDyn (toDyn decsr0) env_decsr0))

putNoLink osTy (ListTypeDeclarationTag) (ListJCTreeTag) ListTypeDeclarationListJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCTree)) -> Just (Cons tDecr0
                                                                                                                                                             tDecsr1)) env = toDyn ((Cons res_tDecr0 res_tDecsr1) :: ( List TypeDeclaration ))
              where preS_tDecr0 = [0]
                    preV_tDecr0 = [0]
                    env_tDecr0 = map (delPathH ([],
                                                preV_tDecr0)) (filterEnv preV_tDecr0 env)
                    res_tDecr0 :: ( TypeDeclaration )
                    res_tDecr0 = fromJust (fromDynamic (put osTy TypeDeclarationTag JCTreeTag osDyn (toDyn tDecr0) env_tDecr0))
                    preS_tDecsr1 = [1]
                    preV_tDecsr1 = [1]
                    env_tDecsr1 = map (delPathH ([],
                                                 preV_tDecsr1)) (filterEnv preV_tDecsr1 env)
                    res_tDecsr1 :: ( List TypeDeclaration )
                    res_tDecsr1 = fromJust (fromDynamic (put osTy ListTypeDeclarationTag ListJCTreeTag osDyn (toDyn tDecsr1) env_tDecsr1))
putNoLink osTy (ListTypeDeclarationTag) (ListJCTreeTag) ListTypeDeclarationListJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCTree)) -> Just (Nil)) env = toDyn ((Nil) :: ( List TypeDeclaration ))

putNoLink osTy (ListClassBodyDeclarationTag) (ListJCTreeTag) ListClassBodyDeclarationListJCTreeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCTree)) -> Just (Nil)) env = toDyn ((Nil) :: ( List ClassBodyDeclaration ))
putNoLink osTy (ListClassBodyDeclarationTag) (ListJCTreeTag) ListClassBodyDeclarationListJCTreeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List JCTree)) -> Just (Cons ar0
                                                                                                                                                                       asr1)) env = toDyn ((Cons res_ar0 res_asr1) :: ( List ClassBodyDeclaration ))
              where preS_ar0 = [0]
                    preV_ar0 = [0]
                    env_ar0 = map (delPathH ([], preV_ar0)) (filterEnv preV_ar0 env)
                    res_ar0 :: ( ClassBodyDeclaration )
                    res_ar0 = fromJust (fromDynamic (put osTy ClassBodyDeclarationTag JCTreeTag osDyn (toDyn ar0) env_ar0))
                    preS_asr1 = [1]
                    preV_asr1 = [1]
                    env_asr1 = map (delPathH ([], preV_asr1)) (filterEnv preV_asr1 env)
                    res_asr1 :: ( List ClassBodyDeclaration )
                    res_asr1 = fromJust (fromDynamic (put osTy ListClassBodyDeclarationTag ListJCTreeTag osDyn (toDyn asr1) env_asr1))

putNoLink osTy (ULitTag) (ULitTag) ULitULitS0 osDyn ((fromDynamic :: Dynamic -> Maybe (ULit)) -> Just (UIntegerLit ir0)) env = toDyn ((UIntegerLit res_ir0) :: ULit)
              where preS_ir0 = [0]
                    preV_ir0 = [0]
                    env_ir0 = map (delPathH ([], preV_ir0)) (filterEnv preV_ir0 env)
                    res_ir0 :: ( Integer )
                    res_ir0 = fromJust (fromDynamic (put osTy IntegerTag IntegerTag osDyn (toDyn ir0) env_ir0))
putNoLink osTy (ULitTag) (ULitTag) ULitULitS1 osDyn ((fromDynamic :: Dynamic -> Maybe (ULit)) -> Just (UStringLit sr0)) env = toDyn ((UStringLit res_sr0) :: ULit)
              where preS_sr0 = [0]
                    preV_sr0 = [0]
                    env_sr0 = map (delPathH ([], preV_sr0)) (filterEnv preV_sr0 env)
                    res_sr0 :: ( String )
                    res_sr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn sr0) env_sr0))
putNoLink osTy (ULitTag) (ULitTag) ULitULitS2 osDyn ((fromDynamic :: Dynamic -> Maybe (ULit)) -> Just (UBoolLit br0)) env = toDyn ((UBoolLit res_br0) :: ULit)
              where preS_br0 = [0]
                    preV_br0 = [0]
                    env_br0 = map (delPathH ([], preV_br0)) (filterEnv preV_br0 env)
                    res_br0 :: ( Bool )
                    res_br0 = fromJust (fromDynamic (put osTy BoolTag BoolTag osDyn (toDyn br0) env_br0))

putNoLink osTy (UTypeTag) (UTypeTag) UTypeUTypeS0 osDyn ((fromDynamic :: Dynamic -> Maybe (UType)) -> Just (UInteger)) env = toDyn ((UInteger) :: UType)
putNoLink osTy (UTypeTag) (UTypeTag) UTypeUTypeS1 osDyn ((fromDynamic :: Dynamic -> Maybe (UType)) -> Just (UString)) env = toDyn ((UString) :: UType)
putNoLink osTy (UTypeTag) (UTypeTag) UTypeUTypeS2 osDyn ((fromDynamic :: Dynamic -> Maybe (UType)) -> Just (UBool)) env = toDyn ((UBool) :: UType)
putNoLink osTy (UTypeTag) (UTypeTag) UTypeUTypeS3 osDyn ((fromDynamic :: Dynamic -> Maybe (UType)) -> Just (UVoid)) env = toDyn ((UVoid) :: UType)

putWithLinks :: OSTyTag ->
                STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

putWithLinks osTy sTy vTy osDyn vDyn env = s4
                 where (maybeL, imags, env') = getTopLinks env
                       s2 = case maybeL of
                                Just l -> let {((sReg, sPath), (_, [])) = l;
                                               s0 = fetch' osTy osDyn l;
                                               s1 = putNoLink osTy (askDynTyTag s0) vTy sReg osDyn vDyn env'}
                                           in (repSubtree sReg s0 s1)
                                Nothing -> putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env'
                       s3 = foldr (splice osDyn) s2 imags
                       s4 = mkInj (askDynTyTag s3) sTy s3

topPut :: OSTyTag -> STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

topPut osTy sTy vTy osDyn vDyn hls = put osTy sTy vTy osDyn vDyn hls

