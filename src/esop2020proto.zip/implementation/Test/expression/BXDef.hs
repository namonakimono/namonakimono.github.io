{-# LANGUAGE DeriveDataTypeable, TypeSynonymInstances, FlexibleInstances, MultiParamTypeClasses, ViewPatterns #-}

module BXDef where

import Prelude hiding (putChar)
import Data.Data
import Data.Generics hiding (GT)
import Data.Dynamic
import Data.List (partition, sortBy, nub)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Maybe (catMaybes, isJust, fromJust)

type Region = (RegPat, Path)
type RLink = (Region, Region)
type HLink = RLink

type VLink = (Path,RegPat,Path)
type VCorr = VLink

type OSDyn = Dynamic
type SDyn  = Dynamic
type VDyn  = Dynamic

type OSTyTag = TyTag
type STyTag  = TyTag
type VTyTag  = TyTag
type SupTyTag = TyTag
type SubTyTag = TyTag

type Path = [Integer]
type Env = [RLink]
type RLinks = [RLink]

-- functions handling paths and steps.

-- compose a HLink and a VLink
compHV :: RLink -> VCorr -> Maybe RLink
compHV ((hRegL,hPathL),(hRegR,hPathR)) (vPathU,vReg,vPathB)
  | hPathR == vPathU && hRegR == vReg = Just ((hRegL,hPathL),(hRegR,vPathB))
compHV _ _ = Nothing

-- compose [VCorr] and [RLink]
compHVs :: [RLink] -> [VCorr] -> [RLink]
compHVs hls vls = nub $ catMaybes [hl `compHV` vl | hl <- hls, vl <- vls]

filterEnv :: Path -> [RLink] -> [RLink]
filterEnv s = filter (\ (_ , (_,p)) -> isPrefix s p)

filterVLinkS :: Path -> [VCorr] -> [VCorr]
filterVLinkS p0 = filter (\ (p, _, _) -> isPrefix p0 p)

filterVLinkE :: Path -> [VCorr] -> [VCorr]
filterVLinkE p0 = filter (\ (_, _, p) -> isPrefix p0 p)

isPrefix :: Path -> Path -> Bool
isPrefix [] _ = True
isPrefix (s1:ss1) (s2:ss2) | s1 /= s2 = False
isPrefix (s1:ss1) (s2:ss2) | s1 == s2 = isPrefix ss1 ss2
isPrefix _ _ = False

-- delete the given prefix path from all links
delPathH :: (Path,Path) -> RLink -> RLink
delPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) =
  ((sReg,delPrefix sPre sp) , (vReg,delPrefix vPre vp))

delPrefix :: Path -> Path -> Path
delPrefix [] p = p
delPrefix s1 s2 = if isPrefix s1 s2 then drop (length s1) s2
  else error $ "the first input path is not a prefix of the second \n" ++
               "input path1: " ++ show s1 ++ "\n" ++ "input path2: " ++ show s2

addPathV :: (Path,Path) -> VLink -> VLink
addPathV (sPre1,sPre2) (sp1,sPat,sp2) = (sPre1 ++ sp1,sPat,sPre2 ++ sp2)

addPathH :: (Path,Path) -> RLink -> RLink
addPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) = ((sReg,sPre ++ sp) , (vReg,vPre ++ vp))

hasTopLink :: [RLink] -> Bool
hasTopLink = ([] `elem`) . map (snd . snd)

-- get links with empty view paths (link at the top)
-- return a Maybe real-link, a list of imaginary links (may be empty list), and remainings
-- to do so, we first sort the HLinks in the following order:
-- (3) : the links whose view-paths are empty come first
-- (2) : among (3), whose view-patterns is Void come first.
-- (1) : among (2), whose source-paths are smaller come first.
getTopLinks :: [RLink] -> (Maybe RLink, [RLink], [RLink])
getTopLinks hls =
  let (candidates3,rem3) = partition (\ (_,(_,vpath)) -> null vpath) hls
      -- rem2 should be either empty or singleton
      (candidates2,rem2) = partition (\ (_,(vRegion,_)) -> vRegion == Void) candidates3 
      candidates1 = sortBy cmpSPathRL candidates2
  in  case rem2 of
        []  -> (Nothing, candidates1, rem3)
        [r] -> (Just r, candidates1, rem3)

cmpSPathRL :: RLink -> RLink -> Ordering
cmpSPathRL ((_,sp1),_) ((_,sp2),_) = if sp1 < sp2 then LT
  else if sp1 == sp2 then EQ else GT

-- build vertical correspondence between an AST and itself, according to the given consitency links
-- do not use nub. nub will remove usefull links having the void region.
buildIdVCorr :: [RLink] -> [VCorr]
buildIdVCorr consisHLS = [(path2,pat2,path2) | ((pat1,path1) , (pat2,path2)) <- consisHLS]

apFst f (x,y) = (f x , y)


data Arith =
    Add Arith Arith
  | Sub Arith Arith
  | Mul Arith Arith
  | Div Arith Arith
  | Num Integer
  | ArithNull
  deriving (Show, Read, Eq, Data, Typeable)

data Expr =
    Plus String Expr Term
  | Minus String Expr Term
  | FromT String Term
  | ExprNull
  deriving (Show, Read, Eq, Data, Typeable)

data Term =
    Times String Term Factor
  | Division String Term Factor
  | FromF String Factor
  | TermNull
  deriving (Show, Read, Eq, Data, Typeable)

data Factor =
    Neg String Factor
  | Lit String Integer
  | Paren String Expr
  | FactorNull
  deriving (Show, Read, Eq, Data, Typeable)

data TyTag
    = ArithTag
    | ExprTag
    | TermTag
    | FactorTag
    | IntegerTag
    | StringTag
    | CharTag
    | BoolTag
    deriving (Eq, Show)

class TypeTag a
    where tyTag :: a -> TyTag

instance TypeTag Integer
    where tyTag _ = IntegerTag
instance TypeTag String
    where tyTag _ = StringTag
instance TypeTag Char
    where tyTag _ = CharTag
instance TypeTag Bool
    where tyTag _ = BoolTag
instance TypeTag Arith
    where tyTag ArithNull = ArithTag
          tyTag (Add _ _) = ArithTag
          tyTag (Sub _ _) = ArithTag
          tyTag (Mul _ _) = ArithTag
          tyTag (Div _ _) = ArithTag
          tyTag (Num _) = ArithTag
instance TypeTag Expr
    where tyTag ExprNull = ExprTag
          tyTag (Plus _ _ _) = ExprTag
          tyTag (Minus _ _ _) = ExprTag
          tyTag (FromT _ _) = ExprTag
instance TypeTag Term
    where tyTag TermNull = TermTag
          tyTag (Times _ _ _) = TermTag
          tyTag (Division _ _ _) = TermTag
          tyTag (FromF _ _) = TermTag
instance TypeTag Factor
    where tyTag FactorNull = FactorTag
          tyTag (Neg _ _) = FactorTag
          tyTag (Lit _ _) = FactorTag
          tyTag (Paren _ _) = FactorTag

class Fetchable a
    where fetch :: Path -> a -> Dynamic

instance Fetchable Integer
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Integer"
instance Fetchable String
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a String"
instance Fetchable Char
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Char"
instance Fetchable Bool
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Bool"
instance Fetchable Arith
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Add t0 _ , (0)) -> fetch ps t0
                                   (Add _ t1 , (1)) -> fetch ps t1
                                   (Sub t0 _ , (0)) -> fetch ps t0
                                   (Sub _ t1 , (1)) -> fetch ps t1
                                   (Mul t0 _ , (0)) -> fetch ps t0
                                   (Mul _ t1 , (1)) -> fetch ps t1
                                   (Div t0 _ , (0)) -> fetch ps t0
                                   (Div _ t1 , (1)) -> fetch ps t1
                                   (Num t0 , (0)) -> fetch ps t0
instance Fetchable Expr
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Plus t0 _ _ , (0)) -> fetch ps t0
                                   (Plus _ t1 _ , (1)) -> fetch ps t1
                                   (Plus _ _ t2 , (2)) -> fetch ps t2
                                   (Minus t0 _ _ , (0)) -> fetch ps t0
                                   (Minus _ t1 _ , (1)) -> fetch ps t1
                                   (Minus _ _ t2 , (2)) -> fetch ps t2
                                   (FromT t0 _ , (0)) -> fetch ps t0
                                   (FromT _ t1 , (1)) -> fetch ps t1
instance Fetchable Term
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Times t0 _ _ , (0)) -> fetch ps t0
                                   (Times _ t1 _ , (1)) -> fetch ps t1
                                   (Times _ _ t2 , (2)) -> fetch ps t2
                                   (Division t0 _ _ , (0)) -> fetch ps t0
                                   (Division _ t1 _ , (1)) -> fetch ps t1
                                   (Division _ _ t2 , (2)) -> fetch ps t2
                                   (FromF t0 _ , (0)) -> fetch ps t0
                                   (FromF _ t1 , (1)) -> fetch ps t1
instance Fetchable Factor
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Neg t0 _ , (0)) -> fetch ps t0
                                   (Neg _ t1 , (1)) -> fetch ps t1
                                   (Lit t0 _ , (0)) -> fetch ps t0
                                   (Lit _ t1 , (1)) -> fetch ps t1
                                   (Paren t0 _ , (0)) -> fetch ps t0
                                   (Paren _ t1 , (1)) -> fetch ps t1

fetch' :: OSTyTag -> OSDyn -> RLink -> SDyn
fetch' ExprTag ((fromDynamic :: Dynamic ->
                                Maybe Expr) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' ArithTag ((fromDynamic :: Dynamic ->
                                 Maybe Arith) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                               in fetch sPath os
fetch' TermTag ((fromDynamic :: Dynamic ->
                                Maybe Term) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' FactorTag ((fromDynamic :: Dynamic ->
                                  Maybe Factor) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' IntegerTag ((fromDynamic :: Dynamic ->
                                   Maybe Integer) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                   in fetch sPath os
fetch' StringTag ((fromDynamic :: Dynamic ->
                                  Maybe String) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' CharTag ((fromDynamic :: Dynamic ->
                                Maybe Char) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' BoolTag ((fromDynamic :: Dynamic ->
                                Maybe Bool) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os

class Insertable a
    where ins :: (a, Path) -> (TyTag, Dynamic) -> a

instance Insertable Integer
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable String
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Char
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Bool
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Arith
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Add theHole t1 ,
                                               (0)) -> Add ( fromDyn subT theHole ) t1 
                                              (Add t0 theHole ,
                                               (1)) -> Add t0 ( fromDyn subT theHole ) 
                                              (Sub theHole t1 ,
                                               (0)) -> Sub ( fromDyn subT theHole ) t1 
                                              (Sub t0 theHole ,
                                               (1)) -> Sub t0 ( fromDyn subT theHole ) 
                                              (Mul theHole t1 ,
                                               (0)) -> Mul ( fromDyn subT theHole ) t1 
                                              (Mul t0 theHole ,
                                               (1)) -> Mul t0 ( fromDyn subT theHole ) 
                                              (Div theHole t1 ,
                                               (0)) -> Div ( fromDyn subT theHole ) t1 
                                              (Div t0 theHole ,
                                               (1)) -> Div t0 ( fromDyn subT theHole ) 
                                              (Num theHole , (0)) -> Num ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Add theHole t1 ,
                                                (0)) -> Add ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Add t0 theHole ,
                                                (1)) -> Add t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Sub theHole t1 ,
                                                (0)) -> Sub ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Sub t0 theHole ,
                                                (1)) -> Sub t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Mul theHole t1 ,
                                                (0)) -> Mul ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Mul t0 theHole ,
                                                (1)) -> Mul t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Div theHole t1 ,
                                                (0)) -> Div ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Div t0 theHole ,
                                                (1)) -> Div t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Num theHole ,
                                                (0)) -> Num ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Expr
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Plus theHole t1 t2 ,
                                               (0)) -> Plus ( fromDyn subT theHole ) t1 t2 
                                              (Plus t0 theHole t2 ,
                                               (1)) -> Plus t0 ( fromDyn subT theHole ) t2 
                                              (Plus t0 t1 theHole ,
                                               (2)) -> Plus t0 t1 ( fromDyn subT theHole ) 
                                              (Minus theHole t1 t2 ,
                                               (0)) -> Minus ( fromDyn subT theHole ) t1 t2 
                                              (Minus t0 theHole t2 ,
                                               (1)) -> Minus t0 ( fromDyn subT theHole ) t2 
                                              (Minus t0 t1 theHole ,
                                               (2)) -> Minus t0 t1 ( fromDyn subT theHole ) 
                                              (FromT theHole t1 ,
                                               (0)) -> FromT ( fromDyn subT theHole ) t1 
                                              (FromT t0 theHole ,
                                               (1)) -> FromT t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Plus theHole t1 t2 ,
                                                (0)) -> Plus ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Plus t0 theHole t2 ,
                                                (1)) -> Plus t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Plus t0 t1 theHole ,
                                                (2)) -> Plus t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Minus theHole t1 t2 ,
                                                (0)) -> Minus ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Minus t0 theHole t2 ,
                                                (1)) -> Minus t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Minus t0 t1 theHole ,
                                                (2)) -> Minus t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromT theHole t1 ,
                                                (0)) -> FromT ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (FromT t0 theHole ,
                                                (1)) -> FromT t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Term
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Times theHole t1 t2 ,
                                               (0)) -> Times ( fromDyn subT theHole ) t1 t2 
                                              (Times t0 theHole t2 ,
                                               (1)) -> Times t0 ( fromDyn subT theHole ) t2 
                                              (Times t0 t1 theHole ,
                                               (2)) -> Times t0 t1 ( fromDyn subT theHole ) 
                                              (Division theHole t1 t2 ,
                                               (0)) -> Division ( fromDyn subT theHole ) t1 t2 
                                              (Division t0 theHole t2 ,
                                               (1)) -> Division t0 ( fromDyn subT theHole ) t2 
                                              (Division t0 t1 theHole ,
                                               (2)) -> Division t0 t1 ( fromDyn subT theHole ) 
                                              (FromF theHole t1 ,
                                               (0)) -> FromF ( fromDyn subT theHole ) t1 
                                              (FromF t0 theHole ,
                                               (1)) -> FromF t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Times theHole t1 t2 ,
                                                (0)) -> Times ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Times t0 theHole t2 ,
                                                (1)) -> Times t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Times t0 t1 theHole ,
                                                (2)) -> Times t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Division theHole t1 t2 ,
                                                (0)) -> Division ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Division t0 theHole t2 ,
                                                (1)) -> Division t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Division t0 t1 theHole ,
                                                (2)) -> Division t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (FromF theHole t1 ,
                                                (0)) -> FromF ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (FromF t0 theHole ,
                                                (1)) -> FromF t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Factor
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Neg theHole t1 ,
                                               (0)) -> Neg ( fromDyn subT theHole ) t1 
                                              (Neg t0 theHole ,
                                               (1)) -> Neg t0 ( fromDyn subT theHole ) 
                                              (Lit theHole t1 ,
                                               (0)) -> Lit ( fromDyn subT theHole ) t1 
                                              (Lit t0 theHole ,
                                               (1)) -> Lit t0 ( fromDyn subT theHole ) 
                                              (Paren theHole t1 ,
                                               (0)) -> Paren ( fromDyn subT theHole ) t1 
                                              (Paren t0 theHole ,
                                               (1)) -> Paren t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Neg theHole t1 ,
                                                (0)) -> Neg ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Neg t0 theHole ,
                                                (1)) -> Neg t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Lit theHole t1 ,
                                                (0)) -> Lit ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Lit t0 theHole ,
                                                (1)) -> Lit t0 ( ins (theHole,ps) (tySubT,subT) ) 
                                               (Paren theHole t1 ,
                                                (0)) -> Paren ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Paren t0 theHole ,
                                                (1)) -> Paren t0 ( ins (theHole,ps) (tySubT,subT) ) 

class HasDefVal a
    where defVal :: TyTag -> a

instance HasDefVal Arith
    where defVal ArithTag = ArithNull
instance HasDefVal Expr
    where defVal ExprTag = ExprNull
instance HasDefVal Term
    where defVal TermTag = TermNull
instance HasDefVal Factor
    where defVal FactorTag = FactorNull
instance HasDefVal Integer
    where defVal IntegerTag = 0
instance HasDefVal String
    where defVal StringTag = "DEF_VAL"
instance HasDefVal Char
    where defVal CharTag = 'X'
instance HasDefVal Bool
    where defVal BoolTag = False

class NodeAndPath a
    where nodeAndPath :: a -> [(Dynamic, Path)]

instance NodeAndPath Integer
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath String
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Char
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Bool
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Arith
    where nodeAndPath (t@(Add t0
                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(Sub t0
                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(Mul t0
                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(Div t0
                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(Num t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath Expr
    where nodeAndPath (t@(Plus t0
                               t1
                               t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(Minus t0
                                t1
                                t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(FromT t0
                                t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath Term
    where nodeAndPath (t@(Times t0
                                t1
                                t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(Division t0
                                   t1
                                   t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
          nodeAndPath (t@(FromF t0
                                t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath Factor
    where nodeAndPath (t@(Neg t0
                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(Lit t0
                              t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
          nodeAndPath (t@(Paren t0
                                t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)

class IntConv sub sup
    where inj :: sub -> sup
instance IntConv Expr Term
    where inj el = FromF "DEF_VAL" (Paren "DEF_VAL" el)
instance IntConv Factor Expr
    where inj fl = FromT "DEF_VAL" (FromF "DEF_VAL" fl)
instance IntConv Term Factor
    where inj tl = Paren "DEF_VAL" (FromT "DEF_VAL" tl)
instance IntConv Term Expr
    where inj t = FromT "XT" t
instance IntConv Factor Term
    where inj f = FromF "XF" f
instance IntConv Expr Factor
    where inj e = Paren "XP" e
mkInj :: SubTyTag -> SupTyTag -> Dynamic -> Dynamic
mkInj (ExprTag) (TermTag) s0 | isJust (fromDynamic s0 :: Maybe Expr) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Expr)) :: Term
mkInj (FactorTag) (ExprTag) s0 | isJust (fromDynamic s0 :: Maybe Factor) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Factor)) :: Expr
mkInj (TermTag) (FactorTag) s0 | isJust (fromDynamic s0 :: Maybe Term) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Term)) :: Factor
mkInj (TermTag) (ExprTag) s0 | isJust (fromDynamic s0 :: Maybe Term) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Term)) :: Expr
mkInj (FactorTag) (TermTag) s0 | isJust (fromDynamic s0 :: Maybe Factor) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Factor)) :: Term
mkInj (ExprTag) (FactorTag) s0 | isJust (fromDynamic s0 :: Maybe Expr) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe Expr)) :: Factor
mkInj a b c | a == b = c

selSPat :: TyTag -> TyTag -> Dynamic -> RegPat
selSPat (ExprTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just (Add xr0
                                                                                   yr1)) = ExprArithS0
selSPat (ExprTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just (Sub xr0
                                                                                   yr1)) = ExprArithS1
selSPat (ExprTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just tr0) = ExprArithS2
selSPat (TermTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just (Mul xr0
                                                                                   yr1)) = TermArithS0
selSPat (TermTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just (Div xr0
                                                                                   yr1)) = TermArithS1
selSPat (TermTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just fr0) = TermArithS2
selSPat (FactorTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just (Sub (Num 0)
                                                                                     xr0)) = FactorArithS0
selSPat (FactorTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just (Num ir0)) = FactorArithS1
selSPat (FactorTag) (ArithTag) ((fromDynamic :: Dynamic -> Maybe Arith) -> Just er0) = FactorArithS2
selSPat (IntegerTag) (IntegerTag) ((fromDynamic :: Dynamic -> Maybe Integer) -> Just prim) = IntegerR
selSPat (StringTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just prim) = StringR
selSPat (CharTag) (CharTag) ((fromDynamic :: Dynamic -> Maybe Char) -> Just prim) = CharR
selSPat (BoolTag) (BoolTag) ((fromDynamic :: Dynamic -> Maybe Bool) -> Just prim) = BoolR
selSPat x y z = (error $ "panic. source tag: " ++ show x ++ "\nview tag " ++ show y ++ "\nnot found!\n" ++ show z)

askDynTyTag :: Dynamic -> TyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Arith) -> Just _) = ArithTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Expr) -> Just _) = ExprTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Term) -> Just _) = TermTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Factor) -> Just _) = FactorTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Integer) -> Just _) = IntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe String) -> Just _) = StringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Char) -> Just _) = CharTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Bool) -> Just _) = BoolTag

splice :: OSDyn -> RLink -> SDyn -> SDyn
splice osDyn imag s0 = insSubtree sReg (fetch' (askDynTyTag osDyn) osDyn imag) s0
  where
    ((sReg,_),(Void,[])) = imag

repSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
repSubtree ExprArithS0 ((fromDynamic :: Dynamic -> Maybe Expr) -> Just (Plus fromWild0fromWild0
                                                                             lxl0
                                                                             lyl1)) ((fromDynamic :: Dynamic -> Maybe Expr) -> Just (Plus _
                                                                                                                                          rxl0
                                                                                                                                          ryl1)) = toDyn (Plus fromWild0fromWild0 rxl0 ryl1 :: Expr)
repSubtree ExprArithS1 ((fromDynamic :: Dynamic -> Maybe Expr) -> Just (Minus fromWild0fromWild0
                                                                              lxl0
                                                                              lyl1)) ((fromDynamic :: Dynamic -> Maybe Expr) -> Just (Minus _
                                                                                                                                            rxl0
                                                                                                                                            ryl1)) = toDyn (Minus fromWild0fromWild0 rxl0 ryl1 :: Expr)
repSubtree ExprArithS2 ((fromDynamic :: Dynamic -> Maybe Expr) -> Just (FromT fromWild0fromWild0
                                                                              ltl0)) ((fromDynamic :: Dynamic -> Maybe Expr) -> Just (FromT _
                                                                                                                                            rtl0)) = toDyn (FromT fromWild0fromWild0 rtl0 :: Expr)
repSubtree TermArithS0 ((fromDynamic :: Dynamic -> Maybe Term) -> Just (Times fromWild0fromWild0
                                                                              lxl0
                                                                              lyl1)) ((fromDynamic :: Dynamic -> Maybe Term) -> Just (Times _
                                                                                                                                            rxl0
                                                                                                                                            ryl1)) = toDyn (Times fromWild0fromWild0 rxl0 ryl1 :: Term)
repSubtree TermArithS1 ((fromDynamic :: Dynamic -> Maybe Term) -> Just (Division fromWild0fromWild0
                                                                                 lxl0
                                                                                 lyl1)) ((fromDynamic :: Dynamic -> Maybe Term) -> Just (Division _
                                                                                                                                                  rxl0
                                                                                                                                                  ryl1)) = toDyn (Division fromWild0fromWild0 rxl0 ryl1 :: Term)
repSubtree TermArithS2 ((fromDynamic :: Dynamic -> Maybe Term) -> Just (FromF fromWild0fromWild0
                                                                              lfl0)) ((fromDynamic :: Dynamic -> Maybe Term) -> Just (FromF _
                                                                                                                                            rfl0)) = toDyn (FromF fromWild0fromWild0 rfl0 :: Term)
repSubtree FactorArithS0 ((fromDynamic :: Dynamic -> Maybe Factor) -> Just (Neg fromWild0fromWild0
                                                                                lxl0)) ((fromDynamic :: Dynamic -> Maybe Factor) -> Just (Neg _
                                                                                                                                              rxl0)) = toDyn (Neg fromWild0fromWild0 rxl0 :: Factor)
repSubtree FactorArithS1 ((fromDynamic :: Dynamic -> Maybe Factor) -> Just (Lit fromWild0fromWild0
                                                                                lil0)) ((fromDynamic :: Dynamic -> Maybe Factor) -> Just (Lit _
                                                                                                                                              ril0)) = toDyn (Lit fromWild0fromWild0 ril0 :: Factor)
repSubtree FactorArithS2 ((fromDynamic :: Dynamic -> Maybe Factor) -> Just (Paren fromWild0fromWild0
                                                                                  lel0)) ((fromDynamic :: Dynamic -> Maybe Factor) -> Just (Paren _
                                                                                                                                                  rel0)) = toDyn (Paren fromWild0fromWild0 rel0 :: Factor)
repSubtree IntegerR dynS1 dynS2 = dynS1
repSubtree StringR dynS1 dynS2 = dynS1
repSubtree CharR dynS1 dynS2 = dynS1
repSubtree BoolR dynS1 dynS2 = dynS1

insSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
insSubtree ExprArithS2 ((fromDynamic :: Dynamic -> Maybe (Expr)) -> Just (FromT fromWild0
                                                                                theHole)) s0 = toDyn (FromT fromWild0 s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) TermNull
insSubtree TermArithS2 ((fromDynamic :: Dynamic -> Maybe (Term)) -> Just (FromF fromWild0
                                                                                theHole)) s0 = toDyn (FromF fromWild0 s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) FactorNull
insSubtree FactorArithS2 ((fromDynamic :: Dynamic -> Maybe (Factor)) -> Just (Paren fromWild0
                                                                                    theHole)) s0 = toDyn (Paren fromWild0 s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ExprNull

data RegPat
    = ExprArithV0
    | TermArithV1
    | TermArithS1
    | TermArithS2
    | ExprArithS2
    | FactorArithS1
    | ExprArithS1
    | TermArithV0
    | FactorArithS0
    | FactorArithV1
    | FactorArithS2
    | ExprArithS0
    | FactorArithV0
    | ExprArithV1
    | TermArithS0
    | IntegerR
    | StringR
    | CharR
    | BoolR
    | Void
    deriving (Eq, Show, Ord, Read)