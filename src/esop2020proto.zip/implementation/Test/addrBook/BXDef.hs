{-# LANGUAGE DeriveDataTypeable, TypeSynonymInstances, FlexibleInstances, MultiParamTypeClasses, ViewPatterns #-}

module BXDef where

import Prelude hiding (putChar)
import Data.Data
import Data.Generics hiding (GT)
import Data.Dynamic
import Data.List (partition, sortBy, nub)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Maybe (catMaybes, isJust, fromJust)

type Region = (RegPat, Path)
type RLink = (Region, Region)
type HLink = RLink

type VLink = (Path,RegPat,Path)
type VCorr = VLink

type OSDyn = Dynamic
type SDyn  = Dynamic
type VDyn  = Dynamic

type OSTyTag = TyTag
type STyTag  = TyTag
type VTyTag  = TyTag
type SupTyTag = TyTag
type SubTyTag = TyTag

type Path = [Integer]
type Env = [RLink]
type RLinks = [RLink]

-- functions handling paths and steps.

-- compose a HLink and a VLink
compHV :: RLink -> VCorr -> Maybe RLink
compHV ((hRegL,hPathL),(hRegR,hPathR)) (vPathU,vReg,vPathB)
  | hPathR == vPathU && hRegR == vReg = Just ((hRegL,hPathL),(hRegR,vPathB))
compHV _ _ = Nothing

-- compose [VCorr] and [RLink]
compHVs :: [RLink] -> [VCorr] -> [RLink]
compHVs hls vls = nub $ catMaybes [hl `compHV` vl | hl <- hls, vl <- vls]

filterEnv :: Path -> [RLink] -> [RLink]
filterEnv s = filter (\ (_ , (_,p)) -> isPrefix s p)

filterVLinkS :: Path -> [VCorr] -> [VCorr]
filterVLinkS p0 = filter (\ (p, _, _) -> isPrefix p0 p)

filterVLinkE :: Path -> [VCorr] -> [VCorr]
filterVLinkE p0 = filter (\ (_, _, p) -> isPrefix p0 p)

isPrefix :: Path -> Path -> Bool
isPrefix [] _ = True
isPrefix (s1:ss1) (s2:ss2) | s1 /= s2 = False
isPrefix (s1:ss1) (s2:ss2) | s1 == s2 = isPrefix ss1 ss2
isPrefix _ _ = False

-- delete the given prefix path from all links
delPathH :: (Path,Path) -> RLink -> RLink
delPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) =
  ((sReg,delPrefix sPre sp) , (vReg,delPrefix vPre vp))

delPrefix :: Path -> Path -> Path
delPrefix [] p = p
delPrefix s1 s2 = if isPrefix s1 s2 then drop (length s1) s2
  else error $ "the first input path is not a prefix of the second \n" ++
               "input path1: " ++ show s1 ++ "\n" ++ "input path2: " ++ show s2

addPathV :: (Path,Path) -> VLink -> VLink
addPathV (sPre1,sPre2) (sp1,sPat,sp2) = (sPre1 ++ sp1,sPat,sPre2 ++ sp2)

addPathH :: (Path,Path) -> RLink -> RLink
addPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) = ((sReg,sPre ++ sp) , (vReg,vPre ++ vp))

hasTopLink :: [RLink] -> Bool
hasTopLink = ([] `elem`) . map (snd . snd)

-- get links with empty view paths (link at the top)
-- return a Maybe real-link, a list of imaginary links (may be empty list), and remainings
-- to do so, we first sort the HLinks in the following order:
-- (3) : the links whose view-paths are empty come first
-- (2) : among (3), whose view-patterns is Void come first.
-- (1) : among (2), whose source-paths are smaller come first.
getTopLinks :: [RLink] -> (Maybe RLink, [RLink], [RLink])
getTopLinks hls =
  let (candidates3,rem3) = partition (\ (_,(_,vpath)) -> null vpath) hls
      -- rem2 should be either empty or singleton
      (candidates2,rem2) = partition (\ (_,(vRegion,_)) -> vRegion == Void) candidates3 
      candidates1 = sortBy cmpSPathRL candidates2
  in  case rem2 of
        []  -> (Nothing, candidates1, rem3)
        [r] -> (Just r, candidates1, rem3)

cmpSPathRL :: RLink -> RLink -> Ordering
cmpSPathRL ((_,sp1),_) ((_,sp2),_) = if sp1 < sp2 then LT
  else if sp1 == sp2 then EQ else GT

-- build vertical correspondence between an AST and itself, according to the given consitency links
-- do not use nub. nub will remove usefull links having the void region.
buildIdVCorr :: [RLink] -> [VCorr]
buildIdVCorr consisHLS = [(path2,pat2,path2) | ((pat1,path1) , (pat2,path2)) <- consisHLS]

apFst f (x,y) = (f x , y)


data List a =
    Nil
  | Cons a (List a)
  | ListNull
  deriving (Show, Read, Eq, Data, Typeable)

data Triple a b c =
    Triple a b c
  | TripleNull
  deriving (Show, Read, Eq, Data, Typeable)

data AddrBook =
    AddrBook (List AddrGroup)
  | AddrBookNull
  deriving (Show, Read, Eq, Data, Typeable)

data AddrGroup =
    AddrGroup String (List Person)
  | AddrGroupNull
  deriving (Show, Read, Eq, Data, Typeable)

data Person =
    Person (Triple String String String)
  | PersonNull
  deriving (Show, Read, Eq, Data, Typeable)

data SocialBook =
    SocialBook (List SocialGroup)
  | SocialBookNull
  deriving (Show, Read, Eq, Data, Typeable)

data SocialGroup =
    SocialGroup String (List String)
  | SocialGroupNull
  deriving (Show, Read, Eq, Data, Typeable)

data TyTag
    = ListAddrGroupTag
    | ListPersonTag
    | ListSocialGroupTag
    | ListStringTag
    | TripleStringStringStringTag
    | AddrBookTag
    | AddrGroupTag
    | PersonTag
    | SocialBookTag
    | SocialGroupTag
    | IntegerTag
    | StringTag
    | CharTag
    | BoolTag
    deriving (Eq, Show)

class TypeTag a
    where tyTag :: a -> TyTag

instance TypeTag Integer
    where tyTag _ = IntegerTag
instance TypeTag String
    where tyTag _ = StringTag
instance TypeTag Char
    where tyTag _ = CharTag
instance TypeTag Bool
    where tyTag _ = BoolTag
instance TypeTag ( List AddrGroup )
    where tyTag ListNull = ListAddrGroupTag
          tyTag (Nil) = ListAddrGroupTag
          tyTag (Cons _ _) = ListAddrGroupTag
instance TypeTag ( List Person )
    where tyTag ListNull = ListPersonTag
          tyTag (Nil) = ListPersonTag
          tyTag (Cons _ _) = ListPersonTag
instance TypeTag ( List SocialGroup )
    where tyTag ListNull = ListSocialGroupTag
          tyTag (Nil) = ListSocialGroupTag
          tyTag (Cons _ _) = ListSocialGroupTag
instance TypeTag ( List String )
    where tyTag ListNull = ListStringTag
          tyTag (Nil) = ListStringTag
          tyTag (Cons _ _) = ListStringTag
instance TypeTag ( Triple String String String )
    where tyTag TripleNull = TripleStringStringStringTag
          tyTag (Triple _ _ _) = TripleStringStringStringTag
instance TypeTag AddrBook
    where tyTag AddrBookNull = AddrBookTag
          tyTag (AddrBook _) = AddrBookTag
instance TypeTag AddrGroup
    where tyTag AddrGroupNull = AddrGroupTag
          tyTag (AddrGroup _ _) = AddrGroupTag
instance TypeTag Person
    where tyTag PersonNull = PersonTag
          tyTag (Person _) = PersonTag
instance TypeTag SocialBook
    where tyTag SocialBookNull = SocialBookTag
          tyTag (SocialBook _) = SocialBookTag
instance TypeTag SocialGroup
    where tyTag SocialGroupNull = SocialGroupTag
          tyTag (SocialGroup _ _) = SocialGroupTag

class Fetchable a
    where fetch :: Path -> a -> Dynamic

instance Fetchable Integer
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Integer"
instance Fetchable String
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a String"
instance Fetchable Char
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Char"
instance Fetchable Bool
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Bool"
instance ( Fetchable a , Typeable a ) => Fetchable ( List a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Cons t0 _ , (0)) -> fetch ps t0
                                   (Cons _ t1 , (1)) -> fetch ps t1
instance ( Fetchable a , Typeable a , Fetchable b , Typeable b , Fetchable c , Typeable c ) => Fetchable ( Triple a b c )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Triple t0 _ _ , (0)) -> fetch ps t0
                                   (Triple _ t1 _ , (1)) -> fetch ps t1
                                   (Triple _ _ t2 , (2)) -> fetch ps t2
instance Fetchable AddrBook
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (AddrBook t0 , (0)) -> fetch ps t0
instance Fetchable AddrGroup
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (AddrGroup t0 _ , (0)) -> fetch ps t0
                                   (AddrGroup _ t1 , (1)) -> fetch ps t1
instance Fetchable Person
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Person t0 , (0)) -> fetch ps t0
instance Fetchable SocialBook
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (SocialBook t0 , (0)) -> fetch ps t0
instance Fetchable SocialGroup
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (SocialGroup t0 _ , (0)) -> fetch ps t0
                                   (SocialGroup _ t1 , (1)) -> fetch ps t1

fetch' :: OSTyTag -> OSDyn -> RLink -> SDyn
fetch' AddrBookTag ((fromDynamic :: Dynamic ->
                                    Maybe AddrBook) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                     in fetch sPath os
fetch' SocialBookTag ((fromDynamic :: Dynamic ->
                                      Maybe SocialBook) -> Just os) l = let ((sReg, sPath),
                                                                             (_, [])) = l
                                                                         in fetch sPath os
fetch' ListAddrGroupTag ((fromDynamic :: Dynamic ->
                                         Maybe ( List AddrGroup )) -> Just os) l = let ((sReg,
                                                                                         sPath),
                                                                                        (_, [])) = l
                                                                                    in fetch sPath os
fetch' ListSocialGroupTag ((fromDynamic :: Dynamic ->
                                           Maybe ( List SocialGroup )) -> Just os) l = let ((sReg,
                                                                                             sPath),
                                                                                            (_,
                                                                                             [])) = l
                                                                                        in fetch sPath os
fetch' AddrGroupTag ((fromDynamic :: Dynamic ->
                                     Maybe AddrGroup) -> Just os) l = let ((sReg, sPath),
                                                                           (_, [])) = l
                                                                       in fetch sPath os
fetch' SocialGroupTag ((fromDynamic :: Dynamic ->
                                       Maybe SocialGroup) -> Just os) l = let ((sReg, sPath),
                                                                               (_, [])) = l
                                                                           in fetch sPath os
fetch' ListPersonTag ((fromDynamic :: Dynamic ->
                                      Maybe ( List Person )) -> Just os) l = let ((sReg, sPath),
                                                                                  (_, [])) = l
                                                                              in fetch sPath os
fetch' ListStringTag ((fromDynamic :: Dynamic ->
                                      Maybe ( List String )) -> Just os) l = let ((sReg, sPath),
                                                                                  (_, [])) = l
                                                                              in fetch sPath os
fetch' PersonTag ((fromDynamic :: Dynamic ->
                                  Maybe Person) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' StringTag ((fromDynamic :: Dynamic ->
                                  Maybe String) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' TripleStringStringStringTag ((fromDynamic :: Dynamic ->
                                                    Maybe ( Triple String String String )) -> Just os) l = let ((sReg,
                                                                                                                 sPath),
                                                                                                                (_,
                                                                                                                 [])) = l
                                                                                                            in fetch sPath os
fetch' IntegerTag ((fromDynamic :: Dynamic ->
                                   Maybe Integer) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                   in fetch sPath os
fetch' StringTag ((fromDynamic :: Dynamic ->
                                  Maybe String) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' CharTag ((fromDynamic :: Dynamic ->
                                Maybe Char) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' BoolTag ((fromDynamic :: Dynamic ->
                                Maybe Bool) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os

class Insertable a
    where ins :: (a, Path) -> (TyTag, Dynamic) -> a

instance Insertable Integer
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable String
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Char
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Bool
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable ( List AddrGroup )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List Person )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List SocialGroup )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List String )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( Triple String String String )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Triple theHole t1 t2 ,
                                               (0)) -> Triple ( fromDyn subT theHole ) t1 t2 
                                              (Triple t0 theHole t2 ,
                                               (1)) -> Triple t0 ( fromDyn subT theHole ) t2 
                                              (Triple t0 t1 theHole ,
                                               (2)) -> Triple t0 t1 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Triple theHole t1 t2 ,
                                                (0)) -> Triple ( ins (theHole,ps) (tySubT,subT) ) t1 t2 
                                               (Triple t0 theHole t2 ,
                                                (1)) -> Triple t0 ( ins (theHole,ps) (tySubT,subT) ) t2 
                                               (Triple t0 t1 theHole ,
                                                (2)) -> Triple t0 t1 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable AddrBook
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (AddrBook theHole ,
                                               (0)) -> AddrBook ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (AddrBook theHole ,
                                                (0)) -> AddrBook ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable AddrGroup
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (AddrGroup theHole t1 ,
                                               (0)) -> AddrGroup ( fromDyn subT theHole ) t1 
                                              (AddrGroup t0 theHole ,
                                               (1)) -> AddrGroup t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (AddrGroup theHole t1 ,
                                                (0)) -> AddrGroup ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (AddrGroup t0 theHole ,
                                                (1)) -> AddrGroup t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable Person
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Person theHole ,
                                               (0)) -> Person ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Person theHole ,
                                                (0)) -> Person ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable SocialBook
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (SocialBook theHole ,
                                               (0)) -> SocialBook ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (SocialBook theHole ,
                                                (0)) -> SocialBook ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable SocialGroup
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (SocialGroup theHole t1 ,
                                               (0)) -> SocialGroup ( fromDyn subT theHole ) t1 
                                              (SocialGroup t0 theHole ,
                                               (1)) -> SocialGroup t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (SocialGroup theHole t1 ,
                                                (0)) -> SocialGroup ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (SocialGroup t0 theHole ,
                                                (1)) -> SocialGroup t0 ( ins (theHole,ps) (tySubT,subT) ) 

class HasDefVal a
    where defVal :: TyTag -> a

instance HasDefVal ( List AddrGroup )
    where defVal ListAddrGroupTag = ListNull
instance HasDefVal ( List Person )
    where defVal ListPersonTag = ListNull
instance HasDefVal ( List SocialGroup )
    where defVal ListSocialGroupTag = ListNull
instance HasDefVal ( List String )
    where defVal ListStringTag = ListNull
instance HasDefVal ( Triple String String String )
    where defVal TripleStringStringStringTag = TripleNull
instance HasDefVal AddrBook
    where defVal AddrBookTag = AddrBookNull
instance HasDefVal AddrGroup
    where defVal AddrGroupTag = AddrGroupNull
instance HasDefVal Person
    where defVal PersonTag = PersonNull
instance HasDefVal SocialBook
    where defVal SocialBookTag = SocialBookNull
instance HasDefVal SocialGroup
    where defVal SocialGroupTag = SocialGroupNull
instance HasDefVal Integer
    where defVal IntegerTag = 0
instance HasDefVal String
    where defVal StringTag = "DEF_VAL"
instance HasDefVal Char
    where defVal CharTag = 'X'
instance HasDefVal Bool
    where defVal BoolTag = False

class NodeAndPath a
    where nodeAndPath :: a -> [(Dynamic, Path)]

instance NodeAndPath Integer
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath String
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Char
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Bool
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath ( List AddrGroup )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List Person )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List SocialGroup )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List String )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( Triple String String String )
    where nodeAndPath (t@(Triple t0
                                 t1
                                 t2)) = (([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)) ++ map (\(n,p) -> (n,2:p)) (nodeAndPath t2)
instance NodeAndPath AddrBook
    where nodeAndPath (t@(AddrBook t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath AddrGroup
    where nodeAndPath (t@(AddrGroup t0
                                    t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath Person
    where nodeAndPath (t@(Person t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath SocialBook
    where nodeAndPath (t@(SocialBook t0)) = [(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)
instance NodeAndPath SocialGroup
    where nodeAndPath (t@(SocialGroup t0
                                      t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)

class IntConv sub sup
    where inj :: sub -> sup
instance IntConv ( Triple String String String ) Person
    where inj tl = Person tl
mkInj :: SubTyTag -> SupTyTag -> Dynamic -> Dynamic
mkInj (TripleStringStringStringTag) (PersonTag) s0 | isJust (fromDynamic s0 :: Maybe ( Triple String String String )) = toDyn s'
          where s' = inj (fromJust (fromDynamic s0 :: Maybe ( Triple String String String ))) :: Person
mkInj a b c | a == b = c

selSPat :: TyTag -> TyTag -> Dynamic -> RegPat
selSPat (AddrBookTag) (SocialBookTag) ((fromDynamic :: Dynamic -> Maybe SocialBook) -> Just (SocialBook xsr0)) = AddrBookSocialBookS0
selSPat (ListAddrGroupTag) (ListSocialGroupTag) ((fromDynamic :: Dynamic -> Maybe ( List SocialGroup )) -> Just (Nil)) = ListAddrGroupListSocialGroupS0
selSPat (ListAddrGroupTag) (ListSocialGroupTag) ((fromDynamic :: Dynamic -> Maybe ( List SocialGroup )) -> Just (Cons xr0
                                                                                                                      xsr1)) = ListAddrGroupListSocialGroupS1
selSPat (AddrGroupTag) (SocialGroupTag) ((fromDynamic :: Dynamic -> Maybe SocialGroup) -> Just (SocialGroup grpr0
                                                                                                            pr1)) = AddrGroupSocialGroupS0
selSPat (ListPersonTag) (ListStringTag) ((fromDynamic :: Dynamic -> Maybe ( List String )) -> Just (Nil)) = ListPersonListStringS0
selSPat (ListPersonTag) (ListStringTag) ((fromDynamic :: Dynamic -> Maybe ( List String )) -> Just (Cons pr0
                                                                                                         xsr1)) = ListPersonListStringS1
selSPat (PersonTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just tr0) = PersonStringS0
selSPat (TripleStringStringStringTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just namer0) = TripleStringStringStringStringS0
selSPat (IntegerTag) (IntegerTag) ((fromDynamic :: Dynamic -> Maybe Integer) -> Just prim) = IntegerR
selSPat (StringTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just prim) = StringR
selSPat (CharTag) (CharTag) ((fromDynamic :: Dynamic -> Maybe Char) -> Just prim) = CharR
selSPat (BoolTag) (BoolTag) ((fromDynamic :: Dynamic -> Maybe Bool) -> Just prim) = BoolR
selSPat x y z = (error $ "panic. source tag: " ++ show x ++ "\nview tag " ++ show y ++ "\nnot found!\n" ++ show z)

askDynTyTag :: Dynamic -> TyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List AddrGroup )) -> Just _) = ListAddrGroupTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List Person )) -> Just _) = ListPersonTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List SocialGroup )) -> Just _) = ListSocialGroupTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List String )) -> Just _) = ListStringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( Triple String String String )) -> Just _) = TripleStringStringStringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe AddrBook) -> Just _) = AddrBookTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe AddrGroup) -> Just _) = AddrGroupTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Person) -> Just _) = PersonTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe SocialBook) -> Just _) = SocialBookTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe SocialGroup) -> Just _) = SocialGroupTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Integer) -> Just _) = IntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe String) -> Just _) = StringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Char) -> Just _) = CharTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Bool) -> Just _) = BoolTag

splice :: OSDyn -> RLink -> SDyn -> SDyn
splice osDyn imag s0 = insSubtree sReg (fetch' (askDynTyTag osDyn) osDyn imag) s0
  where
    ((sReg,_),(Void,[])) = imag

repSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
repSubtree AddrBookSocialBookS0 ((fromDynamic :: Dynamic -> Maybe AddrBook) -> Just (AddrBook lxsl0)) ((fromDynamic :: Dynamic -> Maybe AddrBook) -> Just (AddrBook rxsl0)) = toDyn (AddrBook rxsl0 :: AddrBook)
repSubtree ListAddrGroupListSocialGroupS0 ((fromDynamic :: Dynamic -> Maybe ( List AddrGroup )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List AddrGroup )) -> Just (Nil)) = toDyn (Nil :: ( List AddrGroup ))
repSubtree ListAddrGroupListSocialGroupS1 ((fromDynamic :: Dynamic -> Maybe ( List AddrGroup )) -> Just (Cons lxl0
                                                                                                              lxsl1)) ((fromDynamic :: Dynamic -> Maybe ( List AddrGroup )) -> Just (Cons rxl0
                                                                                                                                                                                          rxsl1)) = toDyn (Cons rxl0 rxsl1 :: ( List AddrGroup ))
repSubtree AddrGroupSocialGroupS0 ((fromDynamic :: Dynamic -> Maybe AddrGroup) -> Just (AddrGroup lgrpl0
                                                                                                  lpl1)) ((fromDynamic :: Dynamic -> Maybe AddrGroup) -> Just (AddrGroup rgrpl0
                                                                                                                                                                         rpl1)) = toDyn (AddrGroup rgrpl0 rpl1 :: AddrGroup)
repSubtree ListPersonListStringS0 ((fromDynamic :: Dynamic -> Maybe ( List Person )) -> Just (Nil)) ((fromDynamic :: Dynamic -> Maybe ( List Person )) -> Just (Nil)) = toDyn (Nil :: ( List Person ))
repSubtree ListPersonListStringS1 ((fromDynamic :: Dynamic -> Maybe ( List Person )) -> Just (Cons lpl0
                                                                                                   lxsl1)) ((fromDynamic :: Dynamic -> Maybe ( List Person )) -> Just (Cons rpl0
                                                                                                                                                                            rxsl1)) = toDyn (Cons rpl0 rxsl1 :: ( List Person ))
repSubtree PersonStringS0 ((fromDynamic :: Dynamic -> Maybe Person) -> Just (Person ltl0)) ((fromDynamic :: Dynamic -> Maybe Person) -> Just (Person rtl0)) = toDyn (Person rtl0 :: Person)
repSubtree TripleStringStringStringStringS0 ((fromDynamic :: Dynamic -> Maybe ( Triple String String String )) -> Just (Triple lnamel0
                                                                                                                               fromWild0fromWild0
                                                                                                                               fromWild1fromWild1)) ((fromDynamic :: Dynamic -> Maybe ( Triple String String String )) -> Just (Triple rnamel0
                                                                                                                                                                                                                                       _
                                                                                                                                                                                                                                       _)) = toDyn (Triple rnamel0 fromWild0fromWild0 fromWild1fromWild1 :: ( Triple String String String ))
repSubtree IntegerR dynS1 dynS2 = dynS1
repSubtree StringR dynS1 dynS2 = dynS1
repSubtree CharR dynS1 dynS2 = dynS1
repSubtree BoolR dynS1 dynS2 = dynS1

insSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
insSubtree PersonStringS0 ((fromDynamic :: Dynamic -> Maybe (Person)) -> Just (Person theHole)) s0 = toDyn (Person s1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) TripleNull
insSubtree TripleStringStringStringStringS0 ((fromDynamic :: Dynamic -> Maybe (Triple String String String)) -> Just (Triple theHole
                                                                                                                             fromWild0
                                                                                                                             fromWild1)) s0 = toDyn (Triple s1 fromWild0 fromWild1)
               where s1 = fromDyn (mkInj (tyTag theHole) (askDynTyTag s0) s0) ("DEF_VAL")

data RegPat
    = AddrBookSocialBookS0
    | AddrGroupSocialGroupS0
    | ListAddrGroupListSocialGroupS1
    | ListPersonListStringS1
    | ListAddrGroupListSocialGroupV1
    | ListPersonListStringV1
    | ListAddrGroupListSocialGroupS0
    | ListPersonListStringS0
    | ListAddrGroupListSocialGroupV0
    | ListPersonListStringV0
    | PersonStringS0
    | AddrBookSocialBookV0
    | AddrGroupSocialGroupV0
    | TripleStringStringStringStringS0
    | IntegerR
    | StringR
    | CharR
    | BoolR
    | Void
    deriving (Eq, Show, Ord, Read)