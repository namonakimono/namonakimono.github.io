{-# LANGUAGE ViewPatterns #-}
module BX where

import BXDef
import Prelude hiding (putChar)
import Data.Maybe (isJust, isNothing, fromJust)
import Data.List (partition, sortBy, sort)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Dynamic
import Text.Show.Pretty (pPrint, ppShow)

topGetAddrBookSocialBook :: AddrBook -> (SocialBook, [RLink])

topGetAddrBookSocialBook s = let (view,
                                  rlinks) = getAddrBookSocialBook s
                              in (view, rlinks)

topGetListAddrGroupListSocialGroup :: List AddrGroup ->
                                      (List SocialGroup, [RLink])

topGetListAddrGroupListSocialGroup s = let (view,
                                            rlinks) = getListAddrGroupListSocialGroup s
                                        in (view, rlinks)

topGetAddrGroupSocialGroup :: AddrGroup -> (SocialGroup, [RLink])

topGetAddrGroupSocialGroup s = let (view,
                                    rlinks) = getAddrGroupSocialGroup s
                                in (view, rlinks)

topGetListPersonListString :: List Person -> (List String, [RLink])

topGetListPersonListString s = let (view,
                                    rlinks) = getListPersonListString s
                                in (view, rlinks)

topGetPersonString :: Person -> (String, [RLink])

topGetPersonString s = let (view, rlinks) = getPersonString s
                        in (view, rlinks)

topGetTripleStringStringStringString :: Triple String String String ->
                                        (String, [RLink])

topGetTripleStringStringStringString s = let (view,
                                              rlinks) = getTripleStringStringStringString s
                                          in (view, rlinks)

getAddrBookSocialBook :: AddrBook -> (SocialBook, [RLink])

getAddrBookSocialBook (AddrBook xsl0) = (SocialBook xsr0, l0 : ls')
                          where (xsr0, xsr0ls) = getListAddrGroupListSocialGroup xsl0
                                preS_xsr0 = [0]
                                preV_xsr0 = [0]
                                xsr0ls' = map (addPathH (preS_xsr0, preV_xsr0)) xsr0ls
                                l0 = ((AddrBookSocialBookS0, []), (AddrBookSocialBookV0, []))
                                ls' = concat [xsr0ls']

getListAddrGroupListSocialGroup :: List AddrGroup ->
                                   (List SocialGroup, [RLink])

getListAddrGroupListSocialGroup (Nil) = (Nil, l0 : ls')
                                    where l0 = ((ListAddrGroupListSocialGroupS0, []),
                                                (ListAddrGroupListSocialGroupV0, []))
                                          ls' = concat []
getListAddrGroupListSocialGroup (Cons xl0 xsl1) = (Cons xr0 xsr1,
                                                   l0 : ls')
                                    where (xr0, xr0ls) = getAddrGroupSocialGroup xl0
                                          preS_xr0 = [0]
                                          preV_xr0 = [0]
                                          xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                                          (xsr1, xsr1ls) = getListAddrGroupListSocialGroup xsl1
                                          preS_xsr1 = [1]
                                          preV_xsr1 = [1]
                                          xsr1ls' = map (addPathH (preS_xsr1, preV_xsr1)) xsr1ls
                                          l0 = ((ListAddrGroupListSocialGroupS1, []),
                                                (ListAddrGroupListSocialGroupV1, []))
                                          ls' = concat [xr0ls', xsr1ls']

getAddrGroupSocialGroup :: AddrGroup -> (SocialGroup, [RLink])

getAddrGroupSocialGroup (AddrGroup grpl0
                                   pl1) = (SocialGroup grpr0 pr1, l0 : ls')
                            where (grpr0, grpr0ls) = getStringString grpl0
                                  preS_grpr0 = [0]
                                  preV_grpr0 = [0]
                                  grpr0ls' = map (addPathH (preS_grpr0, preV_grpr0)) grpr0ls
                                  (pr1, pr1ls) = getListPersonListString pl1
                                  preS_pr1 = [1]
                                  preV_pr1 = [1]
                                  pr1ls' = map (addPathH (preS_pr1, preV_pr1)) pr1ls
                                  l0 = ((AddrGroupSocialGroupS0, []), (AddrGroupSocialGroupV0, []))
                                  ls' = concat [grpr0ls', pr1ls']

getListPersonListString :: List Person -> (List String, [RLink])

getListPersonListString (Nil) = (Nil, l0 : ls')
                            where l0 = ((ListPersonListStringS0, []),
                                        (ListPersonListStringV0, []))
                                  ls' = concat []
getListPersonListString (Cons pl0 xsl1) = (Cons pr0 xsr1, l0 : ls')
                            where (pr0, pr0ls) = getPersonString pl0
                                  preS_pr0 = [0]
                                  preV_pr0 = [0]
                                  pr0ls' = map (addPathH (preS_pr0, preV_pr0)) pr0ls
                                  (xsr1, xsr1ls) = getListPersonListString xsl1
                                  preS_xsr1 = [1]
                                  preV_xsr1 = [1]
                                  xsr1ls' = map (addPathH (preS_xsr1, preV_xsr1)) xsr1ls
                                  l0 = ((ListPersonListStringS1, []), (ListPersonListStringV1, []))
                                  ls' = concat [pr0ls', xsr1ls']

getPersonString :: Person -> (String, [RLink])

getPersonString (Person tl0) = (tr0, l0 : ls')
                    where (tr0, tr0ls) = getTripleStringStringStringString tl0
                          preS_tr0 = [0]
                          preV_tr0 = []
                          tr0ls' = map (addPathH (preS_tr0, preV_tr0)) tr0ls
                          l0 = ((PersonStringS0, []), (Void, []))
                          ls' = concat [tr0ls']

getTripleStringStringStringString :: Triple String String String ->
                                     (String, [RLink])

getTripleStringStringStringString (Triple namel0 _ _) = (namer0,
                                                         l0 : ls')
                                      where (namer0, namer0ls) = getStringString namel0
                                            preS_namer0 = [0]
                                            preV_namer0 = []
                                            namer0ls' = map (addPathH (preS_namer0,
                                                                       preV_namer0)) namer0ls
                                            l0 = ((TripleStringStringStringStringS0, []),
                                                  (Void, []))
                                            ls' = concat [namer0ls']

getIntegerInteger s = (s, [((IntegerR, []), (IntegerR, []))])

getStringString s = (s, [((StringR, []), (StringR, []))])

getCharChar s = (s, [((CharR, []), (CharR, []))])

getBoolBool s = (s, [((BoolR, []), (BoolR, []))])

put :: OSTyTag ->
       STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

put osTy sTy vTy osDyn vDyn env | not (hasTopLink env) = putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env

put osTy sTy vTy osDyn vDyn env | hasTopLink env = putWithLinks osTy sTy vTy osDyn vDyn env

putNoLink :: OSTyTag ->
             STyTag -> VTyTag -> RegPat -> OSDyn -> VDyn -> [RLink] -> SDyn

putNoLink _ (IntegerTag) (IntegerTag) _ _ dynV _ = dynV

putNoLink _ (StringTag) (StringTag) _ _ dynV _ = dynV

putNoLink _ (CharTag) (CharTag) _ _ dynV _ = dynV

putNoLink _ (BoolTag) (BoolTag) _ _ dynV _ = dynV

putNoLink osTy (ListAddrGroupTag) (ListSocialGroupTag) ListAddrGroupListSocialGroupS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List SocialGroup)) -> Just (Nil)) env = toDyn ((Nil) :: ( List AddrGroup ))
putNoLink osTy (ListAddrGroupTag) (ListSocialGroupTag) ListAddrGroupListSocialGroupS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List SocialGroup)) -> Just (Cons xr0
                                                                                                                                                                xsr1)) env = toDyn ((Cons res_xr0 res_xsr1) :: ( List AddrGroup ))
              where preS_xr0 = [0]
                    preV_xr0 = [0]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( AddrGroup )
                    res_xr0 = fromJust (fromDynamic (put osTy AddrGroupTag SocialGroupTag osDyn (toDyn xr0) env_xr0))
                    preS_xsr1 = [1]
                    preV_xsr1 = [1]
                    env_xsr1 = map (delPathH ([], preV_xsr1)) (filterEnv preV_xsr1 env)
                    res_xsr1 :: ( List AddrGroup )
                    res_xsr1 = fromJust (fromDynamic (put osTy ListAddrGroupTag ListSocialGroupTag osDyn (toDyn xsr1) env_xsr1))

putNoLink osTy (ListPersonTag) (ListStringTag) ListPersonListStringS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List String)) -> Just (Nil)) env = toDyn ((Nil) :: ( List Person ))
putNoLink osTy (ListPersonTag) (ListStringTag) ListPersonListStringS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List String)) -> Just (Cons pr0
                                                                                                                                           xsr1)) env = toDyn ((Cons res_pr0 res_xsr1) :: ( List Person ))
              where preS_pr0 = [0]
                    preV_pr0 = [0]
                    env_pr0 = map (delPathH ([], preV_pr0)) (filterEnv preV_pr0 env)
                    res_pr0 :: ( Person )
                    res_pr0 = fromJust (fromDynamic (put osTy PersonTag StringTag osDyn (toDyn pr0) env_pr0))
                    preS_xsr1 = [1]
                    preV_xsr1 = [1]
                    env_xsr1 = map (delPathH ([], preV_xsr1)) (filterEnv preV_xsr1 env)
                    res_xsr1 :: ( List Person )
                    res_xsr1 = fromJust (fromDynamic (put osTy ListPersonTag ListStringTag osDyn (toDyn xsr1) env_xsr1))

putNoLink osTy (AddrBookTag) (SocialBookTag) AddrBookSocialBookS0 osDyn ((fromDynamic :: Dynamic -> Maybe (SocialBook)) -> Just (SocialBook xsr0)) env = toDyn ((AddrBook res_xsr0) :: AddrBook)
              where preS_xsr0 = [0]
                    preV_xsr0 = [0]
                    env_xsr0 = map (delPathH ([], preV_xsr0)) (filterEnv preV_xsr0 env)
                    res_xsr0 :: ( List AddrGroup )
                    res_xsr0 = fromJust (fromDynamic (put osTy ListAddrGroupTag ListSocialGroupTag osDyn (toDyn xsr0) env_xsr0))

putNoLink osTy (AddrGroupTag) (SocialGroupTag) AddrGroupSocialGroupS0 osDyn ((fromDynamic :: Dynamic -> Maybe (SocialGroup)) -> Just (SocialGroup grpr0
                                                                                                                                                  pr1)) env = toDyn ((AddrGroup res_grpr0 res_pr1) :: AddrGroup)
              where preS_grpr0 = [0]
                    preV_grpr0 = [0]
                    env_grpr0 = map (delPathH ([],
                                               preV_grpr0)) (filterEnv preV_grpr0 env)
                    res_grpr0 :: ( String )
                    res_grpr0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn grpr0) env_grpr0))
                    preS_pr1 = [1]
                    preV_pr1 = [1]
                    env_pr1 = map (delPathH ([], preV_pr1)) (filterEnv preV_pr1 env)
                    res_pr1 :: ( List Person )
                    res_pr1 = fromJust (fromDynamic (put osTy ListPersonTag ListStringTag osDyn (toDyn pr1) env_pr1))

putNoLink osTy (PersonTag) (StringTag) PersonStringS0 osDyn ((fromDynamic :: Dynamic -> Maybe (String)) -> Just tr0) env = toDyn ((Person res_tr0) :: Person)
              where preS_tr0 = [0]
                    preV_tr0 = []
                    env_tr0 = map (delPathH ([], preV_tr0)) (filterEnv preV_tr0 env)
                    res_tr0 :: ( Triple String String String )
                    res_tr0 = fromJust (fromDynamic (put osTy TripleStringStringStringTag StringTag osDyn (toDyn tr0) env_tr0))

putNoLink osTy (TripleStringStringStringTag) (StringTag) TripleStringStringStringStringS0 osDyn ((fromDynamic :: Dynamic -> Maybe (String)) -> Just namer0) env = toDyn ((Triple res_namer0 "DEF_VAL" "DEF_VAL") :: ( Triple String String String ))
              where preS_namer0 = [0]
                    preV_namer0 = []
                    env_namer0 = map (delPathH ([],
                                                preV_namer0)) (filterEnv preV_namer0 env)
                    res_namer0 :: ( String )
                    res_namer0 = fromJust (fromDynamic (put osTy StringTag StringTag osDyn (toDyn namer0) env_namer0))

putWithLinks :: OSTyTag ->
                STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

putWithLinks osTy sTy vTy osDyn vDyn env = s4
                 where (maybeL, imags, env') = getTopLinks env
                       s2 = case maybeL of
                                Just l -> let {((sReg, sPath), (_, [])) = l;
                                               s0 = fetch' osTy osDyn l;
                                               s1 = putNoLink osTy (askDynTyTag s0) vTy sReg osDyn vDyn env'}
                                           in (repSubtree sReg s0 s1)
                                Nothing -> putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env'
                       s3 = foldr (splice osDyn) s2 imags
                       s4 = mkInj (askDynTyTag s3) sTy s3

topPut :: OSTyTag -> STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

topPut osTy sTy vTy osDyn vDyn hls = put osTy sTy vTy osDyn vDyn hls

