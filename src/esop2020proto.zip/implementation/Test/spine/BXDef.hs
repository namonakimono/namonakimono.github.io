{-# LANGUAGE DeriveDataTypeable, TypeSynonymInstances, FlexibleInstances, MultiParamTypeClasses, ViewPatterns #-}

module BXDef where

import Prelude hiding (putChar)
import Data.Data
import Data.Generics hiding (GT)
import Data.Dynamic
import Data.List (partition, sortBy, nub)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Maybe (catMaybes, isJust, fromJust)

type Region = (RegPat, Path)
type RLink = (Region, Region)
type HLink = RLink

type VLink = (Path,RegPat,Path)
type VCorr = VLink

type OSDyn = Dynamic
type SDyn  = Dynamic
type VDyn  = Dynamic

type OSTyTag = TyTag
type STyTag  = TyTag
type VTyTag  = TyTag
type SupTyTag = TyTag
type SubTyTag = TyTag

type Path = [Integer]
type Env = [RLink]
type RLinks = [RLink]

-- functions handling paths and steps.

-- compose a HLink and a VLink
compHV :: RLink -> VCorr -> Maybe RLink
compHV ((hRegL,hPathL),(hRegR,hPathR)) (vPathU,vReg,vPathB)
  | hPathR == vPathU && hRegR == vReg = Just ((hRegL,hPathL),(hRegR,vPathB))
compHV _ _ = Nothing

-- compose [VCorr] and [RLink]
compHVs :: [RLink] -> [VCorr] -> [RLink]
compHVs hls vls = nub $ catMaybes [hl `compHV` vl | hl <- hls, vl <- vls]

filterEnv :: Path -> [RLink] -> [RLink]
filterEnv s = filter (\ (_ , (_,p)) -> isPrefix s p)

filterVLinkS :: Path -> [VCorr] -> [VCorr]
filterVLinkS p0 = filter (\ (p, _, _) -> isPrefix p0 p)

filterVLinkE :: Path -> [VCorr] -> [VCorr]
filterVLinkE p0 = filter (\ (_, _, p) -> isPrefix p0 p)

isPrefix :: Path -> Path -> Bool
isPrefix [] _ = True
isPrefix (s1:ss1) (s2:ss2) | s1 /= s2 = False
isPrefix (s1:ss1) (s2:ss2) | s1 == s2 = isPrefix ss1 ss2
isPrefix _ _ = False

-- delete the given prefix path from all links
delPathH :: (Path,Path) -> RLink -> RLink
delPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) =
  ((sReg,delPrefix sPre sp) , (vReg,delPrefix vPre vp))

delPrefix :: Path -> Path -> Path
delPrefix [] p = p
delPrefix s1 s2 = if isPrefix s1 s2 then drop (length s1) s2
  else error $ "the first input path is not a prefix of the second \n" ++
               "input path1: " ++ show s1 ++ "\n" ++ "input path2: " ++ show s2

addPathV :: (Path,Path) -> VLink -> VLink
addPathV (sPre1,sPre2) (sp1,sPat,sp2) = (sPre1 ++ sp1,sPat,sPre2 ++ sp2)

addPathH :: (Path,Path) -> RLink -> RLink
addPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) = ((sReg,sPre ++ sp) , (vReg,vPre ++ vp))

hasTopLink :: [RLink] -> Bool
hasTopLink = ([] `elem`) . map (snd . snd)

-- get links with empty view paths (link at the top)
-- return a Maybe real-link, a list of imaginary links (may be empty list), and remainings
-- to do so, we first sort the HLinks in the following order:
-- (3) : the links whose view-paths are empty come first
-- (2) : among (3), whose view-patterns is Void come first.
-- (1) : among (2), whose source-paths are smaller come first.
getTopLinks :: [RLink] -> (Maybe RLink, [RLink], [RLink])
getTopLinks hls =
  let (candidates3,rem3) = partition (\ (_,(_,vpath)) -> null vpath) hls
      -- rem2 should be either empty or singleton
      (candidates2,rem2) = partition (\ (_,(vRegion,_)) -> vRegion == Void) candidates3 
      candidates1 = sortBy cmpSPathRL candidates2
  in  case rem2 of
        []  -> (Nothing, candidates1, rem3)
        [r] -> (Just r, candidates1, rem3)

cmpSPathRL :: RLink -> RLink -> Ordering
cmpSPathRL ((_,sp1),_) ((_,sp2),_) = if sp1 < sp2 then LT
  else if sp1 == sp2 then EQ else GT

-- build vertical correspondence between an AST and itself, according to the given consitency links
-- do not use nub. nub will remove usefull links having the void region.
buildIdVCorr :: [RLink] -> [VCorr]
buildIdVCorr consisHLS = [(path2,pat2,path2) | ((pat1,path1) , (pat2,path2)) <- consisHLS]

apFst f (x,y) = (f x , y)


data List a =
    Nil
  | Cons a (List a)
  | ListNull
  deriving (Show, Read, Eq, Data, Typeable)

data RTree a =
    RNode a (List ( RTree a ))
  | RTreeNull
  deriving (Show, Read, Eq, Data, Typeable)

data TyTag
    = ListIntegerTag
    | ListRTreeIntegerTag
    | RTreeIntegerTag
    | IntegerTag
    | StringTag
    | CharTag
    | BoolTag
    deriving (Eq, Show)

class TypeTag a
    where tyTag :: a -> TyTag

instance TypeTag Integer
    where tyTag _ = IntegerTag
instance TypeTag String
    where tyTag _ = StringTag
instance TypeTag Char
    where tyTag _ = CharTag
instance TypeTag Bool
    where tyTag _ = BoolTag
instance TypeTag ( List Integer )
    where tyTag ListNull = ListIntegerTag
          tyTag (Nil) = ListIntegerTag
          tyTag (Cons _ _) = ListIntegerTag
instance TypeTag ( List ( RTree Integer ) )
    where tyTag ListNull = ListRTreeIntegerTag
          tyTag (Nil) = ListRTreeIntegerTag
          tyTag (Cons _ _) = ListRTreeIntegerTag
instance TypeTag ( RTree Integer )
    where tyTag RTreeNull = RTreeIntegerTag
          tyTag (RNode _ _) = RTreeIntegerTag

class Fetchable a
    where fetch :: Path -> a -> Dynamic

instance Fetchable Integer
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Integer"
instance Fetchable String
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a String"
instance Fetchable Char
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Char"
instance Fetchable Bool
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Bool"
instance ( Fetchable a , Typeable a ) => Fetchable ( List a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Cons t0 _ , (0)) -> fetch ps t0
                                   (Cons _ t1 , (1)) -> fetch ps t1
instance ( Fetchable a , Typeable a ) => Fetchable ( RTree a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (RNode t0 _ , (0)) -> fetch ps t0
                                   (RNode _ t1 , (1)) -> fetch ps t1

fetch' :: OSTyTag -> OSDyn -> RLink -> SDyn
fetch' RTreeIntegerTag ((fromDynamic :: Dynamic ->
                                        Maybe ( RTree Integer )) -> Just os) l = let ((sReg, sPath),
                                                                                      (_, [])) = l
                                                                                  in fetch sPath os
fetch' ListIntegerTag ((fromDynamic :: Dynamic ->
                                       Maybe ( List Integer )) -> Just os) l = let ((sReg, sPath),
                                                                                    (_, [])) = l
                                                                                in fetch sPath os
fetch' IntegerTag ((fromDynamic :: Dynamic ->
                                   Maybe Integer) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                   in fetch sPath os
fetch' StringTag ((fromDynamic :: Dynamic ->
                                  Maybe String) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' CharTag ((fromDynamic :: Dynamic ->
                                Maybe Char) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' BoolTag ((fromDynamic :: Dynamic ->
                                Maybe Bool) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os

class Insertable a
    where ins :: (a, Path) -> (TyTag, Dynamic) -> a

instance Insertable Integer
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable String
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Char
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable Bool
    where ins _ _ = error "invalid path for insertion. Primitive types such as Integer is reached"
instance Insertable ( List Integer )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( List ( RTree Integer ) )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (Cons theHole t1 ,
                                               (0)) -> Cons ( fromDyn subT theHole ) t1 
                                              (Cons t0 theHole ,
                                               (1)) -> Cons t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (Cons theHole t1 ,
                                                (0)) -> Cons ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (Cons t0 theHole ,
                                                (1)) -> Cons t0 ( ins (theHole,ps) (tySubT,subT) ) 
instance Insertable ( RTree Integer )
    where ins (src, [p]) (tySubT, subT) = case (src, p) of
                                              (RNode theHole t1 ,
                                               (0)) -> RNode ( fromDyn subT theHole ) t1 
                                              (RNode t0 theHole ,
                                               (1)) -> RNode t0 ( fromDyn subT theHole ) 
          ins (src, p:ps) (tySubT, subT) = case (src, p) of
                                               (RNode theHole t1 ,
                                                (0)) -> RNode ( ins (theHole,ps) (tySubT,subT) ) t1 
                                               (RNode t0 theHole ,
                                                (1)) -> RNode t0 ( ins (theHole,ps) (tySubT,subT) ) 

class HasDefVal a
    where defVal :: TyTag -> a

instance HasDefVal ( List Integer )
    where defVal ListIntegerTag = ListNull
instance HasDefVal ( List ( RTree Integer ) )
    where defVal ListRTreeIntegerTag = ListNull
instance HasDefVal ( RTree Integer )
    where defVal RTreeIntegerTag = RTreeNull
instance HasDefVal Integer
    where defVal IntegerTag = 0
instance HasDefVal String
    where defVal StringTag = "DEF_VAL"
instance HasDefVal Char
    where defVal CharTag = 'X'
instance HasDefVal Bool
    where defVal BoolTag = False

class NodeAndPath a
    where nodeAndPath :: a -> [(Dynamic, Path)]

instance NodeAndPath Integer
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath String
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Char
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath Bool
    where nodeAndPath i = [(toDyn i, [])]
instance NodeAndPath ( List Integer )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( List ( RTree Integer ) )
    where nodeAndPath (t@(Nil)) = [(toDyn t, [])]
          nodeAndPath (t@(Cons t0
                               t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)
instance NodeAndPath ( RTree Integer )
    where nodeAndPath (t@(RNode t0
                                t1)) = ([(toDyn t, [])] ++ map (\(n,p) -> (n,0:p)) (nodeAndPath t0)) ++ map (\(n,p) -> (n,1:p)) (nodeAndPath t1)

class IntConv sub sup
    where inj :: sub -> sup
mkInj :: SubTyTag -> SupTyTag -> Dynamic -> Dynamic
mkInj a b c | a == b = c

selSPat :: TyTag -> TyTag -> Dynamic -> RegPat
selSPat (RTreeIntegerTag) (ListIntegerTag) ((fromDynamic :: Dynamic -> Maybe ( List Integer )) -> Just (Cons ir0
                                                                                                             (Nil))) = RTreeIntegerListIntegerS0
selSPat (RTreeIntegerTag) (ListIntegerTag) ((fromDynamic :: Dynamic -> Maybe ( List Integer )) -> Just (Cons ir0
                                                                                                             tr1)) = RTreeIntegerListIntegerS1
selSPat (IntegerTag) (IntegerTag) ((fromDynamic :: Dynamic -> Maybe Integer) -> Just prim) = IntegerR
selSPat (StringTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just prim) = StringR
selSPat (CharTag) (CharTag) ((fromDynamic :: Dynamic -> Maybe Char) -> Just prim) = CharR
selSPat (BoolTag) (BoolTag) ((fromDynamic :: Dynamic -> Maybe Bool) -> Just prim) = BoolR
selSPat x y z = (error $ "panic. source tag: " ++ show x ++ "\nview tag " ++ show y ++ "\nnot found!\n" ++ show z)

askDynTyTag :: Dynamic -> TyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List Integer )) -> Just _) = ListIntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( List ( RTree Integer ) )) -> Just _) = ListRTreeIntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just _) = RTreeIntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Integer) -> Just _) = IntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe String) -> Just _) = StringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Char) -> Just _) = CharTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Bool) -> Just _) = BoolTag

splice :: OSDyn -> RLink -> SDyn -> SDyn
splice osDyn imag s0 = insSubtree sReg (fetch' (askDynTyTag osDyn) osDyn imag) s0
  where
    ((sReg,_),(Void,[])) = imag

repSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
repSubtree RTreeIntegerListIntegerS0 ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode lil0
                                                                                                         (Nil))) ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode ril0
                                                                                                                                                                                     (Nil))) = toDyn (RNode ril0 Nil :: ( RTree Integer ))
repSubtree RTreeIntegerListIntegerS1 ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode lil0
                                                                                                         (Cons ltl1
                                                                                                               fromWild0fromWild0))) ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode ril0
                                                                                                                                                                                                         (Cons rtl1
                                                                                                                                                                                                               _))) = toDyn (RNode ril0 (Cons rtl1 fromWild0fromWild0) :: ( RTree Integer ))
repSubtree IntegerR dynS1 dynS2 = dynS1
repSubtree StringR dynS1 dynS2 = dynS1
repSubtree CharR dynS1 dynS2 = dynS1
repSubtree BoolR dynS1 dynS2 = dynS1

insSubtree = undefined -- no need to define it since it will not be invoked.

data RegPat
    = RTreeIntegerListIntegerV0
    | RTreeIntegerListIntegerV1
    | RTreeIntegerListIntegerS1
    | RTreeIntegerListIntegerS0
    | IntegerR
    | StringR
    | CharR
    | BoolR
    | Void
    deriving (Eq, Show, Ord, Read)