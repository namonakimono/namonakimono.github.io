{-# LANGUAGE ViewPatterns #-}
module BX where

import BXDef
import Prelude hiding (putChar)
import Data.Maybe (isJust, isNothing, fromJust)
import Data.List (partition, sortBy, sort)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Dynamic
import Text.Show.Pretty (pPrint, ppShow)

topGetRTreeIntegerListInteger :: RTree Integer ->
                                 (List Integer, [RLink])

topGetRTreeIntegerListInteger s = let (view,
                                       rlinks) = getRTreeIntegerListInteger s
                                   in (view, rlinks)

getRTreeIntegerListInteger :: RTree Integer ->
                              (List Integer, [RLink])

getRTreeIntegerListInteger (RNode il0 (Nil)) = (Cons ir0 Nil,
                                                l0 : ls')
                               where (ir0, ir0ls) = getIntegerInteger il0
                                     preS_ir0 = [0]
                                     preV_ir0 = [0]
                                     ir0ls' = map (addPathH (preS_ir0, preV_ir0)) ir0ls
                                     l0 = ((RTreeIntegerListIntegerS0, []),
                                           (RTreeIntegerListIntegerV0, []))
                                     ls' = concat [ir0ls']
getRTreeIntegerListInteger (RNode il0
                                  (Cons tl1 _)) = (Cons ir0 tr1, l0 : ls')
                               where (ir0, ir0ls) = getIntegerInteger il0
                                     preS_ir0 = [0]
                                     preV_ir0 = [0]
                                     ir0ls' = map (addPathH (preS_ir0, preV_ir0)) ir0ls
                                     (tr1, tr1ls) = getRTreeIntegerListInteger tl1
                                     preS_tr1 = [1, 0]
                                     preV_tr1 = [1]
                                     tr1ls' = map (addPathH (preS_tr1, preV_tr1)) tr1ls
                                     l0 = ((RTreeIntegerListIntegerS1, []),
                                           (RTreeIntegerListIntegerV1, []))
                                     ls' = concat [ir0ls', tr1ls']

getIntegerInteger s = (s, [((IntegerR, []), (IntegerR, []))])

getStringString s = (s, [((StringR, []), (StringR, []))])

getCharChar s = (s, [((CharR, []), (CharR, []))])

getBoolBool s = (s, [((BoolR, []), (BoolR, []))])

put :: OSTyTag ->
       STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

put osTy sTy vTy osDyn vDyn env | not (hasTopLink env) = putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env

put osTy sTy vTy osDyn vDyn env | hasTopLink env = putWithLinks osTy sTy vTy osDyn vDyn env

putNoLink :: OSTyTag ->
             STyTag -> VTyTag -> RegPat -> OSDyn -> VDyn -> [RLink] -> SDyn

putNoLink _ (IntegerTag) (IntegerTag) _ _ dynV _ = dynV

putNoLink _ (StringTag) (StringTag) _ _ dynV _ = dynV

putNoLink _ (CharTag) (CharTag) _ _ dynV _ = dynV

putNoLink _ (BoolTag) (BoolTag) _ _ dynV _ = dynV

putNoLink osTy (RTreeIntegerTag) (ListIntegerTag) RTreeIntegerListIntegerS0 osDyn ((fromDynamic :: Dynamic -> Maybe (List Integer)) -> Just (Cons ir0
                                                                                                                                                  (Nil))) env = toDyn ((RNode res_ir0 Nil) :: ( RTree Integer ))
              where preS_ir0 = [0]
                    preV_ir0 = [0]
                    env_ir0 = map (delPathH ([], preV_ir0)) (filterEnv preV_ir0 env)
                    res_ir0 :: ( Integer )
                    res_ir0 = fromJust (fromDynamic (put osTy IntegerTag IntegerTag osDyn (toDyn ir0) env_ir0))
putNoLink osTy (RTreeIntegerTag) (ListIntegerTag) RTreeIntegerListIntegerS1 osDyn ((fromDynamic :: Dynamic -> Maybe (List Integer)) -> Just (Cons ir0
                                                                                                                                                  tr1)) env = toDyn ((RNode res_ir0 (Cons res_tr1 ListNull)) :: ( RTree Integer ))
              where preS_ir0 = [0]
                    preV_ir0 = [0]
                    env_ir0 = map (delPathH ([], preV_ir0)) (filterEnv preV_ir0 env)
                    res_ir0 :: ( Integer )
                    res_ir0 = fromJust (fromDynamic (put osTy IntegerTag IntegerTag osDyn (toDyn ir0) env_ir0))
                    preS_tr1 = [1, 0]
                    preV_tr1 = [1]
                    env_tr1 = map (delPathH ([], preV_tr1)) (filterEnv preV_tr1 env)
                    res_tr1 :: ( RTree Integer )
                    res_tr1 = fromJust (fromDynamic (put osTy RTreeIntegerTag ListIntegerTag osDyn (toDyn tr1) env_tr1))

putWithLinks :: OSTyTag ->
                STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

putWithLinks osTy sTy vTy osDyn vDyn env = s4
                 where (maybeL, imags, env') = getTopLinks env
                       s2 = case maybeL of
                                Just l -> let {((sReg, sPath), (_, [])) = l;
                                               s0 = fetch' osTy osDyn l;
                                               s1 = putNoLink osTy (askDynTyTag s0) vTy sReg osDyn vDyn env'}
                                           in (repSubtree sReg s0 s1)
                                Nothing -> putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env'
                       s3 = foldr (splice osDyn) s2 imags
                       s4 = mkInj (askDynTyTag s3) sTy s3

topPut :: OSTyTag -> STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

topPut osTy sTy vTy osDyn vDyn hls = put osTy sTy vTy osDyn vDyn hls

