{-# LANGUAGE DeriveDataTypeable, TypeSynonymInstances, FlexibleInstances, MultiParamTypeClasses, ViewPatterns #-}

module BXDef where

import Prelude hiding (putChar)
import Data.Data
import Data.Generics hiding (GT)
import Data.Dynamic
import Data.List (partition, sortBy)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Maybe (catMaybes, isJust, fromJust)

type Region = (RegPat, Path)
type RLink = (Region, Region)

type NamedPat = (RegPat, Int)
type NamedRegion = (NamedPat, Path)
type NamedRLink = (NamedRegion, NamedRegion)

data SProp = Top NamedPat
           | Child NamedPat NamedPat Integer
  deriving (Show, Eq, Ord)

type SPropLink = (SProp, SProp)
data HLink = FirstOrderLink  NamedRLink
           | SecondOrderLink SPropLink
  deriving (Show, Eq, Ord)

type SSLink = (Path,RegPat,Path)
type VVLink = (Path,Region,Path)

type OSDyn = Dynamic
type SDyn  = Dynamic
type VDyn  = Dynamic

type OSTyTag = TyTag
type STyTag  = TyTag
type VTyTag  = TyTag
type SupTyTag = TyTag
type SubTyTag = TyTag

type Path = [Integer]
type Env = [HLink]
type HLinks = [HLink]
type SSLinks = [SSLink]
type VVLinks = [VVLink]

-- functions handling paths and steps.
-- compose a SSLink and a RLink
compSSSV :: SSLink -> RLink -> Maybe RLink
compSSSV (sPathU,sReg1,sPathB) ((sReg2,sPathL),(vReg,vPathR))
  | sPathB == sPathL && sReg1 == sReg2 = Just ((sReg2,sPathU),(vReg,vPathR))
compSSSV _ _ = Nothing

-- compose SSLinks and [RLink]
compSSSVs :: SSLinks -> [RLink] -> [RLink]
compSSSVs ss sv = catMaybes [compSSSV s v | s <- ss, v <- sv]

filterEnv :: Path -> [RLink] -> [RLink]
filterEnv s = filter (\ (_ , (_,p)) -> isPrefix s p)

isPrefix :: Path -> Path -> Bool
isPrefix [] _ = True
isPrefix (s1:ss1) (s2:ss2) | s1 /= s2 = False
isPrefix (s1:ss1) (s2:ss2) | s1 == s2 = isPrefix ss1 ss2
isPrefix _ _ = False

-- delete the given prefix path from all links
delPathH :: (Path,Path) -> RLink -> RLink
delPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) =
  ((sReg,delPrefix sPre sp) , (vReg,delPrefix vPre vp))

delPrefix :: Path -> Path -> Path
delPrefix [] p = p
delPrefix s1 s2 = if isPrefix s1 s2 then drop (length s1) s2
  else error $ "the first input path is not a prefix of the second \n" ++
               "input path1: " ++ show s1 ++ "\n" ++ "input path2: " ++ show s2

addPathSS :: (Path,Path) -> SSLink -> SSLink
addPathSS (sPre1,sPre2) (sp1,sPat,sp2) = (sPre1 ++ sp1,sPat,sPre2 ++ sp2)

addPathH :: (Path,Path) -> RLink -> RLink
addPathH (sPre,vPre) ((sReg,sp),(vReg,vp)) = ((sReg,sPre ++ sp) , (vReg,vPre ++ vp))

hasTopLink :: [RLink] -> Bool
hasTopLink = ([] `elem`) . map (snd . snd)

-- get links with empty view paths (link at the top)
-- return a Maybe real-link, a list of imaginary links (may be empty list), and remainings
-- to do so, we first sort the HLinks in the following order:
-- (3) : the links whose view-paths are empty come first
-- (2) : among (3), whose view-patterns is Void come first.
-- (1) : among (2), whose source-paths are smaller come first.
getTopLinks :: [RLink] -> (Maybe RLink, [RLink], [RLink])
getTopLinks hls =
  let (candidates3,rem3) = partition (\ (_,(_,vpath)) -> null vpath) hls
      -- rem2 should be either empty or singleton
      (candidates2,rem2) = partition (\ (_,(vRegion,_)) -> vRegion == Void) candidates3 
      candidates1 = sortBy cmpSPathRL candidates2
  in  case rem2 of
        []  -> (Nothing, candidates1, rem3)
        [r] -> (Just r, candidates1, rem3)

cmpSPathRL :: RLink -> RLink -> Ordering
cmpSPathRL ((_,sp1),_) ((_,sp2),_) = if sp1 < sp2 then LT
  else if sp1 == sp2 then EQ else GT


toHLink :: [RLink] -> [HLink]
toHLink rls =
  let nrls = nameRLink rls
  in  map FirstOrderLink nrls ++ [topProp nrls] ++ relativePos nrls

nameRLink :: [RLink] -> [NamedRLink]
nameRLink rls =
  let rls' = sortBy cmpSPathRL rls
  in  zipWith (\((sPat,sPath), (vPat,vPath)) i ->
                  (((sPat,i),sPath) , ((vPat,i),vPath))) rls' [0..]

-- assume input lists are sorted
topProp :: [NamedRLink] -> HLink
topProp nrls =
  case filter (\ (((sPat,si),sPath) , ((vPat,vi),vPath)) -> null sPath && null vPath) nrls of
    [((nspat,[]) , (nvPat,[]))] -> SecondOrderLink (Top nspat , Top nvPat)

-- assume input lists are sorted
relativePos :: [NamedRLink] -> [HLink]
relativePos [] = []
relativePos (nrl@((_,sPath0), _):nrls) =
  let (children, others) = span (\ ((_,sPath1), _)  -> 1 + length sPath0 == length sPath1) nrls
  in  establishPosLink nrl children ++ relativePos nrls

establishPosLink :: NamedRLink -> [NamedRLink] -> [HLink]
establishPosLink _ [] = []
establishPosLink father@((fnsPat,fsPath),(fnvPat,fvPath)) (((cnsPat,csPath),(cnvPat,cvPath)) : cs) =
  let sPos = if null (drop (length fsPath) csPath)
              then error "impossible. in generating second-order links (relative positions)"
              else head $ drop (length fsPath) csPath
      vPos = if null (drop (length fvPath) cvPath)
              then -1
              else head $ drop (length fvPath) cvPath
  in  SecondOrderLink ((Child fnsPat cnsPat sPos) , (Child cnvPat cnvPat vPos)) :
      establishPosLink father cs


eraseSecondOrderProp :: [HLink] -> [RLink]
eraseSecondOrderProp [] = []
eraseSecondOrderProp (FirstOrderLink nrLink : l) = eraseName nrLink : eraseSecondOrderProp l
eraseSecondOrderProp (SecondOrderLink _ : l) = eraseSecondOrderProp l

eraseName :: NamedRLink -> RLink
eraseName (((regPatS,_), pathS), ((regPatV,_), pathV)) = ((regPatS, pathS) , (regPatV, pathV))

apFst f (x,y) = (f x , y)



data List a =
    Nil
  | Cons a (List a)
  | ListNull
  deriving (Show, Read, Eq, Data, Typeable)

data RTree a =
    RNode a (List ( RTree a ))
  | RTreeNull
  deriving (Show, Read, Eq, Data, Typeable)

data TyTag
    = ListIntegerTag
    | RTreeIntegerTag
    | IntegerTag
    | StringTag
    | CharTag
    | BoolTag
    deriving (Eq, Show)

class TagTypeable a
    where tyTag :: a -> TyTag

instance TagTypeable ( RTree Integer )
    where tyTag (RNode _ _) = RTreeIntegerTag
instance TagTypeable ( List Integer )
    where tyTag (Nil) = ListIntegerTag
          tyTag (Cons _ _) = ListIntegerTag

class Fetchable a
    where fetch :: Path -> a -> Dynamic

instance Fetchable Integer
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Integer"
instance Fetchable String
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a String"
instance Fetchable Char
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Char"
instance Fetchable Bool
    where fetch [] src = toDyn src
          fetch _ _ = error "invalid path for fetching a Bool"
instance ( Fetchable a , Typeable a ) => Fetchable ( List a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (Cons t0 _ , (0)) -> fetch ps t0
                                   (Cons _ t1 , (1)) -> fetch ps t1
instance ( Fetchable a , Typeable a ) => Fetchable ( RTree a )
    where fetch [] src = toDyn src
          fetch (p : ps) src = case (src, p) of
                                   (RNode t0 _ , (0)) -> fetch ps t0
                                   (RNode _ t1 , (1)) -> fetch ps t1

fetch' :: OSTyTag -> OSDyn -> RLink -> SDyn
fetch' RTreeIntegerTag ((fromDynamic :: Dynamic ->
                                        Maybe ( RTree Integer )) -> Just os) l = let ((sReg, sPath),
                                                                                      (_, [])) = l
                                                                                  in fetch sPath os
fetch' ListIntegerTag ((fromDynamic :: Dynamic ->
                                       Maybe ( List Integer )) -> Just os) l = let ((sReg, sPath),
                                                                                    (_, [])) = l
                                                                                in fetch sPath os
fetch' IntegerTag ((fromDynamic :: Dynamic ->
                                   Maybe Integer) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                   in fetch sPath os
fetch' StringTag ((fromDynamic :: Dynamic ->
                                  Maybe String) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                                 in fetch sPath os
fetch' CharTag ((fromDynamic :: Dynamic ->
                                Maybe Char) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os
fetch' BoolTag ((fromDynamic :: Dynamic ->
                                Maybe Bool) -> Just os) l = let ((sReg, sPath), (_, [])) = l
                                                             in fetch sPath os

class IntConv sub sup
    where inj :: sub -> sup
mkInj :: SubTyTag -> SupTyTag -> Dynamic -> Dynamic
mkInj a b c | a == b = c

selSPat :: TyTag -> TyTag -> Dynamic -> RegPat
selSPat (RTreeIntegerTag) (ListIntegerTag) ((fromDynamic :: Dynamic -> Maybe ( List Integer )) -> Just (Cons ir0
                                                                                                             (Nil))) = RTreeIntegerListIntegerS0
selSPat (RTreeIntegerTag) (ListIntegerTag) ((fromDynamic :: Dynamic -> Maybe ( List Integer )) -> Just (Cons ir0
                                                                                                             tr1)) = RTreeIntegerListIntegerS1
selSPat (IntegerTag) (IntegerTag) ((fromDynamic :: Dynamic -> Maybe Integer) -> Just prim) = IntegerR
selSPat (StringTag) (StringTag) ((fromDynamic :: Dynamic -> Maybe String) -> Just prim) = StringR
selSPat (CharTag) (CharTag) ((fromDynamic :: Dynamic -> Maybe Char) -> Just prim) = CharR
selSPat (BoolTag) (BoolTag) ((fromDynamic :: Dynamic -> Maybe Bool) -> Just prim) = BoolR
selSPat x y z = (error $ "panic. source tag: " ++ show x ++ "\nview tag " ++ show y ++ "\nnot found!\n" ++ show z)

askDynTyTag :: Dynamic -> TyTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just _) = RTreeIntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Integer) -> Just _) = IntegerTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe String) -> Just _) = StringTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Char) -> Just _) = CharTag
askDynTyTag ((fromDynamic :: Dynamic -> Maybe Bool) -> Just _) = BoolTag

splice :: OSDyn -> RLink -> SDyn -> SDyn
splice osDyn imag s0 = insSubtree sReg (fetch' (askDynTyTag osDyn) osDyn imag) s0
  where
    ((sReg,_),(Void,[])) = imag

repSubtree :: RegPat -> Dynamic -> Dynamic -> Dynamic
repSubtree RTreeIntegerListIntegerS0 ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode lil0
                                                                                                         (Nil))) ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode ril0
                                                                                                                                                                                     (Nil))) = toDyn (RNode ril0 Nil :: ( RTree Integer ))
repSubtree RTreeIntegerListIntegerS1 ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode lil0
                                                                                                         (Cons ltl1
                                                                                                               fromWild0fromWild0))) ((fromDynamic :: Dynamic -> Maybe ( RTree Integer )) -> Just (RNode ril0
                                                                                                                                                                                                         (Cons rtl1
                                                                                                                                                                                                               _))) = toDyn (RNode ril0 (Cons rtl1 fromWild0fromWild0) :: ( RTree Integer ))
repSubtree IntegerR dynS1 dynS2 = dynS1
repSubtree StringR dynS1 dynS2 = dynS1
repSubtree CharR dynS1 dynS2 = dynS1
repSubtree BoolR dynS1 dynS2 = dynS1

insSubtree = undefined -- no need to define it since it will not be invoked.

data RegPat
    = RTreeIntegerListIntegerV0
    | RTreeIntegerListIntegerV1
    | RTreeIntegerListIntegerS1
    | RTreeIntegerListIntegerS0
    | IntegerR
    | StringR
    | CharR
    | BoolR
    | Void
    deriving (Eq, Show, Ord, Read)