{-# LANGUAGE ViewPatterns #-}
module BX where

import BXDef
import Prelude hiding (putChar)
import Data.Maybe (isJust, isNothing, fromJust)
import Data.List (partition, sortBy, sort)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Dynamic
import Text.Show.Pretty (pPrint, ppShow)

topGetBinTIntegerBinTInteger :: BinT Integer ->
                                (BinT Integer, [HLink])

topGetBinTIntegerBinTInteger s = let (view,
                                      rlinks) = getBinTIntegerBinTInteger s
                                  in (view, toHLink rlinks)

getBinTIntegerBinTInteger :: BinT Integer ->
                             (BinT Integer, [RLink])

getBinTIntegerBinTInteger (Tip) = (Tip, l0 : ls')
                              where l0 = ((BinTIntegerBinTIntegerS0, []),
                                          (BinTIntegerBinTIntegerS0, []))
                                    ls' = concat []
getBinTIntegerBinTInteger (Node il0 xl1 yl2) = (Node ir0 yr1 xr2,
                                                l0 : ls')
                              where (ir0, ir0ls) = getIntegerInteger il0
                                    preS_ir0 = [0]
                                    preV_ir0 = [0]
                                    ir0ls' = map (addPathH (preS_ir0, preV_ir0)) ir0ls
                                    (yr1, yr1ls) = getBinTIntegerBinTInteger yl2
                                    preS_yr1 = [2]
                                    preV_yr1 = [1]
                                    yr1ls' = map (addPathH (preS_yr1, preV_yr1)) yr1ls
                                    (xr2, xr2ls) = getBinTIntegerBinTInteger xl1
                                    preS_xr2 = [1]
                                    preV_xr2 = [2]
                                    xr2ls' = map (addPathH (preS_xr2, preV_xr2)) xr2ls
                                    l0 = ((BinTIntegerBinTIntegerS1, []),
                                          (BinTIntegerBinTIntegerV1, []))
                                    ls' = concat [ir0ls', yr1ls', xr2ls']

getIntegerInteger s = (s, [((IntegerR, []), (IntegerR, []))])

getStringString s = (s, [((StringR, []), (StringR, []))])

getCharChar s = (s, [((CharR, []), (CharR, []))])

getBoolBool s = (s, [((BoolR, []), (BoolR, []))])

put :: OSTyTag ->
       STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

put osTy sTy vTy osDyn vDyn env | not (hasTopLink env) = putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env

put osTy sTy vTy osDyn vDyn env | hasTopLink env = putWithLinks osTy sTy vTy osDyn vDyn env

putNoLink :: OSTyTag ->
             STyTag -> VTyTag -> RegPat -> OSDyn -> VDyn -> [RLink] -> SDyn

putNoLink _ (IntegerTag) (IntegerTag) _ _ dynV _ = dynV

putNoLink _ (StringTag) (StringTag) _ _ dynV _ = dynV

putNoLink _ (CharTag) (CharTag) _ _ dynV _ = dynV

putNoLink _ (BoolTag) (BoolTag) _ _ dynV _ = dynV

putNoLink osTy (BinTIntegerTag) (BinTIntegerTag) BinTIntegerBinTIntegerS0 osDyn ((fromDynamic :: Dynamic -> Maybe (BinT Integer)) -> Just (Tip)) env = toDyn ((Tip) :: ( BinT Integer ))
putNoLink osTy (BinTIntegerTag) (BinTIntegerTag) BinTIntegerBinTIntegerS1 osDyn ((fromDynamic :: Dynamic -> Maybe (BinT Integer)) -> Just (Node ir0
                                                                                                                                                yr1
                                                                                                                                                xr2)) env = toDyn ((Node res_ir0 res_xr2 res_yr1) :: ( BinT Integer ))
              where preS_ir0 = [0]
                    preV_ir0 = [0]
                    env_ir0 = map (delPathH ([], preV_ir0)) (filterEnv preV_ir0 env)
                    res_ir0 :: ( Integer )
                    res_ir0 = fromJust (fromDynamic (put osTy IntegerTag IntegerTag osDyn (toDyn ir0) env_ir0))
                    preS_yr1 = [2]
                    preV_yr1 = [1]
                    env_yr1 = map (delPathH ([], preV_yr1)) (filterEnv preV_yr1 env)
                    res_yr1 :: ( BinT Integer )
                    res_yr1 = fromJust (fromDynamic (put osTy BinTIntegerTag BinTIntegerTag osDyn (toDyn yr1) env_yr1))
                    preS_xr2 = [1]
                    preV_xr2 = [2]
                    env_xr2 = map (delPathH ([], preV_xr2)) (filterEnv preV_xr2 env)
                    res_xr2 :: ( BinT Integer )
                    res_xr2 = fromJust (fromDynamic (put osTy BinTIntegerTag BinTIntegerTag osDyn (toDyn xr2) env_xr2))

putWithLinks :: OSTyTag ->
                STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

putWithLinks osTy sTy vTy osDyn vDyn env = s4
                 where (maybeL, imags, env') = getTopLinks env
                       s2 = case maybeL of
                                Just l -> let {((sReg, sPath), (_, [])) = l;
                                               s0 = fetch' osTy osDyn l;
                                               s1 = putNoLink osTy (askDynTyTag s0) vTy sReg osDyn vDyn env'}
                                           in (repSubtree sReg s0 s1)
                                Nothing -> putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env'
                       s3 = foldr (splice osDyn) s2 imags
                       s4 = mkInj (askDynTyTag s3) sTy s3

topPut :: OSTyTag -> STyTag -> VTyTag -> OSDyn -> VDyn -> [HLink] -> SDyn

topPut osTy sTy vTy osDyn vDyn hls = put osTy sTy vTy osDyn vDyn (eraseSecondOrderProp hls)

