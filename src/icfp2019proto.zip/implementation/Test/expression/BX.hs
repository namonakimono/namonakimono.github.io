{-# LANGUAGE ViewPatterns #-}
module BX where

import BXDef
import Prelude hiding (putChar)
import Data.Maybe (isJust, isNothing, fromJust)
import Data.List (partition, sortBy, sort)
import Data.Map hiding (map, foldl, foldr, filter, null, drop, partition, take)
import Data.Dynamic
import Text.Show.Pretty (pPrint, ppShow)

topGetExprArith :: Expr -> (Arith, [HLink])

topGetExprArith s = let (view, rlinks) = getExprArith s
                     in (view, toHLink rlinks)

topGetTermArith :: Term -> (Arith, [HLink])

topGetTermArith s = let (view, rlinks) = getTermArith s
                     in (view, toHLink rlinks)

topGetFactorArith :: Factor -> (Arith, [HLink])

topGetFactorArith s = let (view, rlinks) = getFactorArith s
                       in (view, toHLink rlinks)

getExprArith :: Expr -> (Arith, [RLink])

getExprArith (Plus _ xl0 yl1) = (Add xr0 yr1, l0 : ls')
                 where (xr0, xr0ls) = getExprArith xl0
                       preS_xr0 = [1]
                       preV_xr0 = [0]
                       xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                       (yr1, yr1ls) = getTermArith yl1
                       preS_yr1 = [2]
                       preV_yr1 = [1]
                       yr1ls' = map (addPathH (preS_yr1, preV_yr1)) yr1ls
                       l0 = ((ExprArithS0, []), (ExprArithV0, []))
                       ls' = concat [xr0ls', yr1ls']
getExprArith (Minus _ xl0 yl1) = (Sub xr0 yr1, l0 : ls')
                 where (xr0, xr0ls) = getExprArith xl0
                       preS_xr0 = [1]
                       preV_xr0 = [0]
                       xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                       (yr1, yr1ls) = getTermArith yl1
                       preS_yr1 = [2]
                       preV_yr1 = [1]
                       yr1ls' = map (addPathH (preS_yr1, preV_yr1)) yr1ls
                       l0 = ((ExprArithS1, []), (ExprArithV1, []))
                       ls' = concat [xr0ls', yr1ls']
getExprArith (FromT _ tl0) = (tr0, l0 : ls')
                 where (tr0, tr0ls) = getTermArith tl0
                       preS_tr0 = [1]
                       preV_tr0 = []
                       tr0ls' = map (addPathH (preS_tr0, preV_tr0)) tr0ls
                       l0 = ((ExprArithS2, []), (Void, []))
                       ls' = concat [tr0ls']

getTermArith :: Term -> (Arith, [RLink])

getTermArith (Times _ xl0 yl1) = (Mul xr0 yr1, l0 : ls')
                 where (xr0, xr0ls) = getTermArith xl0
                       preS_xr0 = [1]
                       preV_xr0 = [0]
                       xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                       (yr1, yr1ls) = getFactorArith yl1
                       preS_yr1 = [2]
                       preV_yr1 = [1]
                       yr1ls' = map (addPathH (preS_yr1, preV_yr1)) yr1ls
                       l0 = ((TermArithS0, []), (TermArithV0, []))
                       ls' = concat [xr0ls', yr1ls']
getTermArith (Division _ xl0 yl1) = (Div xr0 yr1, l0 : ls')
                 where (xr0, xr0ls) = getTermArith xl0
                       preS_xr0 = [1]
                       preV_xr0 = [0]
                       xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                       (yr1, yr1ls) = getFactorArith yl1
                       preS_yr1 = [2]
                       preV_yr1 = [1]
                       yr1ls' = map (addPathH (preS_yr1, preV_yr1)) yr1ls
                       l0 = ((TermArithS1, []), (TermArithV1, []))
                       ls' = concat [xr0ls', yr1ls']
getTermArith (FromF _ fl0) = (fr0, l0 : ls')
                 where (fr0, fr0ls) = getFactorArith fl0
                       preS_fr0 = [1]
                       preV_fr0 = []
                       fr0ls' = map (addPathH (preS_fr0, preV_fr0)) fr0ls
                       l0 = ((TermArithS2, []), (Void, []))
                       ls' = concat [fr0ls']

getFactorArith :: Factor -> (Arith, [RLink])

getFactorArith (Neg _ xl0) = (Sub (Num 0) xr0, l0 : ls')
                   where (xr0, xr0ls) = getFactorArith xl0
                         preS_xr0 = [1]
                         preV_xr0 = [1]
                         xr0ls' = map (addPathH (preS_xr0, preV_xr0)) xr0ls
                         l0 = ((FactorArithS0, []), (FactorArithV0, []))
                         ls' = concat [xr0ls']
getFactorArith (Lit _ il0) = (Num ir0, l0 : ls')
                   where (ir0, ir0ls) = getIntegerInteger il0
                         preS_ir0 = [1]
                         preV_ir0 = [0]
                         ir0ls' = map (addPathH (preS_ir0, preV_ir0)) ir0ls
                         l0 = ((FactorArithS1, []), (FactorArithV1, []))
                         ls' = concat [ir0ls']
getFactorArith (Paren _ el0) = (er0, l0 : ls')
                   where (er0, er0ls) = getExprArith el0
                         preS_er0 = [1]
                         preV_er0 = []
                         er0ls' = map (addPathH (preS_er0, preV_er0)) er0ls
                         l0 = ((FactorArithS2, []), (Void, []))
                         ls' = concat [er0ls']

getIntegerInteger s = (s, [((IntegerR, []), (IntegerR, []))])

getStringString s = (s, [((StringR, []), (StringR, []))])

getCharChar s = (s, [((CharR, []), (CharR, []))])

getBoolBool s = (s, [((BoolR, []), (BoolR, []))])

put :: OSTyTag ->
       STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

put osTy sTy vTy osDyn vDyn env | not (hasTopLink env) = putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env

put osTy sTy vTy osDyn vDyn env | hasTopLink env = putWithLinks osTy sTy vTy osDyn vDyn env

putNoLink :: OSTyTag ->
             STyTag -> VTyTag -> RegPat -> OSDyn -> VDyn -> [RLink] -> SDyn

putNoLink _ (IntegerTag) (IntegerTag) _ _ dynV _ = dynV

putNoLink _ (StringTag) (StringTag) _ _ dynV _ = dynV

putNoLink _ (CharTag) (CharTag) _ _ dynV _ = dynV

putNoLink _ (BoolTag) (BoolTag) _ _ dynV _ = dynV

putNoLink osTy (ExprTag) (ArithTag) ExprArithS0 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just (Add xr0
                                                                                                              yr1)) env = toDyn ((Plus "DEF_VAL" res_xr0 res_yr1) :: Expr)
              where preS_xr0 = [1]
                    preV_xr0 = [0]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( Expr )
                    res_xr0 = fromJust (fromDynamic (put osTy ExprTag ArithTag osDyn (toDyn xr0) env_xr0))
                    preS_yr1 = [2]
                    preV_yr1 = [1]
                    env_yr1 = map (delPathH ([], preV_yr1)) (filterEnv preV_yr1 env)
                    res_yr1 :: ( Term )
                    res_yr1 = fromJust (fromDynamic (put osTy TermTag ArithTag osDyn (toDyn yr1) env_yr1))
putNoLink osTy (ExprTag) (ArithTag) ExprArithS1 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just (Sub xr0
                                                                                                              yr1)) env = toDyn ((Minus "DEF_VAL" res_xr0 res_yr1) :: Expr)
              where preS_xr0 = [1]
                    preV_xr0 = [0]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( Expr )
                    res_xr0 = fromJust (fromDynamic (put osTy ExprTag ArithTag osDyn (toDyn xr0) env_xr0))
                    preS_yr1 = [2]
                    preV_yr1 = [1]
                    env_yr1 = map (delPathH ([], preV_yr1)) (filterEnv preV_yr1 env)
                    res_yr1 :: ( Term )
                    res_yr1 = fromJust (fromDynamic (put osTy TermTag ArithTag osDyn (toDyn yr1) env_yr1))
putNoLink osTy (ExprTag) (ArithTag) ExprArithS2 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just tr0) env = toDyn ((FromT "DEF_VAL" res_tr0) :: Expr)
              where preS_tr0 = [1]
                    preV_tr0 = []
                    env_tr0 = map (delPathH ([], preV_tr0)) (filterEnv preV_tr0 env)
                    res_tr0 :: ( Term )
                    res_tr0 = fromJust (fromDynamic (put osTy TermTag ArithTag osDyn (toDyn tr0) env_tr0))

putNoLink osTy (TermTag) (ArithTag) TermArithS0 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just (Mul xr0
                                                                                                              yr1)) env = toDyn ((Times "DEF_VAL" res_xr0 res_yr1) :: Term)
              where preS_xr0 = [1]
                    preV_xr0 = [0]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( Term )
                    res_xr0 = fromJust (fromDynamic (put osTy TermTag ArithTag osDyn (toDyn xr0) env_xr0))
                    preS_yr1 = [2]
                    preV_yr1 = [1]
                    env_yr1 = map (delPathH ([], preV_yr1)) (filterEnv preV_yr1 env)
                    res_yr1 :: ( Factor )
                    res_yr1 = fromJust (fromDynamic (put osTy FactorTag ArithTag osDyn (toDyn yr1) env_yr1))
putNoLink osTy (TermTag) (ArithTag) TermArithS1 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just (Div xr0
                                                                                                              yr1)) env = toDyn ((Division "DEF_VAL" res_xr0 res_yr1) :: Term)
              where preS_xr0 = [1]
                    preV_xr0 = [0]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( Term )
                    res_xr0 = fromJust (fromDynamic (put osTy TermTag ArithTag osDyn (toDyn xr0) env_xr0))
                    preS_yr1 = [2]
                    preV_yr1 = [1]
                    env_yr1 = map (delPathH ([], preV_yr1)) (filterEnv preV_yr1 env)
                    res_yr1 :: ( Factor )
                    res_yr1 = fromJust (fromDynamic (put osTy FactorTag ArithTag osDyn (toDyn yr1) env_yr1))
putNoLink osTy (TermTag) (ArithTag) TermArithS2 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just fr0) env = toDyn ((FromF "DEF_VAL" res_fr0) :: Term)
              where preS_fr0 = [1]
                    preV_fr0 = []
                    env_fr0 = map (delPathH ([], preV_fr0)) (filterEnv preV_fr0 env)
                    res_fr0 :: ( Factor )
                    res_fr0 = fromJust (fromDynamic (put osTy FactorTag ArithTag osDyn (toDyn fr0) env_fr0))

putNoLink osTy (FactorTag) (ArithTag) FactorArithS0 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just (Sub (Num 0)
                                                                                                                  xr0)) env = toDyn ((Neg "DEF_VAL" res_xr0) :: Factor)
              where preS_xr0 = [1]
                    preV_xr0 = [1]
                    env_xr0 = map (delPathH ([], preV_xr0)) (filterEnv preV_xr0 env)
                    res_xr0 :: ( Factor )
                    res_xr0 = fromJust (fromDynamic (put osTy FactorTag ArithTag osDyn (toDyn xr0) env_xr0))
putNoLink osTy (FactorTag) (ArithTag) FactorArithS1 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just (Num ir0)) env = toDyn ((Lit "DEF_VAL" res_ir0) :: Factor)
              where preS_ir0 = [1]
                    preV_ir0 = [0]
                    env_ir0 = map (delPathH ([], preV_ir0)) (filterEnv preV_ir0 env)
                    res_ir0 :: ( Integer )
                    res_ir0 = fromJust (fromDynamic (put osTy IntegerTag IntegerTag osDyn (toDyn ir0) env_ir0))
putNoLink osTy (FactorTag) (ArithTag) FactorArithS2 osDyn ((fromDynamic :: Dynamic -> Maybe (Arith)) -> Just er0) env = toDyn ((Paren "DEF_VAL" res_er0) :: Factor)
              where preS_er0 = [1]
                    preV_er0 = []
                    env_er0 = map (delPathH ([], preV_er0)) (filterEnv preV_er0 env)
                    res_er0 :: ( Expr )
                    res_er0 = fromJust (fromDynamic (put osTy ExprTag ArithTag osDyn (toDyn er0) env_er0))

putWithLinks :: OSTyTag ->
                STyTag -> VTyTag -> OSDyn -> VDyn -> [RLink] -> SDyn

putWithLinks osTy sTy vTy osDyn vDyn env = s4
                 where (maybeL, imags, env') = getTopLinks env
                       s2 = case maybeL of
                                Just l -> let {((sReg, sPath), (_, [])) = l;
                                               s0 = fetch' osTy osDyn l;
                                               s1 = putNoLink osTy (askDynTyTag s0) vTy sReg osDyn vDyn env'}
                                           in (repSubtree sReg s0 s1)
                                Nothing -> putNoLink osTy sTy vTy (selSPat sTy vTy vDyn) osDyn vDyn env'
                       s3 = foldr (splice osDyn) s2 imags
                       s4 = mkInj (askDynTyTag s3) sTy s3

topPut :: OSTyTag -> STyTag -> VTyTag -> OSDyn -> VDyn -> [HLink] -> SDyn

topPut osTy sTy vTy osDyn vDyn hls = put osTy sTy vTy osDyn vDyn (eraseSecondOrderProp hls)

